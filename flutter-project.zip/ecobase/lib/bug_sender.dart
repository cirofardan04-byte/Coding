import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  List<dynamic> senderList = [];
  bool isLoading = false;
  bool isRefreshing = false;
  String? errorMessage;

  late VideoPlayerController _backgroundVideoController;
  bool _backgroundVideoInitialized = false;

  // ====== NEON BLUE LIGHT THEME ======
  final Color primaryColor = const Color(0xFF00B0FF); // Electric Blue
  final Color accentColor = const Color(0xFF00B0FF); // Cyan Neon
  final Color backgroundColor = const Color(0xFF050B1A);
  final Color surfaceColor = const Color(0xFF0A1930);
  final Color cardColor = const Color(0xFF0F2547);
  final Color textPrimary = Colors.white;
  final Color textSecondary = const Color(0xFFB3E5FC);

  // White glow helper
  List<BoxShadow> neonGlow({
    Color color = const Color(0xFF00B0FF),
    double blur = 16,
    double spread = 1.5,
    double opacity = 0.55,
  }) {
    return [
      BoxShadow(
        color: color.withOpacity(opacity),
        blurRadius: blur,
        spreadRadius: spread,
      ),
      BoxShadow(
        color: Colors.white.withOpacity(0.18), // cahaya putih tipis
        blurRadius: blur * 0.6,
        spreadRadius: 0.5,
      ),
    ];
  }

  bool get canAddGlobal =>
      ["owner", "developer"].contains(widget.role.toLowerCase());

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _fetchSenders();
    _initBackgroundVideo();
  }

  void _initBackgroundVideo() {
    _backgroundVideoController =
        VideoPlayerController.asset('assets/videos/splash.mp4')
          ..initialize().then((_) {
            if (mounted) {
              setState(() => _backgroundVideoInitialized = true);
              _backgroundVideoController.setLooping(true);
              _backgroundVideoController.setVolume(0);
              _backgroundVideoController.play();
            }
          }).catchError((error) {
            debugPrint("Background video error: $error");
          });
  }

  void _initAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    )..forward();

    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    _backgroundVideoController.dispose();
    super.dispose();
  }

  Future<void> _fetchSenders() async {
    setState(() {
      isLoading = true;
      errorMessage = null;
    });
    try {
      final res = await http.get(
        Uri.parse(
            "http://raulllll.panelantirusuh.biz.id:10361/mySender?key=${widget.sessionKey}"),
      );
      final data = jsonDecode(res.body);
      if (res.statusCode == 200 && data["valid"] == true) {
        final connections = data["connections"] as List<dynamic>? ?? [];
        connections.sort((a, b) {
          final ag = a["isGlobal"] == true ? 0 : 1;
          final bg = b["isGlobal"] == true ? 0 : 1;
          if (ag != bg) return ag.compareTo(bg);
          return (a["sessionName"] ?? "").toString().compareTo(
                (b["sessionName"] ?? "").toString(),
              );
        });
        setState(() => senderList = connections);
      } else {
        setState(
          () => errorMessage = data["message"] ?? "Failed to fetch senders",
        );
      }
    } catch (e) {
      setState(() => errorMessage = "Connection failed: $e");
    } finally {
      setState(() {
        isLoading = false;
        isRefreshing = false;
      });
    }
  }

  Future<void> _refreshSenders() async {
    setState(() => isRefreshing = true);
    await _fetchSenders();
  }

  Future<void> _addSender(String number, bool isGlobal) async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse(
          "http://raulllll.panelantirusuh.biz.id:10361/getPairing?key=${widget.sessionKey}&number=$number&global=${isGlobal ? 1 : 0}",
        ),
      );
      final data = jsonDecode(res.body);
      if (res.statusCode == 200 && data["valid"] == true) {
        _showPairingDialog(number, data["pairingCode"].toString());
        _showSnackBar("Pairing code generated!", false);
      } else {
        _showSnackBar(
            data["message"] ?? "Failed to generate pairing code", true);
      }
    } catch (e) {
      _showSnackBar("Connection failed: $e", true);
    } finally {
      setState(() => isLoading = false);
      await _fetchSenders();
    }
  }

  Future<void> _deleteSender(String id, bool isGlobal) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => _buildDeleteDialog(isGlobal),
    );
    if (ok != true) return;

    setState(() => isLoading = true);
    try {
      final res = await http.delete(
        Uri.parse(
          "http://raulllll.panelantirusuh.biz.id:10361/deleteSender?key=${widget.sessionKey}&id=$id&scope=${isGlobal ? 'global' : 'private'}",
        ),
      );
      final data = jsonDecode(res.body);
      if (res.statusCode == 200 && data["valid"] == true) {
        _showSnackBar("Sender deleted successfully!", false);
        await _fetchSenders();
      } else {
        _showSnackBar(data["message"] ?? "Failed to delete sender", true);
      }
    } catch (e) {
      _showSnackBar("Connection failed: $e", true);
    } finally {
      setState(() => isLoading = false);
    }
  }

  Widget _buildDeleteDialog(bool isGlobal) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: TweenAnimationBuilder(
        duration: const Duration(milliseconds: 300),
        tween: Tween<double>(begin: 0, end: 1),
        builder: (context, double scale, child) {
          return Transform.scale(scale: scale, child: child);
        },
        child: Container(
          margin: const EdgeInsets.all(20),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(32),
            border: Border.all(color: Colors.red.withOpacity(0.6), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: Colors.red.withOpacity(0.45),
                blurRadius: 16,
                spreadRadius: 1.5,
              ),
              BoxShadow(
                color: Colors.white.withOpacity(0.15),
                blurRadius: 8,
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.red.withOpacity(0.4)),
                ),
                child: const Icon(Icons.warning_amber_rounded,
                    color: Colors.redAccent, size: 32),
              ),
              const SizedBox(height: 20),
              const Text(
                "Confirm Delete",
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                isGlobal
                    ? "Global sender ini akan dihapus untuk semua user. This action cannot be undone."
                    : "Are you sure you want to delete this sender? This action cannot be undone.",
                style: TextStyle(color: textSecondary, fontSize: 13),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context, false),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(16),
                          border:
                              Border.all(color: Colors.white.withOpacity(0.15)),
                        ),
                        child: Center(
                          child: Text(
                            "CANCEL",
                            style: TextStyle(
                                color: textSecondary,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: GestureDetector(
                      onTap: () => Navigator.pop(context, true),
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: Colors.red.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(16),
                          border:
                              Border.all(color: Colors.red.withOpacity(0.5)),
                        ),
                        child: const Center(
                          child: Text(
                            "DELETE",
                            style: TextStyle(
                                color: Colors.redAccent,
                                fontWeight: FontWeight.w600),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showAddDialog() {
    final phoneController = TextEditingController();
    bool isGlobal = false;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setLocal) {
            return Dialog(
              backgroundColor: Colors.transparent,
              child: TweenAnimationBuilder(
                duration: const Duration(milliseconds: 300),
                tween: Tween<double>(begin: 0, end: 1),
                builder: (context, double scale, child) {
                  return Transform.scale(scale: scale, child: child);
                },
                child: Container(
                  margin: const EdgeInsets.all(20),
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: cardColor,
                    borderRadius: BorderRadius.circular(32),
                    border: Border.all(
                        color: primaryColor.withOpacity(0.55), width: 1.5),
                    boxShadow: neonGlow(opacity: 0.5),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                              colors: [primaryColor, accentColor]),
                          shape: BoxShape.circle,
                          boxShadow: neonGlow(opacity: 0.6),
                        ),
                        child: const Icon(Icons.phone_android,
                            color: Colors.white, size: 28),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        "Add New Sender",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                        ),
                      ),
                      const SizedBox(height: 8),
                      const Text(
                        "Enter phone number to add new WhatsApp sender",
                        style: TextStyle(color: Colors.white70, fontSize: 13),
                      ),
                      const SizedBox(height: 24),
                      Container(
                        decoration: BoxDecoration(
                          color: surfaceColor,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                              color: primaryColor.withOpacity(0.45)),
                          boxShadow: neonGlow(
                              blur: 10, spread: 0.5, opacity: 0.35),
                        ),
                        child: TextField(
                          controller: phoneController,
                          keyboardType: TextInputType.phone,
                          style: TextStyle(color: textPrimary, fontSize: 16),
                          decoration: InputDecoration(
                            hintText: "62xxxxxxxxxx",
                            hintStyle: TextStyle(
                                color: textSecondary.withOpacity(0.5)),
                            prefixIcon: Icon(Icons.phone,
                                color: accentColor, size: 20),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(
                                horizontal: 20, vertical: 16),
                          ),
                        ),
                      ),
                      if (canAddGlobal) ...[
                        const SizedBox(height: 16),
                        Container(
                          decoration: BoxDecoration(
                            color: surfaceColor,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                                color: primaryColor.withOpacity(0.45)),
                          ),
                          child: SwitchListTile(
                            value: isGlobal,
                            onChanged: (v) => setLocal(() => isGlobal = v),
                            title: Text(
                              "Global Sender",
                              style: TextStyle(color: textPrimary),
                            ),
                            subtitle: Text(
                              "Tambah global sender untuk semua role",
                              style: TextStyle(
                                  color: textSecondary, fontSize: 12),
                            ),
                            activeColor: accentColor,
                            inactiveThumbColor: Colors.grey,
                            contentPadding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                          ),
                        ),
                      ],
                      const SizedBox(height: 24),
                      Row(
                        children: [
                          Expanded(
                            child: GestureDetector(
                              onTap: () => Navigator.pop(context),
                              child: Container(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 14),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.05),
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(
                                      color: Colors.white.withOpacity(0.15)),
                                ),
                                child: Center(
                                  child: Text(
                                    "CANCEL",
                                    style: TextStyle(
                                        color: textSecondary,
                                        fontWeight: FontWeight.w600),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: GestureDetector(
                              onTap: () async {
                                final number = phoneController.text.trim();
                                if (number.isEmpty) {
                                  _showSnackBar(
                                      "Please enter phone number", true);
                                  return;
                                }
                                if (isGlobal && !canAddGlobal) {
                                  _showSnackBar(
                                    "Hanya owner & developer yang dapat menambahkan Global Sender.",
                                    true,
                                  );
                                  return;
                                }
                                Navigator.pop(context);
                                await _addSender(number, isGlobal);
                              },
                              child: Container(
                                padding:
                                    const EdgeInsets.symmetric(vertical: 14),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                      colors: [primaryColor, accentColor]),
                                  borderRadius: BorderRadius.circular(16),
                                  boxShadow: neonGlow(opacity: 0.5),
                                ),
                                child: Center(
                                  child: Text(
                                    "ADD SENDER",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w600),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _showPairingDialog(String number, String code) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: TweenAnimationBuilder(
          duration: const Duration(milliseconds: 300),
          tween: Tween<double>(begin: 0, end: 1),
          builder: (context, double scale, child) {
            return Transform.scale(scale: scale, child: child);
          },
          child: Container(
            margin: const EdgeInsets.all(20),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(32),
              border: Border.all(
                  color: primaryColor.withOpacity(0.55), width: 1.5),
              boxShadow: neonGlow(opacity: 0.5),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient:
                        LinearGradient(colors: [primaryColor, accentColor]),
                    shape: BoxShape.circle,
                    boxShadow: neonGlow(opacity: 0.6),
                  ),
                  child: const Icon(Icons.qr_code_2,
                      color: Colors.white, size: 32),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Pairing Required",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  "Number: $number",
                  style: TextStyle(color: textSecondary, fontSize: 14),
                ),
                const SizedBox(height: 20),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        primaryColor.withOpacity(0.1),
                        accentColor.withOpacity(0.1),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(20),
                    border:
                        Border.all(color: primaryColor.withOpacity(0.45)),
                    boxShadow: neonGlow(
                        blur: 12, spread: 0.5, opacity: 0.35),
                  ),
                  child: Column(
                    children: [
                      Text(
                        "Pairing Code",
                        style: TextStyle(color: textSecondary, fontSize: 12),
                      ),
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: backgroundColor,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: accentColor, width: 2),
                          boxShadow: neonGlow(
                              color: accentColor,
                              blur: 14,
                              spread: 0.8,
                              opacity: 0.55),
                        ),
                        child: SelectableText(
                          code,
                          style: TextStyle(
                            color: accentColor,
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 4,
                            fontFamily: 'monospace',
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      GestureDetector(
                        onTap: () async {
                          await Clipboard.setData(ClipboardData(text: code));
                          _showSnackBar("Code copied to clipboard!", false);
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                            color: primaryColor.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                                color: primaryColor.withOpacity(0.45)),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.copy, color: accentColor, size: 18),
                              const SizedBox(width: 8),
                              Text(
                                "COPY CODE",
                                style: TextStyle(
                                    color: accentColor,
                                    fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                                color: Colors.white.withOpacity(0.15)),
                          ),
                          child: Center(
                            child: Text(
                              "CLOSE",
                              style: TextStyle(
                                  color: textSecondary,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                          _refreshSenders();
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                                colors: [primaryColor, accentColor]),
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: neonGlow(opacity: 0.5),
                          ),
                          child: Center(
                            child: Text(
                              "REFRESH",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showSnackBar(String msg, bool isError) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : Icons.check_circle_outline,
              color: Colors.white,
              size: 20,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                msg,
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w500),
              ),
            ),
          ],
        ),
        backgroundColor: isError
            ? Colors.red.withOpacity(0.9)
            : primaryColor.withOpacity(0.9),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  Widget _buildSenderCard(Map<String, dynamic> sender, int index) {
    final name = sender["sessionName"] ?? "WhatsApp Sender";
    final id = (sender["id"] ?? name).toString();
    final isGlobal = sender["isGlobal"] == true;
    final canDelete = sender["canDelete"] != false;

    return TweenAnimationBuilder(
      duration: Duration(milliseconds: 300 + (index * 50)),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Transform.translate(
          offset: Offset(0, 20 * (1 - value)),
          child: Opacity(opacity: value, child: child),
        );
      },
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: surfaceColor,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: primaryColor.withOpacity(0.45), width: 1),
          boxShadow: neonGlow(blur: 14, spread: 0.6, opacity: 0.35),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                          colors: [primaryColor, accentColor]),
                      shape: BoxShape.circle,
                      boxShadow: neonGlow(opacity: 0.55),
                    ),
                    child: Icon(
                      isGlobal ? Icons.public : Icons.phone_android,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          name,
                          style: TextStyle(
                            color: textPrimary,
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          "ID: $id",
                          style:
                              TextStyle(color: textSecondary, fontSize: 11),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: (isGlobal ? primaryColor : accentColor)
                          .withOpacity(0.15),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: (isGlobal ? primaryColor : accentColor)
                            .withOpacity(0.45),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: (isGlobal ? primaryColor : accentColor)
                              .withOpacity(0.3),
                          blurRadius: 8,
                        ),
                        BoxShadow(
                          color: Colors.white.withOpacity(0.12),
                          blurRadius: 4,
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 8,
                          height: 8,
                          decoration: BoxDecoration(
                            color: isGlobal ? primaryColor : accentColor,
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: (isGlobal ? primaryColor : accentColor)
                                    .withOpacity(0.8),
                                blurRadius: 8,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          isGlobal ? "GLOBAL" : "PRIVATE",
                          style: TextStyle(
                            color: isGlobal ? primaryColor : accentColor,
                            fontSize: 10,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: _refreshSenders,
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: primaryColor.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                              color: primaryColor.withOpacity(0.45)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.refresh, color: accentColor, size: 18),
                            const SizedBox(width: 8),
                            Text(
                              "REFRESH",
                              style: TextStyle(
                                  color: accentColor,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 12),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: GestureDetector(
                      onTap: canDelete
                          ? () => _deleteSender(id, isGlobal)
                          : null,
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: canDelete
                              ? Colors.red.withOpacity(0.15)
                              : Colors.grey.withOpacity(0.05),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: canDelete
                                ? Colors.red.withOpacity(0.45)
                                : Colors.grey.withOpacity(0.15),
                          ),
                          boxShadow: canDelete
                              ? [
                                  BoxShadow(
                                    color:
                                        Colors.red.withOpacity(0.3),
                                    blurRadius: 8,
                                  ),
                                  BoxShadow(
                                    color: Colors.white.withOpacity(0.12),
                                    blurRadius: 4,
                                  ),
                                ]
                              : null,
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(
                              canDelete
                                  ? Icons.delete_outline
                                  : Icons.lock_outline,
                              color:
                                  canDelete ? Colors.redAccent : textSecondary,
                              size: 18,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              canDelete ? "DELETE" : "LOCKED",
                              style: TextStyle(
                                color: canDelete
                                    ? Colors.redAccent
                                    : textSecondary,
                                fontWeight: FontWeight.w600,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoBanner() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: surfaceColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: primaryColor.withOpacity(0.45), width: 1),
        boxShadow: neonGlow(blur: 12, spread: 0.5, opacity: 0.35),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient:
                  LinearGradient(colors: [primaryColor, accentColor]),
              borderRadius: BorderRadius.circular(12),
              boxShadow: neonGlow(blur: 10, spread: 0.5, opacity: 0.55),
            ),
            child: const Icon(Icons.info_outline,
                color: Colors.white, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              "Global sender hanya bisa ditambah owner/developer, tapi semua role bisa memakai global sender.",
              style: TextStyle(color: textSecondary, fontSize: 12, height: 1.3),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: TweenAnimationBuilder(
        duration: const Duration(milliseconds: 600),
        tween: Tween<double>(begin: 0, end: 1),
        builder: (context, double value, child) {
          return Opacity(
            opacity: value,
            child: Transform.translate(
              offset: Offset(0, 20 * (1 - value)),
              child: child,
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(32),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      primaryColor.withOpacity(0.1),
                      accentColor.withOpacity(0.1),
                    ],
                  ),
                  shape: BoxShape.circle,
                  border: Border.all(color: primaryColor.withOpacity(0.45)),
                  boxShadow: neonGlow(blur: 20, spread: 1, opacity: 0.4),
                ),
                child: Icon(Icons.phone_iphone, color: accentColor, size: 70),
              ),
              const SizedBox(height: 28),
              Text(
                "No Senders Found",
                style: TextStyle(
                    color: textPrimary,
                    fontSize: 22,
                    fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              Text(
                "Add your first WhatsApp sender to get started",
                style: TextStyle(color: textSecondary, fontSize: 14),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 36),
              GestureDetector(
                onTap: _showAddDialog,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                  decoration: BoxDecoration(
                    gradient:
                        LinearGradient(colors: [primaryColor, accentColor]),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: primaryColor.withOpacity(0.6),
                        blurRadius: 20,
                        spreadRadius: 1.5,
                      ),
                      BoxShadow(
                        color: Colors.white.withOpacity(0.2),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.add, color: Colors.white, size: 22),
                      const SizedBox(width: 10),
                      const Text(
                        "ADD NEW SENDER",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(0.15),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.red.withOpacity(0.4)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.red.withOpacity(0.4),
                    blurRadius: 16,
                  ),
                  BoxShadow(
                    color: Colors.white.withOpacity(0.12),
                    blurRadius: 8,
                  ),
                ],
              ),
              child: const Icon(Icons.error_outline,
                  color: Colors.redAccent, size: 60),
            ),
            const SizedBox(height: 24),
            const Text(
              "Failed to Load",
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(
              errorMessage ?? "Unknown error occurred",
              style: TextStyle(color: textSecondary, fontSize: 14),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),
            GestureDetector(
              onTap: _refreshSenders,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 32, vertical: 14),
                decoration: BoxDecoration(
                  gradient:
                      LinearGradient(colors: [primaryColor, accentColor]),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    BoxShadow(
                      color: primaryColor.withOpacity(0.6),
                      blurRadius: 20,
                      spreadRadius: 1.5,
                    ),
                    BoxShadow(
                      color: Colors.white.withOpacity(0.2),
                      blurRadius: 10,
                    ),
                  ],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.refresh, color: Colors.white, size: 20),
                    const SizedBox(width: 10),
                    const Text(
                      "TRY AGAIN",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: primaryColor.withOpacity(0.45)),
              boxShadow: neonGlow(blur: 8, spread: 0.3, opacity: 0.35),
            ),
            child: Icon(Icons.arrow_back_ios_new,
                color: accentColor, size: 18),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [primaryColor, accentColor]),
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: primaryColor.withOpacity(0.6),
                blurRadius: 16,
                spreadRadius: 1,
              ),
              BoxShadow(
                color: Colors.white.withOpacity(0.2),
                blurRadius: 8,
              ),
            ],
          ),
          child: const Text(
            "BUG SENDER",
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 14,
              letterSpacing: 1,
            ),
          ),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: primaryColor.withOpacity(0.45)),
              boxShadow: neonGlow(blur: 8, spread: 0.3, opacity: 0.35),
            ),
            child: IconButton(
              icon: AnimatedRotation(
                turns: isRefreshing ? 1.0 : 0.0,
                duration: const Duration(milliseconds: 500),
                child: Icon(Icons.refresh, color: accentColor, size: 20),
              ),
              onPressed: isLoading ? null : _refreshSenders,
            ),
          ),
          Container(
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              gradient:
                  LinearGradient(colors: [primaryColor, accentColor]),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: primaryColor.withOpacity(0.6),
                  blurRadius: 14,
                  spreadRadius: 1,
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.2),
                  blurRadius: 8,
                ),
              ],
            ),
            child: IconButton(
              icon: const Icon(Icons.add, color: Colors.white, size: 20),
              onPressed: _showAddDialog,
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          if (_backgroundVideoInitialized)
            SizedBox(
              width: double.infinity,
              height: double.infinity,
              child: VideoPlayer(_backgroundVideoController),
            )
          else
            Container(color: backgroundColor),

          // Overlay biru neon gelap
          Container(
            color: const Color(0xFF001028).withOpacity(0.6),
          ),

          FadeTransition(
            opacity: _fadeAnimation,
            child: isLoading && senderList.isEmpty
                ? Center(
                    child: CircularProgressIndicator(
                      color: accentColor,
                      strokeWidth: 3,
                    ),
                  )
                : errorMessage != null && senderList.isEmpty
                    ? _buildErrorState()
                    : Column(
                        children: [
                          _buildInfoBanner(),
                          Expanded(
                            child: senderList.isEmpty
                                ? _buildEmptyState()
                                : RefreshIndicator(
                                    color: accentColor,
                                    backgroundColor: surfaceColor,
                                    onRefresh: _refreshSenders,
                                    child: ListView.builder(
                                      physics:
                                          const AlwaysScrollableScrollPhysics(),
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 8),
                                      itemCount: senderList.length,
                                      itemBuilder: (context, index) =>
                                          _buildSenderCard(
                                        Map<String, dynamic>.from(
                                            senderList[index]),
                                        index,
                                      ),
                                    ),
                                  ),
                          ),
                        ],
                      ),
          ),
        ],
      ),
    );
  }
}