import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'splash.dart';
import 'toko_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;

  late AnimationController _controller;
  late AnimationController _bgController;
  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;

  // ═══════════ WARNA (mengikuti foto referensi: light blue) ═══════════
  final Color bgTop = const Color(0xFFDCE9FF);
  final Color bgBottom = const Color(0xFFC8DBFF);
  final Color surfaceColor = Colors.white;
  final Color softBlue = const Color(0xFFD6E4FF);
  final Color borderColor = const Color(0xFF0A0A0A);
  final Color textPrimary = const Color(0xFF0A0A0A);
  final Color textSecondary = const Color(0xFF6B7280);
  final Color primaryColor = const Color(0xFF00B0FF);
  final Color accentColor = const Color(0xFF00B0FF);
  final Color neonBlue = const Color(0xFF00A8FF);
  final Color neonCyan = const Color(0xFF00E5FF);
  final Color neonWhite = const Color(0xFFFFFFFF);

  final String bannerUrl = "https://files.catbox.moe/w7tjwt.jpg/pjsw43.jpg";

  @override
  void initState() {
    super.initState();
    _initAnim();
    _bgController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();
    initLogin();
  }

  void _initAnim() {
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..forward();
    _fadeAnim = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
    _slideAnim = Tween<Offset>(begin: const Offset(0, 0.15), end: Offset.zero)
        .animate(CurvedAnimation(
            parent: _controller, curve: Curves.easeOutCubic));
  }

  Future<void> initLogin() async {
    androidId = await getAndroidId();

    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
          "http://raulllll.panelantirusuh.biz.id:10361/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey");
      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);
        if (data['valid'] == true && mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => SplashScreen(
                username: savedUser,
                password: savedPass,
                role: data['role'],
                sessionKey: data['key'],
                expiredDate: data['expiredDate'],
                listBug: (data['listBug'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                news: (data['news'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
              ),
            ),
          );
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  Future<void> login() async {
    if (!_formKey.currentState!.validate()) return;

    final username = userController.text.trim();
    final password = passController.text.trim();

    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("http://raulllll.panelantirusuh.biz.id:10361/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );

      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        if (mounted) {
          _showPopup(
            title: "⏳ Akses Habis",
            message: "Masa akses Anda telah berakhir. Silakan perpanjang.",
            showContact: true,
          );
        }
      } else if (validData['valid'] != true) {
        final String errorMsg = (validData['message'] ?? "").toLowerCase();
        if (errorMsg.contains("perangkat") ||
            errorMsg.contains("device") ||
            errorMsg.contains("another")) {
          if (mounted) {
            _showPopup(
              title: "⚠️ Sesi Aktif",
              message:
                  "Akun ini sedang login di perangkat lain. Logout terlebih dahulu.",
            );
          }
        } else {
          if (mounted) {
            _showPopup(
              title: "❌ Login Gagal",
              message: "Username atau password salah.",
            );
          }
        }
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        if (mounted) {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(
              builder: (_) => SplashScreen(
                username: username,
                password: password,
                role: validData['role'],
                sessionKey: validData['key'],
                expiredDate: validData['expiredDate'],
                listBug: (validData['listBug'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
                news: (validData['news'] as List? ?? [])
                    .map((e) => Map<String, dynamic>.from(e as Map))
                    .toList(),
              ),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        _showPopup(
          title: "⚠️ Koneksi Error",
          message: "Gagal terhubung ke server. Periksa internet Anda.",
        );
      }
    }

    if (mounted) {
      setState(() => isLoading = false);
    }
  }

  void _showPopup({
    required String title,
    required String message,
    bool showContact = false,
  }) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: TweenAnimationBuilder(
          duration: const Duration(milliseconds: 400),
          tween: Tween<double>(begin: 0, end: 1),
          builder: (context, double scale, child) {
            return Transform.scale(scale: scale, child: child);
          },
          child: Container(
            margin: const EdgeInsets.all(20),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: surfaceColor,
              borderRadius: BorderRadius.circular(24),
              border: Border.all(color: borderColor, width: 2),
              boxShadow: const [
                BoxShadow(color: borderColor, offset: Offset(5, 5)),
                BoxShadow(
                  color: Color(0x3300A8FF),
                  blurRadius: 30,
                  spreadRadius: 3,
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: softBlue,
                    shape: BoxShape.circle,
                    border: Border.all(color: borderColor, width: 2),
                  ),
                  child: Icon(
                    title.contains("Gagal") ||
                            title.contains("Habis") ||
                            title.contains("Sesi")
                        ? Icons.warning_rounded
                        : Icons.check_circle_rounded,
                    color: borderColor,
                    size: 32,
                  ),
                ),
                const SizedBox(height: 18),
                Text(
                  title,
                  style: const TextStyle(
                    color: Color(0xFF0A0A0A),
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: softBlue.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: borderColor, width: 1.4),
                  ),
                  child: Text(
                    message,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Color(0xFF1F2937),
                      fontSize: 13,
                      height: 1.5,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    if (showContact)
                      Expanded(
                        child: GestureDetector(
                          onTap: () async {
                            await launchUrl(
                                Uri.parse("https://t.me/resbobnich"),
                                mode: LaunchMode.externalApplication);
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            decoration: BoxDecoration(
                              color: softBlue,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: borderColor, width: 2),
                            ),
                            child: const Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.send_rounded,
                                    color: Color(0xFF0A0A0A), size: 14),
                                SizedBox(width: 6),
                                Text(
                                  "HUBUNGI",
                                  style: TextStyle(
                                    color: Color(0xFF0A0A0A),
                                    fontWeight: FontWeight.w800,
                                    fontSize: 11,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    if (showContact) const SizedBox(width: 10),
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: primaryColor,
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(color: borderColor, width: 2),
                            boxShadow: const [
                              BoxShadow(
                                color: borderColor,
                                offset: Offset(3, 3),
                              ),
                            ],
                          ),
                          child: const Center(
                            child: Text(
                              "TUTUP",
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w800,
                                fontSize: 12,
                                letterSpacing: 1,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _bgController.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgTop,
      body: Stack(
        children: [
          // ─── BACKGROUND GRADIENT LIGHT BLUE ──────────────────
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [bgTop, bgBottom, bgTop],
              ),
            ),
          ),

          // ─── ANIMASI NEON: BINTANG, GARIS, GLOW, ASTEROID ────
          Positioned.fill(
            child: AnimatedBuilder(
              animation: _bgController,
              builder: (context, _) {
                return CustomPaint(
                  painter: _NeonSpacePainter(
                    progress: _bgController.value,
                    neonBlue: neonBlue,
                    neonCyan: neonCyan,
                    neonWhite: neonWhite,
                  ),
                );
              },
            ),
          ),

          // ─── KONTEN UTAMA ────────────────────────────────────
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: SlideTransition(
                position: _slideAnim,
                child: Center(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(height: 20),

                        // ─── LOGO CARD ────────────────────────────
                        _buildLogoCard(),
                        const SizedBox(height: 18),

                        // ─── WELCOME BACK ─────────────────────────
                        RichText(
                          text: const TextSpan(
                            style: TextStyle(
                              fontSize: 30,
                              fontWeight: FontWeight.w900,
                              letterSpacing: 0.5,
                              color: Color(0xFF0A0A0A),
                            ),
                            children: [
                              TextSpan(text: "Welcome "),
                              TextSpan(
                                text: "Back",
                                style: TextStyle(color: Color(0xFF2563EB)),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          "Masuk ke akun Anda",
                          style: TextStyle(
                            color: Color(0xFF6B7280),
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const SizedBox(height: 28),

                        // ─── FORM ─────────────────────────────────
                        Form(
                          key: _formKey,
                          child: Column(
                            children: [
                              _buildInput(
                                userController,
                                "Username",
                                Icons.person_outline_rounded,
                                false,
                              ),
                              const SizedBox(height: 14),
                              _buildInput(
                                passController,
                                "Password",
                                Icons.lock_outline_rounded,
                                true,
                              ),
                              const SizedBox(height: 8),
                              Align(
                                alignment: Alignment.centerRight,
                                child: GestureDetector(
                                  onTap: () {
                                    _showPopup(
                                      title: "🔑 Lupa Password?",
                                      message:
                                          "Hubungi admin untuk reset password.",
                                      showContact: true,
                                    );
                                  },
                                  child: const Text(
                                    "Lupa password?",
                                    style: TextStyle(
                                      color: Color(0xFF2563EB),
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(height: 18),

                              // ─── TOMBOL SIGN IN ─────────────────
                              _buildButton(),

                              const SizedBox(height: 16),

                              // ─── ATAU ───────────────────────────
                              Row(
                                children: [
                                  Expanded(
                                    child: Container(
                                      height: 1,
                                      color:
                                          const Color(0xFF0A0A0A).withOpacity(0.15),
                                    ),
                                  ),
                                  const Padding(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 12),
                                    child: Text(
                                      "ATAU",
                                      style: TextStyle(
                                        color: Color(0xFF6B7280),
                                        fontSize: 10,
                                        fontWeight: FontWeight.w800,
                                        letterSpacing: 2,
                                      ),
                                    ),
                                  ),
                                  Expanded(
                                    child: Container(
                                      height: 1,
                                      color:
                                          const Color(0xFF0A0A0A).withOpacity(0.15),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 14),

                              // ─── BELI AKUN ──────────────────────
                              GestureDetector(
                                onTap: () {
                                  Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => const TokoPage(),
                                    ),
                                  );
                                },
                                child: Container(
                                  width: double.infinity,
                                  padding: const EdgeInsets.symmetric(
                                      vertical: 14),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFFFB74D),
                                    borderRadius: BorderRadius.circular(14),
                                    border:
                                        Border.all(color: borderColor, width: 2),
                                    boxShadow: const [
                                      BoxShadow(
                                        color: borderColor,
                                        offset: Offset(3, 3),
                                      ),
                                    ],
                                  ),
                                  child: const Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.shopping_bag_rounded,
                                          color: Color(0xFF0A0A0A), size: 18),
                                      SizedBox(width: 10),
                                      Text(
                                        "BELI AKUN",
                                        style: TextStyle(
                                          color: Color(0xFF0A0A0A),
                                          fontSize: 13,
                                          fontWeight: FontWeight.w800,
                                          letterSpacing: 1.5,
                                        ),
                                      ),
                                      SizedBox(width: 8),
                                      Icon(Icons.arrow_forward_rounded,
                                          color: Color(0xFF0A0A0A), size: 16),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 24),

                        // ─── SOCIAL CHIP ──────────────────────────
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _buildSocialChip(
                              icon: FontAwesomeIcons.tiktok,
                              label: "Tiktok",
                              url:
                                  "https://www.tiktok.com/@kaicho.NEVERLOUS PROJECT",
                              color: const Color(0xFF0A0A0A),
                            ),
                            const SizedBox(width: 12),
                            _buildSocialChip(
                              icon: FontAwesomeIcons.instagram,
                              label: "Instagram",
                              url: "https://www.instagram.com/yawdwy",
                              color: const Color(0xFFE4405F),
                            ),
                          ],
                        ),

                        const SizedBox(height: 20),

                        // ─── FOOTER ──────────────────────────────
                        const Text(
                          "© 2026 NOVZX PROJECT",
                          style: TextStyle(
                            color: Color(0xFF6B7280),
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 1.5,
                          ),
                        ),
                        const SizedBox(height: 16),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── LOGO CARD ─────────────────────────────────────────────
  Widget _buildLogoCard() {
    return Container(
      width: 110,
      height: 110,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: surfaceColor,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: borderColor, width: 2),
        boxShadow: const [
          BoxShadow(color: borderColor, offset: Offset(5, 5)),
          BoxShadow(
            color: Color(0x6600A8FF),
            blurRadius: 28,
            spreadRadius: 2,
          ),
          BoxShadow(
            color: Color(0x33FFFFFF),
            blurRadius: 14,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Image.network(
          bannerUrl,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => Container(
            decoration: BoxDecoration(
              color: softBlue,
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Center(
              child: Icon(Icons.shield_rounded,
                  color: Color(0xFF2563EB), size: 44),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSocialChip({
    required IconData icon,
    required String label,
    required String url,
    required Color color,
  }) {
    return GestureDetector(
      onTap: () async {
        await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: surfaceColor,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: borderColor, width: 1.6),
          boxShadow: const [
            BoxShadow(color: borderColor, offset: Offset(2, 2)),
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 12),
            const SizedBox(width: 6),
            Text(
              label,
              style: const TextStyle(
                color: Color(0xFF0A0A0A),
                fontSize: 10,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── INPUT FIELD (putih + border hitam tegas) ───────────────
  Widget _buildInput(
    TextEditingController controller,
    String label,
    IconData icon,
    bool isPassword,
  ) {
    return Container(
      decoration: BoxDecoration(
        color: surfaceColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderColor, width: 2),
        boxShadow: const [
          BoxShadow(color: borderColor, offset: Offset(3, 3)),
        ],
      ),
      child: TextFormField(
        controller: controller,
        obscureText: isPassword ? _obscurePassword : false,
        style: const TextStyle(
          color: Color(0xFF0A0A0A),
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
        cursorColor: primaryColor,
        decoration: InputDecoration(
          hintText: label,
          hintStyle: const TextStyle(
            color: Color(0xFF6B7280),
            fontSize: 13,
            fontWeight: FontWeight.w500,
          ),
          prefixIcon: Icon(icon, color: primaryColor, size: 18),
          suffixIcon: isPassword
              ? IconButton(
                  icon: Icon(
                    _obscurePassword
                        ? Icons.visibility_off_rounded
                        : Icons.visibility_rounded,
                    color: const Color(0xFF6B7280),
                    size: 18,
                  ),
                  onPressed: () =>
                      setState(() => _obscurePassword = !_obscurePassword),
                )
              : null,
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) return "$label tidak boleh kosong";
          return null;
        },
      ),
    );
  }

  // ─── TOMBOL SIGN IN (biru royal + border hitam + shadow) ────
  Widget _buildButton() {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 600),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - value)),
            child: child,
          ),
        );
      },
      child: SizedBox(
        width: double.infinity,
        height: 52,
        child: GestureDetector(
          onTap: isLoading ? null : login,
          child: Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF2563EB), Color(0xFF3B82F6)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: borderColor, width: 2),
              boxShadow: const [
                BoxShadow(color: borderColor, offset: Offset(4, 4)),
                BoxShadow(
                  color: Color(0x6600A8FF),
                  blurRadius: 22,
                  spreadRadius: 2,
                ),
                BoxShadow(
                  color: Color(0x33FFFFFF),
                  blurRadius: 10,
                ),
              ],
            ),
            child: Center(
              child: isLoading
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                        strokeWidth: 2.5,
                        color: Colors.white,
                      ),
                    )
                  : const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Sign in",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 15,
                            fontWeight: FontWeight.w800,
                            letterSpacing: 2,
                          ),
                        ),
                        SizedBox(width: 10),
                        Icon(Icons.arrow_forward_rounded,
                            color: Colors.white, size: 18),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
// NEON SPACE PAINTER — bintang, garis, glow, asteroid
// ═══════════════════════════════════════════════════════════════════════
class _NeonSpacePainter extends CustomPainter {
  final double progress; // 0.0 → 1.0, berulang
  final Color neonBlue;
  final Color neonCyan;
  final Color neonWhite;

  _NeonSpacePainter({
    required this.progress,
    required this.neonBlue,
    required this.neonCyan,
    required this.neonWhite,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final random = math.Random(7);
    final w = size.width;
    final h = size.height;

    // ─── 1. BINTANG KECIL BERTERBANGAN (starfield) ───
    for (int i = 0; i < 70; i++) {
      final bx = random.nextDouble() * w;
      final by = random.nextDouble() * h;
      final phase = random.nextDouble() * 2 * math.pi;
      final speed = 0.5 + random.nextDouble() * 1.5;
      final twinkle = (math.sin(progress * 2 * math.pi * speed + phase) + 1) / 2;
      final r = 0.6 + random.nextDouble() * 1.6;
      final driftX = math.sin(progress * 2 * math.pi * 0.3 + phase) * 12;
      final driftY = math.cos(progress * 2 * math.pi * 0.25 + phase) * 10;
      final c = i % 2 == 0 ? neonBlue : neonWhite;
      final paint = Paint()
        ..color = c.withOpacity(0.35 + twinkle * 0.55)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(bx + driftX, by + driftY), r, paint);
      // halo kecil
      final halo = Paint()
        ..color = c.withOpacity(0.08 + twinkle * 0.12)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(bx + driftX, by + driftY), r * 4, halo);
    }

    // ─── 2. GARIS-GARIS NEON (streaks diagonal) ───
    final linePaint = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    for (int i = 0; i < 8; i++) {
      final startX = -w * 0.3 + (i * w * 0.2) + progress * w * 0.6;
      final startY = h * (0.05 + i * 0.11);
      final endX = startX + w * 0.35;
      final endY = startY + h * 0.12;
      linePaint
        ..color = (i % 2 == 0 ? neonBlue : neonCyan).withOpacity(0.18)
        ..strokeWidth = 1.2;
      canvas.drawLine(Offset(startX, startY), Offset(endX, endY), linePaint);

      // glow tipis
      linePaint
        ..color = neonWhite.withOpacity(0.08)
        ..strokeWidth = 3.5;
      canvas.drawLine(Offset(startX, startY), Offset(endX, endY), linePaint);
    }

    // ─── 3. GLOW PUTIH LEWAT KE SAMPING ───
    final glowX = -w * 0.4 + progress * w * 1.8;
    final glowY = h * 0.5;
    final glowRect = Rect.fromCircle(
      center: Offset(glowX, glowY),
      radius: w * 0.35,
    );
    final glowPaint = Paint()
      ..shader = RadialGradient(
        colors: [
          neonWhite.withOpacity(0.35),
          neonWhite.withOpacity(0.08),
          Colors.transparent,
        ],
      ).createShader(glowRect);
    canvas.drawCircle(Offset(glowX, glowY), w * 0.35, glowPaint);

    // ─── 4. ASTEROID LEWAT 3 KALI ───
    // Setiap asteroid punya offset fase berbeda
    for (int a = 0; a < 3; a++) {
      final phaseOffset = a * 0.33; // 0.0, 0.33, 0.66
      final local = (progress + phaseOffset) % 1.0;
      final ax = -w * 0.2 + local * w * 1.4;
      final ay = h * 0.15 + (a * h * 0.3) + math.sin(local * math.pi * 2) * 30;
      final asteroidRadius = 6.0 + a * 2.0;

      // Trail glow
      final trailPaint = Paint()
        ..shader = LinearGradient(
          colors: [
            Colors.transparent,
            neonCyan.withOpacity(0.4),
            neonWhite.withOpacity(0.6),
          ],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ).createShader(Rect.fromLTWH(
            ax - 60, ay - asteroidRadius, 60, asteroidRadius * 2));
      canvas.drawRect(
        Rect.fromLTWH(ax - 60, ay - 1, 60, 2),
        trailPaint,
      );

      // Inti asteroid
      final corePaint = Paint()
        ..color = neonWhite.withOpacity(0.9)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(ax, ay), asteroidRadius, corePaint);

      // Halo asteroid
      final haloPaint = Paint()
        ..color = neonCyan.withOpacity(0.4)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(ax, ay), asteroidRadius * 2.4, haloPaint);

      // Spark kecil
      final sparkPaint = Paint()
        ..color = neonBlue.withOpacity(0.7)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(
          Offset(ax - 4, ay + 3), asteroidRadius * 0.4, sparkPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _NeonSpacePainter oldDelegate) {
    return oldDelegate.progress != progress;
  }
}