import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class GlobalSenderPage extends StatefulWidget {
  final String sessionKey;
  const GlobalSenderPage({super.key, required this.sessionKey});

  @override
  State<GlobalSenderPage> createState() => _GlobalSenderPageState();
}

class _GlobalSenderPageState extends State<GlobalSenderPage>
    with TickerProviderStateMixin {
  static const String baseUrl = "http://raulllll.panelantirusuh.biz.id:10361";

  List<Map<String, dynamic>> _globalSessions = [];
  bool _isLoading = false;
  String? _errorMsg;

  final TextEditingController _pairingNumberCtrl = TextEditingController();
  bool _isPairing = false;
  String? _pairingCode;
  String? _pairingStatus;
  Timer? _pairingTimer;
  int _pairingCountdown = 60;
  Timer? _countdownTimer;

  String? _deletingSession;

  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  late VideoPlayerController _backgroundVideoController;
  bool _backgroundVideoInitialized = false;

  // ====== NEON BLUE LIGHT THEME (BLACK BASE) ======
  final Color primaryColor = const Color(0xFF00B0FF);
  final Color accentColor = const Color(0xFF00B0FF);
  final Color backgroundColor = const Color(0xFF000000);
  final Color surfaceColor = const Color(0xFF050B1A);
  final Color cardColor = const Color(0xFF0F2547);
  final Color textPrimary = Colors.white;
  final Color textSecondary = const Color(0xFFB3E5FC);

  // White glow helper (dual shadow)
  List<BoxShadow> neonGlow({
    Color color = const Color(0xFF00B0FF),
    double blur = 16,
    double spread = 1.5,
    double opacity = 0.55,
  }) {
    return [
      BoxShadow(
        color: color.withOpacity(opacity),
        blurRadius: blur,
        spreadRadius: spread,
      ),
      BoxShadow(
        color: Colors.white.withOpacity(0.18),
        blurRadius: blur * 0.6,
        spreadRadius: 0.5,
      ),
    ];
  }

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.7, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
    _fetchGlobalSessions();
    _initBackgroundVideo();
  }

  void _initBackgroundVideo() {
    _backgroundVideoController =
        VideoPlayerController.asset('assets/videos/splash.mp4')
          ..initialize().then((_) {
            if (mounted) {
              setState(() => _backgroundVideoInitialized = true);
              _backgroundVideoController.setLooping(true);
              _backgroundVideoController.setVolume(0);
              _backgroundVideoController.play();
            }
          }).catchError((error) {
            debugPrint("Background video error: $error");
          });
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _pairingNumberCtrl.dispose();
    _pairingTimer?.cancel();
    _countdownTimer?.cancel();
    _backgroundVideoController.dispose();
    super.dispose();
  }

  // ─── FETCH ───────────────────────────────────────────────
  Future<void> _fetchGlobalSessions() async {
    setState(() => _isLoading = true);
    try {
      final res = await http
          .get(Uri.parse("$baseUrl/mySender?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data["valid"] == true) {
        setState(() {
          _globalSessions = List<Map<String, dynamic>>.from(
              data["globalConnections"] ?? []);
          _errorMsg = null;
        });
      } else {
        setState(() => _errorMsg = "Gagal memuat global sender.");
      }
    } catch (e) {
      setState(() => _errorMsg = "Koneksi gagal: $e");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  // ─── PAIRING ─────────────────────────────────────────────
  Future<void> _startPairing() async {
    final number =
        _pairingNumberCtrl.text.trim().replaceAll(RegExp(r'\D'), '');
    if (number.isEmpty) {
      _showSnack("Masukkan nomor WA dulu!", isError: true);
      return;
    }
    if (number.length < 10 || number.length > 15) {
      _showSnack("Nomor tidak valid! Contoh: 6281234567890", isError: true);
      return;
    }

    setState(() {
      _isPairing = true;
      _pairingCode = null;
      _pairingStatus = "Meminta pairing code...";
      _pairingCountdown = 60;
    });

    try {
      final res = await http.post(
        Uri.parse("$baseUrl/pairingGlobal"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "key": widget.sessionKey,
          "number": number,
        }),
      ).timeout(const Duration(seconds: 20));

      final data = jsonDecode(res.body);

      if (data["valid"] == true || data["pairingCode"] != null) {
        final code = data["pairingCode"]?.toString() ?? "";
        setState(() {
          _pairingCode = code;
          _pairingStatus = "Pairing code berhasil didapat!";
        });
        _startPairingCountdown(number);
      } else {
        setState(() {
          _isPairing = false;
          _pairingStatus = data["message"] ?? "Gagal mendapat pairing code.";
        });
        _showSnack(_pairingStatus!, isError: true);
      }
    } catch (e) {
      setState(() {
        _isPairing = false;
        _pairingStatus = "Error: $e";
      });
      _showSnack("Koneksi gagal!", isError: true);
    }
  }

  void _startPairingCountdown(String number) {
    _countdownTimer?.cancel();
    _countdownTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      setState(() => _pairingCountdown--);
      if (_pairingCountdown <= 0) {
        t.cancel();
        _checkPairingStatus(number);
      }
    });
  }

  Future<void> _checkPairingStatus(String number) async {
    try {
      final res = await http
          .get(Uri.parse("$baseUrl/mySender?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data["valid"] == true) {
        final globals = List<Map<String, dynamic>>.from(
            data["globalConnections"] ?? []);
        final connected = globals.any((s) =>
            (s["number"]?.toString() ?? "").contains(number) ||
            (s["id"]?.toString() ?? "").contains(number));

        if (connected) {
          setState(() {
            _isPairing = false;
            _pairingCode = null;
            _pairingStatus = "✅ Sender berhasil terhubung!";
            _globalSessions = globals;
          });
          _showSnack("Global sender berhasil ditambahkan!", isError: false);
          _pairingNumberCtrl.clear();
        } else {
          setState(() {
            _isPairing = false;
            _pairingStatus = "⚠️ Pairing belum selesai. Coba lagi.";
          });
          _showSnack("Pairing belum terdeteksi, coba ulangi.", isError: true);
        }
      }
    } catch (_) {
      setState(() {
        _isPairing = false;
        _pairingStatus = "Gagal cek status.";
      });
    }
    await _fetchGlobalSessions();
  }

  // ─── DELETE ──────────────────────────────────────────────
  Future<void> _deleteSession(String sessionName) async {
    setState(() => _deletingSession = sessionName);
    try {
      final res = await http.delete(
        Uri.parse("$baseUrl/removeGlobalSender"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "key": widget.sessionKey,
          "sessionName": sessionName,
        }),
      ).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data["valid"] == true) {
        _showSnack("Sender dihapus!", isError: false);
        await _fetchGlobalSessions();
      } else {
        _showSnack(data["error"] ?? "Gagal hapus sender.", isError: true);
      }
    } catch (e) {
      _showSnack("Error: $e", isError: true);
    } finally {
      setState(() => _deletingSession = null);
    }
  }

  void _showSnack(String msg, {required bool isError}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white)),
      backgroundColor: isError ? Colors.red.shade700 : Colors.green.shade700,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 3),
    ));
  }

  // ─── BUILD ────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: primaryColor.withOpacity(0.45)),
              boxShadow: neonGlow(blur: 8, spread: 0.3, opacity: 0.35),
            ),
            child:
                Icon(Icons.arrow_back_ios_new, color: accentColor, size: 18),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [primaryColor, accentColor]),
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: primaryColor.withOpacity(0.6),
                blurRadius: 16,
                spreadRadius: 1,
              ),
              BoxShadow(
                color: Colors.white.withOpacity(0.2),
                blurRadius: 8,
              ),
            ],
          ),
          child: const Text(
            'GLOBAL SENDER',
            style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: primaryColor.withOpacity(0.45)),
              boxShadow: neonGlow(blur: 8, spread: 0.3, opacity: 0.35),
            ),
            child: IconButton(
              icon: Icon(Icons.refresh_rounded, color: accentColor),
              onPressed: _fetchGlobalSessions,
              tooltip: 'Refresh',
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          if (_backgroundVideoInitialized)
            SizedBox(
              width: double.infinity,
              height: double.infinity,
              child: VideoPlayer(_backgroundVideoController),
            )
          else
            Container(color: backgroundColor),

          // Overlay biru neon gelap
          Container(
            color: const Color(0xFF001028).withOpacity(0.6),
          ),

          RefreshIndicator(
            color: accentColor,
            backgroundColor: surfaceColor,
            onRefresh: _fetchGlobalSessions,
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildInfoCard(),
                  const SizedBox(height: 20),
                  _buildPairingSection(),
                  const SizedBox(height: 20),
                  _buildSenderList(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── INFO CARD ────────────────────────────────────────────
  Widget _buildInfoCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: primaryColor.withOpacity(0.45)),
        boxShadow: neonGlow(blur: 14, spread: 0.5, opacity: 0.35),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [primaryColor, accentColor]),
              shape: BoxShape.circle,
              boxShadow: neonGlow(opacity: 0.6),
            ),
            child:
                const Icon(Icons.public_rounded, color: Colors.white, size: 22),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Global Sender',
                  style: TextStyle(
                    color: accentColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    shadows: [
                      Shadow(
                        color: accentColor.withOpacity(0.5),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Sender yang bisa dipakai semua user VIP untuk ngebug. Pairing WA ke slot global di sini.',
                  style: TextStyle(
                      color: textSecondary, fontSize: 12, height: 1.4),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── PAIRING SECTION ─────────────────────────────────────
  Widget _buildPairingSection() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: surfaceColor,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: primaryColor.withOpacity(0.45)),
        boxShadow: neonGlow(blur: 16, spread: 0.8, opacity: 0.35),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.add_link_rounded, color: accentColor, size: 18),
              const SizedBox(width: 8),
              Text(
                'TAMBAH SENDER BARU',
                style: TextStyle(
                  color: accentColor,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                  shadows: [
                    Shadow(
                      color: accentColor.withOpacity(0.4),
                      blurRadius: 8,
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          Container(
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: primaryColor.withOpacity(0.45)),
              boxShadow: neonGlow(blur: 10, spread: 0.5, opacity: 0.35),
            ),
            child: TextField(
              controller: _pairingNumberCtrl,
              keyboardType: TextInputType.phone,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              enabled: !_isPairing,
              style: const TextStyle(color: Colors.white, fontSize: 14),
              cursorColor: accentColor,
              decoration: InputDecoration(
                hintText: 'Nomor WA (contoh: 6281234567890)',
                hintStyle: TextStyle(
                    color: textSecondary.withOpacity(0.6), fontSize: 13),
                prefixIcon: Icon(Icons.phone_android_rounded,
                    color: accentColor, size: 20),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16, vertical: 14),
              ),
            ),
          ),
          const SizedBox(height: 12),

          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _isPairing ? null : _startPairing,
              icon: _isPairing
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : const Icon(Icons.qr_code_rounded, size: 18),
              label: Text(
                  _isPairing ? 'Menghubungkan...' : 'Dapatkan Pairing Code'),
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryColor,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
                elevation: 0,
                shadowColor: primaryColor.withOpacity(0.6),
              ),
            ),
          ),

          if (_pairingCode != null && _isPairing) ...[
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: primaryColor.withOpacity(0.15),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: accentColor.withOpacity(0.55)),
                boxShadow: neonGlow(blur: 16, spread: 0.8, opacity: 0.45),
              ),
              child: Column(
                children: [
                  Text(
                    'PAIRING CODE',
                    style: TextStyle(
                      color: accentColor,
                      fontSize: 11,
                      letterSpacing: 2,
                      fontWeight: FontWeight.bold,
                      shadows: [
                        Shadow(
                          color: accentColor.withOpacity(0.6),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  GestureDetector(
                    onTap: () {
                      Clipboard.setData(
                          ClipboardData(text: _pairingCode!));
                      _showSnack("Kode disalin!", isError: false);
                    },
                    child: AnimatedBuilder(
                      animation: _pulseAnim,
                      builder: (_, child) =>
                          Opacity(opacity: _pulseAnim.value, child: child),
                      child: Text(
                        _pairingCode!,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 6,
                          fontFamily: 'monospace',
                          shadows: [
                            Shadow(
                              color: Color(0xCC00E5FF),
                              blurRadius: 20,
                            ),
                            Shadow(
                              color: Colors.white54,
                              blurRadius: 10,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Buka WA → Perangkat Tertaut → Tautkan Perangkat → Masukkan kode',
                    style: TextStyle(
                        color: textSecondary, fontSize: 11, height: 1.4),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: _pairingCountdown / 60,
                    backgroundColor: Colors.white10,
                    valueColor: AlwaysStoppedAnimation<Color>(accentColor),
                    borderRadius: BorderRadius.circular(4),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Sisa waktu: ${_pairingCountdown}s',
                    style: TextStyle(color: textSecondary, fontSize: 11),
                  ),
                ],
              ),
            ),
          ],

          if (_pairingStatus != null && _pairingCode == null) ...[
            const SizedBox(height: 12),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: cardColor,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: primaryColor.withOpacity(0.45)),
                boxShadow: neonGlow(blur: 8, spread: 0.3, opacity: 0.3),
              ),
              child: Row(
                children: [
                  Icon(
                    _pairingStatus!.startsWith('✅')
                        ? Icons.check_circle
                        : Icons.info_outline,
                    color: _pairingStatus!.startsWith('✅')
                        ? Colors.green
                        : accentColor,
                    size: 16,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      _pairingStatus!,
                      style:
                          TextStyle(color: textSecondary, fontSize: 12),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ─── SENDER LIST ─────────────────────────────────────────
  Widget _buildSenderList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(Icons.sensors_rounded, color: accentColor, size: 18),
            const SizedBox(width: 8),
            Text(
              'GLOBAL SENDER AKTIF',
              style: TextStyle(
                color: accentColor,
                fontSize: 11,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
                shadows: [
                  Shadow(
                    color: accentColor.withOpacity(0.4),
                    blurRadius: 8,
                  ),
                ],
              ),
            ),
            const Spacer(),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: primaryColor.withOpacity(0.18),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: primaryColor.withOpacity(0.45)),
                boxShadow: neonGlow(blur: 8, spread: 0.3, opacity: 0.4),
              ),
              child: Text(
                '${_globalSessions.length} sender',
                style: TextStyle(
                    color: accentColor,
                    fontSize: 11,
                    fontWeight: FontWeight.bold),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        if (_isLoading)
          Center(
            child: Padding(
              padding: const EdgeInsets.all(40),
              child: CircularProgressIndicator(
                  color: accentColor, strokeWidth: 2),
            ),
          )
        else if (_errorMsg != null)
          _buildEmptyState(_errorMsg!, isError: true)
        else if (_globalSessions.isEmpty)
          _buildEmptyState(
              'Belum ada global sender.\nTambahkan sender baru di atas.',
              isError: false)
        else
          ListView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _globalSessions.length,
            itemBuilder: (context, index) {
              final sender = _globalSessions[index];
              final name = sender["id"]?.toString() ??
                  sender["number"]?.toString() ??
                  "Sender ${index + 1}";
              final isActive = sender["connected"] == true ||
                  sender["status"] == "connected";
              final isDeleting = _deletingSession == name;

              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: cardColor,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: isActive
                        ? accentColor.withOpacity(0.55)
                        : primaryColor.withOpacity(0.35),
                  ),
                  boxShadow: isActive
                      ? neonGlow(blur: 12, spread: 0.5, opacity: 0.4)
                      : [
                          BoxShadow(
                            color: primaryColor.withOpacity(0.2),
                            blurRadius: 8,
                          ),
                          BoxShadow(
                            color: Colors.white.withOpacity(0.1),
                            blurRadius: 4,
                          ),
                        ],
                ),
                child: Row(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        gradient: isActive
                            ? LinearGradient(
                                colors: [primaryColor, accentColor])
                            : null,
                        color: isActive ? null : cardColor,
                        shape: BoxShape.circle,
                        boxShadow: isActive
                            ? neonGlow(opacity: 0.6)
                            : null,
                      ),
                      child: Icon(
                        Icons.phone_android_rounded,
                        color: isActive ? Colors.white : textSecondary,
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            name,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Row(
                            children: [
                              Container(
                                width: 6,
                                height: 6,
                                decoration: BoxDecoration(
                                  color: isActive
                                      ? Colors.green
                                      : Colors.red,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: (isActive
                                              ? Colors.green
                                              : Colors.red)
                                          .withOpacity(0.7),
                                      blurRadius: 6,
                                    ),
                                    BoxShadow(
                                      color:
                                          Colors.white.withOpacity(0.3),
                                      blurRadius: 3,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 5),
                              Text(
                                isActive ? 'Terhubung' : 'Terputus',
                                style: TextStyle(
                                  color:
                                      isActive ? Colors.green : Colors.red,
                                  fontSize: 11,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 7, vertical: 2),
                                decoration: BoxDecoration(
                                  color: primaryColor.withOpacity(0.18),
                                  borderRadius: BorderRadius.circular(6),
                                  border: Border.all(
                                      color: primaryColor
                                          .withOpacity(0.45)),
                                  boxShadow: neonGlow(
                                      blur: 6,
                                      spread: 0.3,
                                      opacity: 0.4),
                                ),
                                child: Text(
                                  'GLOBAL',
                                  style: TextStyle(
                                    color: accentColor,
                                    fontSize: 9,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    isDeleting
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.red,
                            ),
                          )
                        : IconButton(
                            icon: const Icon(
                                Icons.delete_outline_rounded,
                                color: Colors.red,
                                size: 20),
                            onPressed: () => _confirmDelete(context, name),
                            tooltip: 'Hapus sender',
                          ),
                  ],
                ),
              );
            },
          ),
      ],
    );
  }

  void _confirmDelete(BuildContext context, String name) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: primaryColor.withOpacity(0.5), width: 1),
        ),
        title: Row(
          children: [
            const Icon(Icons.warning_amber_rounded,
                color: Colors.red, size: 22),
            const SizedBox(width: 10),
            Text('Hapus Sender?',
                style: TextStyle(color: textPrimary, fontSize: 16)),
          ],
        ),
        content: Text(
          'Sender "$name" akan dihapus dari slot global.',
          style: TextStyle(color: textSecondary, fontSize: 13),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Batal', style: TextStyle(color: textSecondary)),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _deleteSession(name);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState(String msg, {required bool isError}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: primaryColor.withOpacity(0.45)),
        boxShadow: neonGlow(blur: 12, spread: 0.5, opacity: 0.3),
      ),
      child: Column(
        children: [
          Icon(
            isError ? Icons.error_outline_rounded : Icons.sensors_off_rounded,
            color: isError ? Colors.red : textSecondary.withOpacity(0.5),
            size: 40,
          ),
          const SizedBox(height: 12),
          Text(
            msg,
            style: TextStyle(
                color: textSecondary.withOpacity(0.7),
                fontSize: 13,
                height: 1.5),
            textAlign: TextAlign.center,
          ),
          if (isError) ...[
            const SizedBox(height: 16),
            ElevatedButton.icon(
              onPressed: _fetchGlobalSessions,
              icon: const Icon(Icons.refresh_rounded, size: 16),
              label: const Text('Coba Lagi'),
              style: ElevatedButton.styleFrom(
                backgroundColor: primaryColor,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
            ),
          ],
        ],
      ),
    );
  }
}