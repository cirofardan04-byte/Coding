import 'dart:ui';
import 'dart:convert';
import 'dart:io';
import 'dart:async';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:flutter/services.dart';

import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'ucapan_page.dart';
import 'public_chat_page.dart';
import 'whatsapp_page.dart';
import 'dominos_page.dart';
import 'tools_page.dart'; // ← TAMBAHAN BARU

import 'device_dashboard.dart';
import 'youtube_tool.dart';
import 'minibrowser_tool.dart';
import 'comic.dart';

// ─── Prayer Time & Location Service ─────────────────────────────────────────
class PrayerTimeService {
  static Future<Map<String, dynamic>> fetchPrayerTimes(String city) async {
    final now = DateTime.now();
    final uri = Uri.https('api.aladhan.com', '/v1/timingsByCity', {
      'city': city, 'country': 'ID', 'method': '11',
      'day': '${now.day}', 'month': '${now.month}', 'year': '${now.year}',
    });
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return {};
  }

  static Future<String> detectLocationByGPS() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        return await detectLocationByIP();
      }
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          return await detectLocationByIP();
        }
      }
      if (permission == LocationPermission.deniedForever) {
        return await detectLocationByIP();
      }
      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      ).timeout(const Duration(seconds: 15));
      final placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );
      if (placemarks.isNotEmpty) {
        final place = placemarks.first;
        final city = (place.subAdministrativeArea?.isNotEmpty == true)
            ? place.subAdministrativeArea!
            : (place.administrativeArea?.isNotEmpty == true)
                ? place.administrativeArea!
                : 'Jakarta';
        return city;
      }
    } catch (e) {}
    return await detectLocationByIP();
  }

  static Future<String> detectLocationByIP() async {
    try {
      final response = await http.get(
        Uri.parse('http://ip-api.com/json/'),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == 'success') {
          String city = data['city'] ?? '';
          if (city.isNotEmpty) return city;
        }
      }
    } catch (e) {}
    try {
      final response = await http.get(
        Uri.parse('https://ipapi.co/json/'),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        String city = data['city'] ?? '';
        if (city.isNotEmpty) return city;
      }
    } catch (e) {}
    return 'Jakarta';
  }
}

// ─── ANIMATED DOT ────────────────────────────────────────────────────────────
class _AnimatedDot extends StatefulWidget {
  final Color color;
  final double size;
  const _AnimatedDot({required this.color, this.size = 6});
  @override
  State<_AnimatedDot> createState() => _AnimatedDotState();
}

class _AnimatedDotState extends State<_AnimatedDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }
  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) => FadeTransition(
        opacity: _a,
        child: Container(
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: widget.color,
            boxShadow: [
              BoxShadow(
                  color: widget.color.withOpacity(0.6),
                  blurRadius: 6,
                  spreadRadius: 1),
            ],
          ),
        ),
      );
}

// ─── 3D BUBBLE PAINTER ──────────────────────────────────────────────────────
class _DashboardBubblePainter3D extends CustomPainter {
  final Color color;
  final int count;
  final Animation<double> animation;

  _DashboardBubblePainter3D({
    required this.color,
    required this.count,
    required this.animation,
  }) : super(repaint: animation);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    final random = math.Random(42);
    final time = animation.value * 2 * math.pi;

    for (int i = 0; i < count; i++) {
      final baseX = (random.nextDouble() + i * 0.08) % 1.0;
      final baseY = (random.nextDouble() + i * 0.12) % 1.0;
      final radius = 10 + (random.nextDouble() + i * 0.015) % 30;

      final floatX = math.sin(time + i * 0.7) * 0.05;
      final floatY = math.cos(time * 0.6 + i * 0.5) * 0.05;

      final x = (baseX + floatX) * size.width;
      final y = (baseY + floatY) * size.height;

      final depth = 1.0 - (y / size.height) * 0.5;
      final opacity =
          (0.015 + (random.nextDouble() + i * 0.005) % 0.05) * depth;
      paint.color = color.withOpacity(opacity);

      final shadowPaint = Paint()
        ..color = Colors.black.withOpacity(0.02 * depth)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(x + 3, y + 4), radius * 0.9, shadowPaint);

      canvas.drawCircle(Offset(x, y), radius, paint);

      final highlightPaint = Paint()
        ..color = Colors.white.withOpacity(
            (0.01 + (random.nextDouble() + i * 0.003) % 0.015) * depth)
        ..style = PaintingStyle.fill;

      canvas.drawCircle(
        Offset(x - radius * 0.3, y - radius * 0.35),
        radius * 0.2,
        highlightPaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _DashboardBubblePainter3D oldDelegate) {
    return oldDelegate.animation != animation;
  }
}

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late AnimationController _bubbleAnimationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late WebSocketChannel? _channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const SizedBox();
  Widget _toolsPage = const SizedBox(); // ← TAMBAHAN BARU

  int onlineUsers = 0;
  int activeConnections = 0;
  int _batteryLevel = 0;

  Timer? _statsTimer;
  Timer? _onlineTimer;
  Timer? _clockTimer;
  Timer? _serverTimer;
  Timer? _digitalClockTimer;

  String _currentDateTime = "";

  // ── Digital clock & server status ──
  bool _serverOnline = false;
  String _digitalTime = '00:00:00';
  String _digitalDate = '';

  // ====== NEON BLUE LIGHT THEME (BLACK BASE) ======
  final Color primaryColor = const Color(0xFF00B0FF);
  final Color accentColor = const Color(0xFF00B0FF);
  final Color glowColor = const Color(0xFF80D8FF);
  final Color backgroundColor = const Color(0xFF000000);
  final Color surfaceColor = const Color(0xFF050B1A);
  final Color cardColor = const Color(0xFF0F2547);
  final Color textPrimary = Colors.white;
  final Color textSecondary = const Color(0xFFB3E5FC);

  List<BoxShadow> neonGlow({
    Color color = const Color(0xFF00B0FF),
    double blur = 16,
    double spread = 1.5,
    double opacity = 0.55,
  }) {
    return [
      BoxShadow(
        color: color.withOpacity(opacity),
        blurRadius: blur,
        spreadRadius: spread,
      ),
      BoxShadow(
        color: Colors.white.withOpacity(0.18),
        blurRadius: blur * 0.6,
        spreadRadius: 0.5,
      ),
    ];
  }

  // Animasi button floating
  late AnimationController _buttonPulseController;
  late Animation<double> _buttonPulseAnimation;

  // ── Quick Action Page Controller ──────────────────────
  late PageController _qaPageController;
  double _currentQaPage = 0.0;

  // ── Prayer times ──
  bool _detectingLocation = false;
  String _prayerCity = 'Jakarta';
  Map<String, String> _prayerTimes = {};
  String _nextPrayerLabel = '';
  String _nextPrayerTime = '';
  bool _prayerLoading = true;

  // ── Hadith ──
  Map<String, dynamic>? _hadith;
  bool _hadithLoading = true;
  int _lastHadithNumber = 0;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role.toLowerCase();
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    newsList = widget.news;

    _initAnimations();
    _initButtonAnimation();
    _initAndroidIdAndConnect();
    _initBatteryLevel();
    _loadProfileImage();
    _startStatsTimer();

    _fetchOnlineUsers();
    _startOnlinePolling();
    _startClock();
    _startDigitalClock();
    _startServerCheck();

    _qaPageController =
        PageController(viewportFraction: 0.88, initialPage: 0);
    _qaPageController.addListener(() {
      if (mounted) {
        setState(() => _currentQaPage = _qaPageController.page ?? 0.0);
      }
    });

    _bubbleAnimationController = AnimationController(
      duration: const Duration(seconds: 10),
      vsync: this,
    )..repeat();

    _autoDetectLocationAndFetchPrayer();
    _fetchRandomHadith();
  }

  void _initAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    )..forward();

    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOutCubic,
      ),
    );
  }

  void _initButtonAnimation() {
    _buttonPulseController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );
    _buttonPulseAnimation = Tween<double>(begin: 1.0, end: 1.05).animate(
      CurvedAnimation(parent: _buttonPulseController, curve: Curves.easeInOut),
    );
    _buttonPulseController.repeat(reverse: true);
  }

  void _startStatsTimer() {
    _statsTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (_channel != null) {
        _channel?.sink.add(jsonEncode({"type": "stats"}));
      }
    });
  }

  Future<void> _fetchOnlineUsers() async {
    try {
      final response = await http.get(
        Uri.parse(
            'http://raulllll.panelantirusuh.biz.id:10361/getOnlineUsers?key=$sessionKey'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          if (!mounted) return;
          setState(() {
            onlineUsers = data['count'] ?? 0;
          });
        }
      }
    } catch (e) {
      debugPrint('Error fetching online users: $e');
    }
  }

  void _startOnlinePolling() {
    _onlineTimer = Timer.periodic(const Duration(seconds: 10), (timer) {
      _fetchOnlineUsers();
    });
  }

  void _startClock() {
    _updateDateTime();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      _updateDateTime();
    });
  }

  void _updateDateTime() {
    final now = DateTime.now();
    final time = "${now.hour.toString().padLeft(2, '0')}:"
        "${now.minute.toString().padLeft(2, '0')}:"
        "${now.second.toString().padLeft(2, '0')}";
    final date = "${now.day.toString().padLeft(2, '0')}/"
        "${now.month.toString().padLeft(2, '0')}/"
        "${now.year}";
    final formatted = "$time • $date";
    if (mounted) {
      setState(() {
        _currentDateTime = formatted;
      });
    }
  }

  void _startDigitalClock() {
    _updateDigitalClock();
    _digitalClockTimer =
        Timer.periodic(const Duration(seconds: 1), (_) => _updateDigitalClock());
  }

  void _updateDigitalClock() {
    final now = DateTime.now();
    if (!mounted) return;
    setState(() {
      _digitalTime = "${now.hour.toString().padLeft(2, '0')}:"
          "${now.minute.toString().padLeft(2, '0')}:"
          "${now.second.toString().padLeft(2, '0')}";
      _digitalDate = "${now.day.toString().padLeft(2, '0')}/"
          "${now.month.toString().padLeft(2, '0')}/"
          "${now.year}";
    });
  }

  void _startServerCheck() {
    _checkServer();
    _serverTimer =
        Timer.periodic(const Duration(seconds: 15), (_) => _checkServer());
  }

  Future<void> _checkServer() async {
    try {
      final res = await http
          .get(Uri.parse('http://raulllll.panelantirusuh.biz.id:10361/'))
          .timeout(const Duration(seconds: 5));
      if (!mounted) return;
      setState(() => _serverOnline = res.statusCode < 500);
    } catch (_) {
      if (!mounted) return;
      setState(() => _serverOnline = false);
    }
  }

  Future<void> _initBatteryLevel() async {
    try {
      final battery = await MethodChannel('samples.flutter.dev/battery')
          .invokeMethod('getBatteryLevel');
      if (mounted) {
        setState(() => _batteryLevel = battery as int);
      }
    } catch (e) {
      setState(() => _batteryLevel = 0);
    }
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  // ─── THANKS TO DIALOG ────────────────────────────────────────────────────
  void _showThanksToDialog() {
    showDialog(
      context: context,
      barrierDismissible: true,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        elevation: 0,
        child: Container(
          width: MediaQuery.of(context).size.width * 0.92,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                const Color(0xFF050B1A),
                const Color(0xFF0F2547),
                const Color(0xFF050B1A),
              ],
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(
              color: accentColor.withOpacity(0.4),
              width: 1.5,
            ),
            boxShadow: [
              ...neonGlow(opacity: 0.5),
              BoxShadow(
                color: Colors.black.withOpacity(0.8),
                blurRadius: 30,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(vertical: 28),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [primaryColor, primaryColor.withOpacity(0.7)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(28),
                  ),
                ),
                child: Column(
                  children: [
                    TweenAnimationBuilder(
                      duration: const Duration(milliseconds: 1500),
                      tween: Tween<double>(begin: 1.0, end: 1.2),
                      builder: (context, double scale, child) {
                        return Transform.scale(
                          scale: scale,
                          child: Container(
                            padding: const EdgeInsets.all(18),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [primaryColor, accentColor],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              shape: BoxShape.circle,
                              boxShadow: neonGlow(opacity: 0.6),
                            ),
                            child: const Icon(
                              Icons.favorite_rounded,
                              color: Colors.white,
                              size: 34,
                            ),
                          ),
                        );
                      },
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      "THANKS TO",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 26,
                        fontWeight: FontWeight.w900,
                        letterSpacing: 5,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.15),
                        ),
                      ),
                      child: const Text(
                        "Thanks You For Support ❤️",
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Flexible(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      _buildThanksCategory(
                        title: "⭐ Developer",
                        icon: Icons.star_rounded,
                        members: ["Kaicho"],
                        isDeveloper: true,
                      ),
                      const SizedBox(height: 14),
                      _buildThanksCategory(
                        title: "🎁 My Friends",
                        icon: Icons.code_rounded,
                        members: [
                          "RxVz", "Angga", "AlannXD", "Yono",
                          "Arif", "Afif", "Hamxy", "Sanzy",
                          "Satz", "Whisper", "Kava"
                        ],
                      ),
                      const SizedBox(height: 14),
                      _buildThanksCategory(
                        title: "💕 My Girl",
                        icon: Icons.favorite_rounded,
                        members: ["Ayawww"],
                      ),
                      const SizedBox(height: 14),
                      _buildThanksCategory(
                        title: "🚀 Team NEVERLOUS PROJECT",
                        icon: Icons.rocket_launch_rounded,
                        members: ["RxVz", "Angga", "Yono", "Arif", "Kava"],
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
                child: GestureDetector(
                  onTap: () => Navigator.pop(context),
                  child: Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [primaryColor, accentColor],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: neonGlow(opacity: 0.6),
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.close_rounded,
                            color: Colors.white, size: 18),
                        SizedBox(width: 10),
                        Text(
                          "CLOSE",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w800,
                            fontSize: 14,
                            letterSpacing: 3,
                          ),
                        ),
                        SizedBox(width: 10),
                        Icon(Icons.close_rounded,
                            color: Colors.white, size: 18),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildThanksCategory({
    required String title,
    required IconData icon,
    required List<String> members,
    bool isDeveloper = false,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [surfaceColor, surfaceColor.withOpacity(0.5)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: accentColor.withOpacity(0.3),
          width: 1,
        ),
        boxShadow: neonGlow(blur: 10, spread: 0.5, opacity: 0.3),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [primaryColor.withOpacity(0.3), Colors.transparent],
                  begin: Alignment.centerLeft,
                ),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: accentColor.withOpacity(0.15),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(icon, color: accentColor, size: 16),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    title,
                    style: TextStyle(
                      color: isDeveloper ? accentColor : Color(0xFF00B0FF),
                      fontSize: 13,
                      fontWeight:
                          isDeveloper ? FontWeight.w900 : FontWeight.w700,
                      letterSpacing: 1,
                    ),
                  ),
                  if (isDeveloper) ...[
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 3,
                      ),
                      decoration: BoxDecoration(
                        color: accentColor.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: accentColor.withOpacity(0.4),
                        ),
                      ),
                      child: const Text(
                        "⭐",
                        style: TextStyle(fontSize: 10),
                      ),
                    ),
                  ],
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(14),
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: members.map((member) {
                  return Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 5,
                    ),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          accentColor.withOpacity(0.15),
                          primaryColor.withOpacity(0.1),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: accentColor.withOpacity(0.35),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          width: 5,
                          height: 5,
                          decoration: BoxDecoration(
                            color: isDeveloper ? accentColor : Color(0xFF00B0FF),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: (isDeveloper
                                        ? accentColor
                                        : Color(0xFF00B0FF))
                                    .withOpacity(0.6),
                                blurRadius: 6,
                              ),
                              BoxShadow(
                                color: Colors.white.withOpacity(0.2),
                                blurRadius: 3,
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          member,
                          style: TextStyle(
                            color: isDeveloper
                                ? accentColor
                                : Color(0xFF00B0FF),
                            fontSize: 12,
                            fontWeight: isDeveloper
                                ? FontWeight.w700
                                : FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    _channel =
        WebSocketChannel.connect(Uri.parse('http://raulllll.panelantirusuh.biz.id:10361'));
    _channel?.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));
    _channel?.sink.add(jsonEncode({"type": "stats"}));
    _channel?.sink.add(jsonEncode({"type": "get_online_users"}));

    _channel?.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Akun Anda masuk di perangkat lain.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Sesi tidak valid. Silakan login ulang.");
          }
        }
      }
      if (data['type'] == 'stats') {
        if (!mounted) return;
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: surfaceColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accentColor.withOpacity(0.4), width: 1.5),
        ),
        title: Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: accentColor, size: 24),
            const SizedBox(width: 12),
            const Text("Sesi Habis",
                style: TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w700)),
          ],
        ),
        content: Text(message, style: const TextStyle(color: Colors.grey)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              );
            },
            child: Text("OK", style: TextStyle(color: accentColor)),
          ),
        ],
      ),
    );
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        // Home
      } else if (index == 1) {
        _selectedPage = WhatsAppPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        );
      } else if (index == 2) {
        _selectedPage = DeviceDashboardPage(
          username: username,
          role: role,
          sessionKey: sessionKey,
        );
      } else if (index == 3) {
        _selectedPage = InfoPage(sessionKey: sessionKey);
      } else if (index == 4) {
        _toolsPage = ToolsPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        );
      }
    });
  }

  void _onSidebarTabSelected(int index) {
    Navigator.pop(context);
    Future.delayed(const Duration(milliseconds: 250), () {
      if (!mounted) return;
      if (index == 1) {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => SellerPage(keyToken: sessionKey)),
        );
      } else if (index == 2) {
        Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => AdminPage(sessionKey: sessionKey)),
        );
      } else if (index == 3) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => OwnerPage(
              sessionKey: sessionKey,
              username: username,
              currentUserRole: role,
            ),
          ),
        );
      }
    });
  }

  // ─── AUTO DETECT LOCATION ──────────────────────────────────────────────
  Future<void> _autoDetectLocationAndFetchPrayer() async {
    if (!mounted) return;
    setState(() => _detectingLocation = true);

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const CircularProgressIndicator(color: Color(0xFF00E5FF)),
            const SizedBox(height: 16),
            Text('Mendeteksi lokasi Anda...',
                style: TextStyle(color: textPrimary)),
            const SizedBox(height: 6),
            const Text(
              'Menggunakan GPS untuk akurasi terbaik',
              style: TextStyle(color: Colors.white54, fontSize: 11),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );

    try {
      final detectedCity = await PrayerTimeService.detectLocationByGPS();
      if (mounted) {
        Navigator.pop(context);
        setState(() {
          _prayerCity = detectedCity;
          _detectingLocation = false;
        });
        await _fetchPrayerTimes();
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(children: [
              const Icon(Icons.gps_fixed_rounded,
                  color: Colors.white, size: 16),
              const SizedBox(width: 8),
              Expanded(
                  child: Text('Lokasi terdeteksi: $detectedCity',
                      style: const TextStyle(color: Colors.white))),
            ]),
            backgroundColor: primaryColor,
            behavior: SnackBarBehavior.floating,
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            duration: const Duration(seconds: 3),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context);
        setState(() => _detectingLocation = false);
        await _fetchPrayerTimes();
      }
    }
  }

  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;
    setState(() => _prayerLoading = true);
    final data = await PrayerTimeService.fetchPrayerTimes(_prayerCity);
    if (!mounted) return;
    if (data.isNotEmpty && data['data'] != null) {
      final timings = data['data']['timings'] ?? {};
      final Map<String, String> times = {
        'Subuh': timings['Fajr'] ?? '--:--',
        'Dzuhur': timings['Dhuhr'] ?? '--:--',
        'Ashar': timings['Asr'] ?? '--:--',
        'Maghrib': timings['Maghrib'] ?? '--:--',
        'Isya': timings['Isha'] ?? '--:--',
      };
      final now = TimeOfDay.now();
      String nextLabel = 'Isya';
      String nextTime = times['Isya'] ?? '--:--';
      for (final entry in times.entries) {
        final parts = entry.value.split(':');
        if (parts.length >= 2) {
          final h = int.tryParse(parts[0]) ?? 0;
          final m = int.tryParse(parts[1]) ?? 0;
          if (h > now.hour || (h == now.hour && m > now.minute)) {
            nextLabel = entry.key;
            nextTime = entry.value;
            break;
          }
        }
      }
      setState(() {
        _prayerTimes = times;
        _nextPrayerLabel = nextLabel;
        _nextPrayerTime = nextTime;
        _prayerLoading = false;
      });
    } else {
      setState(() => _prayerLoading = false);
    }
  }

  void _showChangeCityDialog() {
    final ctrl = TextEditingController(text: _prayerCity);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
            side: BorderSide(color: accentColor.withOpacity(0.4))),
        title: const Text('Ganti Lokasi',
            style: TextStyle(color: Colors.white, fontSize: 14)),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Nama kota (misal: Jakarta, Surabaya, Bandung)',
            hintStyle: const TextStyle(color: Colors.white54),
            filled: true,
            fillColor: backgroundColor,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none),
            prefixIcon: const Icon(Icons.location_city_rounded,
                color: Color(0xFF00E5FF)),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal',
                  style: TextStyle(color: Colors.white54))),
          ElevatedButton(
            onPressed: () {
              if (ctrl.text.trim().isNotEmpty) {
                setState(() {
                  _prayerCity = ctrl.text.trim();
                });
                _fetchPrayerTimes();
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: accentColor,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10))),
            child: const Text('Simpan',
                style: TextStyle(
                    color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  // ── Fetch Hadith ──────────────────────────────────────────────────────────
  Future<void> _fetchRandomHadith() async {
    if (!mounted) return;
    setState(() => _hadithLoading = true);
    try {
      int randomNumber;
      do {
        randomNumber = math.Random().nextInt(100) + 1;
      } while (randomNumber == _lastHadithNumber);
      _lastHadithNumber = randomNumber;
      final response = await http
          .get(Uri.parse(
              'https://api.hadith.gading.dev/books/muslim/$randomNumber'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200 && mounted) {
        setState(() {
          _hadith = json.decode(response.body);
          _hadithLoading = false;
        });
      } else {
        if (mounted) setState(() => _hadithLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _hadithLoading = false);
    }
  }

  void _showHadithFullDialog(String arabic, String indo, String source,
      String number, String grade) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Container(
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: accentColor.withOpacity(0.4)),
            boxShadow: [
              ...neonGlow(opacity: 0.4),
              BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 20,
                  offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(24)),
                  color: accentColor.withOpacity(0.1),
                  border: Border(
                      bottom: BorderSide(
                          color: primaryColor.withOpacity(0.3))),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: accentColor.withOpacity(0.2)),
                      child: const Icon(Icons.menu_book_rounded,
                          color: Color(0xFF00E5FF), size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('HADITH LENGKAP',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 14)),
                            Text(grade,
                                style: const TextStyle(
                                    color: Color(0xFF00E5FF), fontSize: 11)),
                          ]),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: 34,
                        height: 34,
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.white.withOpacity(0.08)),
                        child: const Icon(Icons.close_rounded,
                            color: Colors.white54, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
              ConstrainedBox(
                constraints: BoxConstraints(
                    maxHeight: MediaQuery.of(context).size.height * 0.62),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: surfaceColor,
                          border: Border.all(
                              color: primaryColor.withOpacity(0.4)),
                        ),
                        child: Text(arabic,
                            textAlign: TextAlign.right,
                            textDirection: TextDirection.rtl,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 19,
                                height: 2.2)),
                      ),
                      const SizedBox(height: 14),
                      Row(children: [
                        Container(
                            width: 3,
                            height: 18,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(2),
                                color: accentColor)),
                        const SizedBox(width: 8),
                        const Text('ARTINYA:',
                            style: TextStyle(
                                color: Color(0xFF00E5FF),
                                fontSize: 11,
                                fontWeight: FontWeight.bold)),
                      ]),
                      const SizedBox(height: 10),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: surfaceColor,
                          border: Border.all(
                              color: primaryColor.withOpacity(0.3)),
                        ),
                        child: Text(indo,
                            style: const TextStyle(
                                color: Colors.white70,
                                fontSize: 14,
                                fontStyle: FontStyle.italic,
                                height: 1.8)),
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                              color: accentColor.withOpacity(0.5)),
                          color: accentColor.withOpacity(0.1),
                        ),
                        child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.receipt_long_rounded,
                                  color: Color(0xFF00E5FF), size: 14),
                              const SizedBox(width: 6),
                              Text(
                                  '${source.isNotEmpty ? source : "Muslim"} #$number',
                                  style: const TextStyle(
                                      color: Color(0xFF00E5FF),
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold)),
                            ]),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  int _getTotalSessions() {
    try {
      final dir = Directory('permenmd');
      if (!dir.existsSync()) return 0;
      int total = 0;
      for (final folder in dir.listSync()) {
        if (folder is Directory) {
          final files = folder
              .listSync()
              .where((f) => f is File && f.path.endsWith('.json'));
          total += files.length;
        }
      }
      return total;
    } catch (_) {
      return 0;
    }
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  PageRoute _slideRoute(Widget page) => PageRouteBuilder(
        pageBuilder: (_, __, ___) => page,
        transitionDuration: const Duration(milliseconds: 350),
        transitionsBuilder: (_, anim, __, child) => SlideTransition(
          position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
              .animate(
                  CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
          child: FadeTransition(opacity: anim, child: child),
        ),
      );

  // ==================== BUILD DASHBOARD HOME ====================
  Widget _buildDashboardHome() {
    int remainingDays = 0;
    try {
      final expired = DateTime.parse(expiredDate);
      final now = DateTime.now();
      remainingDays = expired.difference(now).inDays;
      if (remainingDays < 0) remainingDays = 0;
    } catch (_) {}

    int totalBugs = listBug.length;
    int totalSession = _getTotalSessions();

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.all(10),
      child: Column(
        children: [
          _buildClockAndServerCard(),
          const SizedBox(height: 10),
          _buildProfileCard(remainingDays, totalBugs, totalSession),
          const SizedBox(height: 10),
          _buildQuickActionsSection(),
          const SizedBox(height: 10),
          _buildPrayerSection(),
          const SizedBox(height: 10),
          _buildHadithSection(),
          const SizedBox(height: 24),
        ],
      ),
    );
  }

  // ─── DIGITAL CLOCK + SERVER STATUS ──────────────────────────────────────
  Widget _buildClockAndServerCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 2),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: primaryColor.withOpacity(0.5), width: 1.4),
        boxShadow: neonGlow(opacity: 0.4),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.access_time_filled_rounded,
                        color: accentColor, size: 14),
                    const SizedBox(width: 6),
                    Text(
                      'WAKTU SEKARANG',
                      style: TextStyle(
                        color: textSecondary,
                        fontSize: 9,
                        letterSpacing: 1.3,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                ShaderMask(
                  shaderCallback: (b) => LinearGradient(
                    colors: [Colors.white, accentColor, primaryColor],
                  ).createShader(b),
                  child: Text(
                    _digitalTime,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.5,
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  _digitalDate,
                  style: TextStyle(
                    color: textSecondary.withOpacity(0.65),
                    fontSize: 10,
                    letterSpacing: 1.2,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: (_serverOnline ? Colors.green : Colors.red)
                  .withOpacity(0.12),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: (_serverOnline ? Colors.green : Colors.red)
                    .withOpacity(0.5),
              ),
              boxShadow: [
                BoxShadow(
                  color: (_serverOnline ? Colors.green : Colors.red)
                      .withOpacity(0.4),
                  blurRadius: 12,
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.15),
                  blurRadius: 6,
                ),
              ],
            ),
            child: Column(
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _AnimatedDot(
                      color: _serverOnline ? Colors.green : Colors.red,
                      size: 8,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      _serverOnline ? 'ONLINE' : 'OFFLINE',
                      style: TextStyle(
                        color: _serverOnline ? Colors.green : Colors.red,
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  'SERVER',
                  style: TextStyle(
                    color: textSecondary.withOpacity(0.65),
                    fontSize: 8,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── PROFILE CARD ────────────────────────────────────────────────────────
  Widget _buildProfileCard(
      int remainingDays, int totalBugs, int totalSession) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            surfaceColor.withOpacity(0.7),
            surfaceColor.withOpacity(0.3),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: accentColor.withOpacity(0.3),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 30,
            spreadRadius: 5,
            offset: const Offset(0, 12),
          ),
          BoxShadow(
            color: primaryColor.withOpacity(0.25),
            blurRadius: 50,
            spreadRadius: 8,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.08),
            blurRadius: 60,
            spreadRadius: 15,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          children: [
            Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: Container(
                height: 50,
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(20),
                  ),
                  gradient: LinearGradient(
                    colors: [
                      Colors.white.withOpacity(0.08),
                      Colors.transparent,
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: accentColor.withOpacity(0.7),
                            width: 2.5,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: accentColor.withOpacity(0.4),
                              blurRadius: 16,
                              spreadRadius: 2,
                            ),
                            BoxShadow(
                              color: Colors.white.withOpacity(0.2),
                              blurRadius: 8,
                            ),
                          ],
                        ),
                        child: ClipOval(
                          child: Image.asset(
                            'assets/images/logo.png',
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              color: primaryColor,
                              child: Icon(
                                Icons.person_rounded,
                                color: accentColor,
                                size: 26,
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              username,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.5,
                                shadows: [
                                  Shadow(blurRadius: 8, color: Colors.black38),
                                ],
                              ),
                            ),
                            const SizedBox(height: 2),
                            GestureDetector(
                              onTap: () =>
                                  _openUrl("https://t.me/resbobnich"),
                              child: const Row(
                                children: [
                                  Icon(FontAwesomeIcons.telegram,
                                      color: Colors.blueAccent, size: 12),
                                  SizedBox(width: 4),
                                  Text(
                                    "@KaichoNew",
                                    style: TextStyle(
                                      color: Colors.blueAccent,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w500,
                                      decoration: TextDecoration.underline,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [primaryColor, accentColor],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(14),
                              boxShadow: neonGlow(
                                  blur: 8, spread: 0.3, opacity: 0.5),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.verified_rounded,
                                    color: Colors.white, size: 12),
                                const SizedBox(width: 4),
                                Text(
                                  role.toUpperCase(),
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 9,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 6,
                                height: 6,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.green.shade400,
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.green.withOpacity(0.6),
                                      blurRadius: 6,
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 4),
                              const Text(
                                "ONLINE",
                                style: TextStyle(
                                  color: Colors.green,
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 0.5,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const Divider(
                      color: Colors.white12, height: 1, thickness: 0.3),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.star_rounded,
                          color: Color(0xFF00E5FF), size: 14),
                      const SizedBox(width: 6),
                      Text(
                        "NEVERLOUS PROJECT ULTRA",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.8,
                          shadows: [
                            Shadow(
                                blurRadius: 10,
                                color: accentColor.withOpacity(0.4)),
                          ],
                        ),
                      ),
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                              colors: [primaryColor, accentColor]),
                          borderRadius: BorderRadius.circular(6),
                          boxShadow: neonGlow(
                              blur: 8, spread: 0.3, opacity: 0.5),
                        ),
                        child: const Text(
                          "PRO",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  GridView.count(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: 4,
                    crossAxisSpacing: 6,
                    mainAxisSpacing: 6,
                    childAspectRatio: 1.6,
                    children: [
                      _buildMiniStat(
                        icon: Icons.screen_share_rounded,
                        iconColor: Colors.cyan,
                        value: "$totalSession",
                        label: "SESSION",
                      ),
                      _buildMiniStat(
                        icon: Icons.timer_outlined,
                        iconColor: remainingDays > 30
                            ? Colors.green
                            : remainingDays > 7
                                ? Colors.amber
                                : Colors.red,
                        value: "$remainingDays",
                        label: "EXPIRATION",
                      ),
                      _buildMiniStat(
                        icon: Icons.people_alt_rounded,
                        iconColor: Colors.green,
                        value: "$onlineUsers",
                        label: "ONLINE",
                      ),
                      _buildMiniStat(
                        icon: Icons.bug_report_rounded,
                        iconColor: accentColor,
                        value: "$totalBugs",
                        label: "BUG",
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMiniStat({
    required IconData icon,
    required Color iconColor,
    required String value,
    required String label,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 6),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.white.withOpacity(0.05),
            Colors.white.withOpacity(0.01),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: iconColor.withOpacity(0.3),
          width: 0.8,
        ),
        boxShadow: [
          BoxShadow(
            color: iconColor.withOpacity(0.15),
            blurRadius: 6,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.08),
            blurRadius: 3,
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: iconColor, size: 14),
          const SizedBox(height: 2),
          Text(
            value,
            style: TextStyle(
              color: Colors.white,
              fontSize: 13,
              fontWeight: FontWeight.bold,
              shadows: [
                Shadow(blurRadius: 6, color: iconColor.withOpacity(0.3)),
              ],
            ),
          ),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withOpacity(0.35),
              fontSize: 6,
              fontWeight: FontWeight.w500,
              letterSpacing: 0.5,
            ),
          ),
        ],
      ),
    );
  }

  // ─── QUICK ACTIONS ──────────────────────────────────────────────────────
  Widget _buildQuickActionsSection() {
    final actions = [
      _QuickActionData(
        icon: Icons.bug_report_rounded,
        bgIcon: Icons.bug_report_rounded,
        title: 'Bug Sender',
        subtitle: 'Kirim bug ke target',
        gradient: [const Color(0xFF00B0FF), const Color(0xFF00E5FF)],
        rainbowColors: [
          const Color(0xFF00B0FF),
          const Color(0xFF00E5FF),
          const Color(0xFF0288D1),
          const Color(0xFF80DEEA),
        ],
        onTap: () => Navigator.push(
          context,
          _slideRoute(BugSenderPage(
              sessionKey: sessionKey, username: username, role: role)),
        ),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.whatsapp,
        bgIcon: FontAwesomeIcons.whatsapp,
        title: 'WhatsApp',
        subtitle: 'Chat, foto, video, VN',
        gradient: [const Color(0xFF00B0FF), const Color(0xFF00E5FF)],
        rainbowColors: [
          const Color(0xFF00B0FF),
          const Color(0xFF00E5FF),
          const Color(0xFF0288D1),
          const Color(0xFF80DEEA),
        ],
        onTap: () => Navigator.push(
          context,
          _slideRoute(WhatsAppPage(
              sessionKey: sessionKey, username: username, role: role)),
        ),
      ),
      _QuickActionData(
        icon: Icons.casino_rounded,
        bgIcon: Icons.casino_rounded,
        title: 'Dominos',
        subtitle: 'Game kartu domino',
        gradient: [const Color(0xFF00838F), const Color(0xFF00B0FF)],
        rainbowColors: [
          const Color(0xFF00B0FF),
          const Color(0xFF00E5FF),
          const Color(0xFF00838F),
          const Color(0xFF4DD0E1),
        ],
        onTap: () => Navigator.push(
          context,
          _slideRoute(const DominosPage()),
        ),
      ),
      _QuickActionData(
        icon: Icons.card_giftcard_rounded,
        bgIcon: Icons.card_giftcard_rounded,
        title: 'Ucapan',
        subtitle: 'Kirim ucapan spesial',
        gradient: [const Color(0xFF00B0FF), const Color(0xFF00E5FF)],
        rainbowColors: [
          const Color(0xFF00B0FF),
          const Color(0xFF00E5FF),
          const Color(0xFF0288D1),
          const Color(0xFF80DEEA),
        ],
        onTap: () => Navigator.push(
          context,
          _slideRoute(UcapanPage(
              sessionKey: sessionKey, username: username, role: role)),
        ),
      ),
      _QuickActionData(
        icon: Icons.public_rounded,
        bgIcon: Icons.public_rounded,
        title: 'Public Chat',
        subtitle: 'Chat dengan pengguna lain',
        gradient: [const Color(0xFF00838F), const Color(0xFF4DD0E1)],
        rainbowColors: [
          const Color(0xFF00838F),
          const Color(0xFF4DD0E1),
          const Color(0xFF00BCD4),
          const Color(0xFF80DEEA),
        ],
        onTap: () => Navigator.push(
          context,
          _slideRoute(PublicChatPage(
              sessionKey: sessionKey, username: username, role: role)),
        ),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.youtube,
        bgIcon: FontAwesomeIcons.youtube,
        title: 'YouTube',
        subtitle: 'Browser YouTube',
        gradient: [const Color(0xFFFF0000), const Color(0xFFFF6B6B)],
        rainbowColors: [
          const Color(0xFFFF0000),
          const Color(0xFFFF6B6B),
          const Color(0xFFCC0000),
          const Color(0xFFFF3D3D),
        ],
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const YouTubeToolPage()),
        ),
      ),
      _QuickActionData(
        icon: Icons.public_rounded,
        bgIcon: Icons.public_rounded,
        title: 'Mini Browser',
        subtitle: 'Jelajahi web apapun',
        gradient: [const Color(0xFF1A73E8), const Color(0xFF4FC3F7)],
        rainbowColors: [
          const Color(0xFF1A73E8),
          const Color(0xFF4FC3F7),
          const Color(0xFF0D47A1),
          const Color(0xFF42A5F5),
        ],
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => const MiniBrowserToolPage()),
        ),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.bookOpenReader,
        bgIcon: FontAwesomeIcons.bookOpenReader,
        title: 'Comic Zone',
        subtitle: 'Baca manga favorit',
        gradient: [const Color(0xFF00B0FF), const Color(0xFF00E5FF)],
        rainbowColors: [
          const Color(0xFF00B0FF),
          const Color(0xFF00E5FF),
          const Color(0xFF0288D1),
          const Color(0xFF80DEEA),
        ],
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const ComicPage()),
        ),
      ),
    ];

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: accentColor.withOpacity(0.15),
                  border: Border.all(color: accentColor.withOpacity(0.4)),
                  boxShadow: neonGlow(blur: 8, spread: 0.3, opacity: 0.4),
                ),
                child: Icon(Icons.bolt_rounded, color: accentColor, size: 18),
              ),
              const SizedBox(width: 10),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'QUICK ACTIONS',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                    ),
                  ),
                  Text(
                    'Beberapa Menu Tambahan',
                    style: TextStyle(color: Colors.white70, fontSize: 10),
                  ),
                ],
              ),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  gradient:
                      LinearGradient(colors: [primaryColor, accentColor]),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: neonGlow(blur: 8, spread: 0.3, opacity: 0.4),
                ),
                child: const Row(
                  children: [
                    SizedBox(
                      width: 5,
                      height: 5,
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: Colors.white,
                        ),
                      ),
                    ),
                    SizedBox(width: 4),
                    Text(
                      'NEVERLOUS PROJECT',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          height: 150,
          child: PageView.builder(
            controller: _qaPageController,
            itemCount: actions.length,
            onPageChanged: (index) {
              if (mounted) setState(() => _currentQaPage = index.toDouble());
            },
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: _buildQuickActionCard(actions[index]),
              );
            },
          ),
        ),
        const SizedBox(height: 8),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(actions.length, (index) {
            final bool isActive = _currentQaPage.round() == index;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 3),
              width: isActive ? 18 : 6,
              height: 5,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(3),
                color: isActive ? accentColor : Color(0xFF00B0FF),
                boxShadow: isActive
                    ? [
                        BoxShadow(
                            color: accentColor.withOpacity(0.5),
                            blurRadius: 8),
                      ]
                    : [],
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildQuickActionCard(_QuickActionData action) {
    final color =
        action.rainbowColors[_currentQaPage.round() % action.rainbowColors.length];
    return GestureDetector(
      onTap: action.onTap,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color, width: 2),
          gradient: LinearGradient(
            colors: action.gradient,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.4),
              blurRadius: 14,
              offset: const Offset(0, 4),
            ),
            BoxShadow(
              color: Colors.white.withOpacity(0.18),
              blurRadius: 8,
            ),
          ],
        ),
        child: Stack(
          children: [
            Positioned(
              right: -10,
              bottom: -10,
              child: Icon(
                action.bgIcon,
                color: Colors.white.withOpacity(0.06),
                size: 80,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white.withOpacity(0.2),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.3),
                        width: 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: color.withOpacity(0.5),
                          blurRadius: 10,
                        ),
                        BoxShadow(
                          color: Colors.white.withOpacity(0.2),
                          blurRadius: 5,
                        ),
                      ],
                    ),
                    child: Icon(
                      action.icon,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                  const Spacer(),
                  Align(
                    alignment: Alignment.topRight,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(14),
                        color: Colors.white.withOpacity(0.2),
                        border: Border.all(
                          color: Colors.white.withOpacity(0.3),
                          width: 1,
                        ),
                      ),
                      child: const Text(
                        'Tap →',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    action.title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                      shadows: [
                        Shadow(blurRadius: 4, color: Colors.black26),
                      ],
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    action.subtitle,
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.75),
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── PRAYER SECTION ──────────────────────────────────────────────────────
  Widget _buildPrayerSection() {
    final prayerColors = [
      const Color(0xFF00B0FF),
      const Color(0xFF00E5FF),
      const Color(0xFF0288D1),
      const Color(0xFF4DD0E1),
      const Color(0xFF80DEEA),
    ];
    final prayerIcons = [
      Icons.nights_stay_rounded,
      Icons.wb_sunny_rounded,
      Icons.cloud_rounded,
      Icons.wb_twilight_rounded,
      Icons.nightlight_round,
    ];
    final prayerKeys = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 0),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: primaryColor.withOpacity(0.5),
            width: 1.5,
          ),
          boxShadow: neonGlow(blur: 15, spread: 1, opacity: 0.35),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.04),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: primaryColor.withOpacity(0.3),
                  width: 1,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          color: accentColor.withOpacity(0.15),
                          border: Border.all(
                            color: accentColor.withOpacity(0.4),
                            width: 1,
                          ),
                          boxShadow:
                              neonGlow(blur: 8, spread: 0.3, opacity: 0.4),
                        ),
                        child: const Center(
                          child: Icon(
                            Icons.mosque_rounded,
                            color: Color(0xFF00E5FF),
                            size: 16,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'JADWAL SHOLAT',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                                letterSpacing: 0.5,
                              ),
                            ),
                            Row(
                              children: [
                                Icon(Icons.location_on_rounded,
                                    color: accentColor, size: 10),
                                const SizedBox(width: 3),
                                Text(
                                  _prayerCity,
                                  style: const TextStyle(
                                    color: Colors.white70,
                                    fontSize: 10,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: _autoDetectLocationAndFetchPrayer,
                        child: Container(
                          width: 30,
                          height: 30,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: accentColor.withOpacity(0.12),
                            border: Border.all(
                              color: accentColor.withOpacity(0.4),
                              width: 1,
                            ),
                            boxShadow: neonGlow(
                                blur: 8, spread: 0.3, opacity: 0.4),
                          ),
                          child: _detectingLocation
                              ? const Padding(
                                  padding: EdgeInsets.all(6),
                                  child: CircularProgressIndicator(
                                    color: Color(0xFF00E5FF),
                                    strokeWidth: 2,
                                  ),
                                )
                              : Icon(
                                  Icons.gps_fixed_rounded,
                                  color: accentColor,
                                  size: 14,
                                ),
                        ),
                      ),
                      const SizedBox(width: 6),
                      GestureDetector(
                        onTap: _showChangeCityDialog,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(14),
                            gradient: LinearGradient(
                              colors: [primaryColor, accentColor],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            boxShadow: neonGlow(
                                blur: 8, spread: 0.3, opacity: 0.5),
                          ),
                          child: const Row(
                            children: [
                              Icon(Icons.edit_location_alt_rounded,
                                  color: Colors.white, size: 12),
                              SizedBox(width: 4),
                              Text(
                                'GANTI',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 9,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  if (_nextPrayerLabel.isNotEmpty)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 6),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: accentColor.withOpacity(0.4),
                          width: 1,
                        ),
                        gradient: LinearGradient(
                          colors: [
                            primaryColor.withOpacity(0.25),
                            primaryColor.withOpacity(0.05),
                          ],
                        ),
                        boxShadow:
                            neonGlow(blur: 10, spread: 0.5, opacity: 0.3),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 6,
                            height: 6,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: accentColor,
                              boxShadow: [
                                BoxShadow(
                                    color: accentColor.withOpacity(0.6),
                                    blurRadius: 6),
                                BoxShadow(
                                    color: Colors.white.withOpacity(0.3),
                                    blurRadius: 3),
                              ],
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'Menuju $_nextPrayerLabel : $_nextPrayerTime',
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 2),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              color: accentColor.withOpacity(0.15),
                              border: Border.all(
                                color: accentColor.withOpacity(0.3),
                              ),
                            ),
                            child: const Text(
                              'TODAY',
                              style: TextStyle(
                                color: Color(0xFF00E5FF),
                                fontSize: 8,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  const SizedBox(height: 10),
                  if (_prayerLoading)
                    const Center(
                      child: Padding(
                        padding: EdgeInsets.symmetric(vertical: 16),
                        child: SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            color: Color(0xFF00E5FF),
                            strokeWidth: 2,
                          ),
                        ),
                      ),
                    )
                  else
                    SizedBox(
                      height: 80,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        physics: const BouncingScrollPhysics(),
                        itemCount: prayerKeys.length,
                        itemBuilder: (ctx, i) {
                          final key = prayerKeys[i];
                          final time = _prayerTimes[key] ?? '--:--';
                          final color = prayerColors[i];
                          final icon = prayerIcons[i];
                          final isNext = key == _nextPrayerLabel;

                          return Container(
                            width: 72,
                            margin: const EdgeInsets.only(right: 8),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              gradient: LinearGradient(
                                colors: [
                                  color.withOpacity(0.2),
                                  color.withOpacity(0.05),
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              border: Border.all(
                                color: isNext
                                    ? accentColor
                                    : color.withOpacity(0.35),
                                width: isNext ? 2 : 1,
                              ),
                              boxShadow: isNext
                                  ? neonGlow(
                                      blur: 12, spread: 0.5, opacity: 0.5)
                                  : null,
                            ),
                            child: Padding(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 6),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    icon,
                                    color: isNext
                                        ? accentColor
                                        : Color(0xFF00B0FF),
                                    size: 14,
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    key.toUpperCase(),
                                    style: TextStyle(
                                      color: isNext
                                          ? accentColor
                                          : Color(0xFF00B0FF),
                                      fontSize: 7,
                                      fontWeight: isNext
                                          ? FontWeight.bold
                                          : FontWeight.w400,
                                    ),
                                  ),
                                  const SizedBox(height: 1),
                                  Text(
                                    time,
                                    style: TextStyle(
                                      color: isNext
                                          ? accentColor
                                          : Color(0xFF00B0FF),
                                      fontSize: 12,
                                      fontWeight: isNext
                                          ? FontWeight.bold
                                          : FontWeight.w500,
                                    ),
                                  ),
                                  if (isNext)
                                    Container(
                                      margin: const EdgeInsets.only(top: 1),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 4, vertical: 1),
                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(
                                            colors: [
                                              primaryColor,
                                              accentColor
                                            ]),
                                        borderRadius: BorderRadius.circular(6),
                                        boxShadow: neonGlow(
                                            blur: 6,
                                            spread: 0.3,
                                            opacity: 0.6),
                                      ),
                                      child: const Text(
                                        'NOW',
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 5,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── HADITH SECTION ──────────────────────────────────────────────────────
  Widget _buildHadithSection() {
    if (_hadithLoading) {
      return Container(
        height: 100,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [surfaceColor, surfaceColor.withOpacity(0.5)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: accentColor.withOpacity(0.3)),
          boxShadow: neonGlow(blur: 10, spread: 0.5, opacity: 0.3),
        ),
        child: const Center(
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  color: Color(0xFF00E5FF),
                  strokeWidth: 2,
                ),
              ),
              SizedBox(width: 12),
              Text(
                'Memuat Hadist...',
                style: TextStyle(color: Colors.white54, fontSize: 11),
              ),
            ],
          ),
        ),
      );
    }

    final arabic = _hadith?['data']?['text']?['ar'] ??
        'إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى';
    final indo = _hadith?['data']?['text']?['id'] ??
        'Sesungguhnya setiap amalan tergantung pada niatnya.';
    final number = _hadith?['data']?['id']?.toString() ?? '1';
    final source = _hadith?['data']?['source']?.toString() ?? 'Muslim';
    final grade = _hadith?['data']?['grade']?.toString() ?? 'Sahih Muslim';

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [surfaceColor, surfaceColor.withOpacity(0.5)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: accentColor.withOpacity(0.3),
          width: 1.5,
        ),
        boxShadow: neonGlow(blur: 12, spread: 0.5, opacity: 0.3),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Stack(
          children: [
            Positioned(
              right: -10,
              bottom: -10,
              child: Icon(
                Icons.menu_book_rounded,
                color: accentColor.withOpacity(0.04),
                size: 60,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          gradient: LinearGradient(
                            colors: [primaryColor, accentColor],
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                          ),
                          boxShadow:
                              neonGlow(blur: 8, spread: 0.3, opacity: 0.5),
                        ),
                        child: const Center(
                          child: Icon(
                            Icons.menu_book_rounded,
                            color: Colors.white,
                            size: 14,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Row(
                          children: [
                            const Text(
                              'HADITH OF THE DAY',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 11,
                                letterSpacing: 0.5,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 6, vertical: 1),
                              decoration: BoxDecoration(
                                color: accentColor.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(
                                  color: accentColor.withOpacity(0.3),
                                ),
                              ),
                              child: Text(
                                grade,
                                style: TextStyle(
                                  color: accentColor,
                                  fontSize: 7,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: _fetchRandomHadith,
                        child: Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: accentColor.withOpacity(0.1),
                          ),
                          child: Icon(
                            Icons.refresh_rounded,
                            color: accentColor.withOpacity(0.6),
                            size: 14,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  GestureDetector(
                    onTap: () => _showHadithFullDialog(
                        arabic, indo, source, number, grade),
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.black.withOpacity(0.25),
                        border: Border.all(
                          color: accentColor.withOpacity(0.15),
                          width: 1,
                        ),
                      ),
                      child: Column(
                        children: [
                          Text(
                            arabic,
                            textAlign: TextAlign.right,
                            textDirection: TextDirection.rtl,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.9),
                              fontSize: 14,
                              height: 1.8,
                              fontWeight: FontWeight.w400,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          const SizedBox(height: 4),
                          Container(
                            height: 0.5,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.transparent,
                                  accentColor.withOpacity(0.3),
                                  Colors.transparent,
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            indo,
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.55),
                              fontSize: 10,
                              fontStyle: FontStyle.italic,
                              height: 1.4,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(
                            color: accentColor.withOpacity(0.3),
                            width: 0.5,
                          ),
                          color: accentColor.withOpacity(0.08),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.receipt_long_rounded,
                              color: accentColor.withOpacity(0.6),
                              size: 10,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              '${source.isNotEmpty ? source : "Muslim"} #$number',
                              style: TextStyle(
                                color: accentColor.withOpacity(0.6),
                                fontSize: 8,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const Spacer(),
                      GestureDetector(
                        onTap: () => _showHadithFullDialog(
                            arabic, indo, source, number, grade),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 8, vertical: 2),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(6),
                            color: accentColor.withOpacity(0.1),
                            border: Border.all(
                              color: accentColor.withOpacity(0.2),
                              width: 0.5,
                            ),
                          ),
                          child: const Text(
                            'Baca Lengkap →',
                            style: TextStyle(
                              color: Color(0xFF00E5FF),
                              fontSize: 8,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, int index) {
    final isSelected = _bottomNavIndex == index;
    return GestureDetector(
      onTap: () => _onBottomNavTapped(index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeInOut,
        padding: EdgeInsets.symmetric(
          horizontal: isSelected ? 14 : 10,
          vertical: 6,
        ),
        decoration: BoxDecoration(
          gradient: isSelected
              ? LinearGradient(
                  colors: [primaryColor, accentColor],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : null,
          borderRadius: BorderRadius.circular(20),
          boxShadow: isSelected
              ? neonGlow(blur: 10, spread: 0.5, opacity: 0.5)
              : [],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon,
                color: isSelected
                    ? Colors.white
                    : textSecondary.withOpacity(0.7),
                size: isSelected ? 18 : 17),
            if (isSelected) ...[
              const SizedBox(width: 6),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.3,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildCustomDrawer() {
    const allowedOwnerRoles = [
      'dev',
      'ceo',
      'high_admin',
      'high admin',
      'owner',
      'admin',
      'reseller'
    ];

    return Drawer(
      backgroundColor: Colors.transparent,
      width: MediaQuery.of(context).size.width * 0.85,
      child: Container(
        decoration: const BoxDecoration(
          color: Color(0xFF050B1A),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 200,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [primaryColor, accentColor],
                ),
                boxShadow: neonGlow(blur: 20, spread: 1, opacity: 0.5),
              ),
              child: SafeArea(
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AnimatedBuilder(
                        animation: _buttonPulseAnimation,
                        builder: (context, child) {
                          return Transform.scale(
                            scale: _buttonPulseAnimation.value,
                            child: Container(
                              width: 80,
                              height: 80,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                    color: accentColor, width: 2),
                                boxShadow: [
                                  BoxShadow(
                                      color: Colors.black.withOpacity(0.3),
                                      blurRadius: 15),
                                ],
                              ),
                              child: ClipOval(
                                child: _profileImage != null
                                    ? Image.file(_profileImage!,
                                        fit: BoxFit.cover)
                                    : Container(
                                        color: primaryColor,
                                        child: Icon(
                                            FontAwesomeIcons.userAstronaut,
                                            size: 36,
                                            color: accentColor),
                                      ),
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 10),
                      Text(username,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 17,
                              fontWeight: FontWeight.w600)),
                      const SizedBox(height: 4),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 3),
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Text(
                          role.toUpperCase(),
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 12),
                children: [
                  if (role == "reseller")
                    _buildMenuItem(
                        icon: Icons.storefront_rounded,
                        label: "Seller Page",
                        onTap: () => _onSidebarTabSelected(1)),
                  if (role == "admin")
                    _buildMenuItem(
                        icon: Icons.admin_panel_settings_rounded,
                        label: "Admin Page",
                        onTap: () => _onSidebarTabSelected(2)),
                  if (allowedOwnerRoles.contains(role))
                    _buildMenuItem(
                      icon: Icons.workspace_premium_rounded,
                      label: "Owner Page",
                      onTap: () => _onSidebarTabSelected(3),
                    ),
                  _buildMenuItem(
                    icon: Icons.history_rounded,
                    label: "Riwayat Aktivitas",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => RiwayatPage(
                                  sessionKey: sessionKey, role: role)));
                    },
                  ),
                  _buildMenuItem(
                    icon: FontAwesomeIcons.whatsapp,
                    label: "WhatsApp",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => WhatsAppPage(
                            sessionKey: sessionKey,
                            username: username,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildMenuItem(
                    icon: Icons.casino_rounded,
                    label: "Dominos Game",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const DominosPage()),
                      );
                    },
                  ),
                  _buildMenuItem(
                    icon: Icons.handyman_rounded,
                    label: "Tools Dashboard",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => ToolsPage(
                            sessionKey: sessionKey,
                            username: username,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildMenuItem(
                    icon: Icons.send_rounded,
                    label: "Manage Sender",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => BugSenderPage(
                                  sessionKey: sessionKey,
                                  username: username,
                                  role: role)));
                    },
                  ),
                  const Divider(
                      color: Colors.white12, height: 20, thickness: 0.5),
                  _buildMenuItem(
                    icon: Icons.logout_rounded,
                    label: "Log Out",
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(
                            builder: (context) => const LoginPage()),
                        (route) => false,
                      );
                    },
                  ),
                  const SizedBox(height: 4),
                  _buildThanksMenuItem(),
                  const SizedBox(height: 12),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildThanksMenuItem() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            Colors.pink.withOpacity(0.15),
            Colors.pink.withOpacity(0.05),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: Colors.pink.withOpacity(0.3),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.pink.withOpacity(0.1),
            blurRadius: 10,
            spreadRadius: 2,
          ),
        ],
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: LinearGradient(
              colors: [Colors.pink.shade300, Colors.pink.shade700],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.pink.withOpacity(0.4),
                blurRadius: 8,
              ),
            ],
          ),
          child: const Icon(
            Icons.favorite_rounded,
            color: Colors.white,
            size: 18,
          ),
        ),
        title: const Text(
          "THANKS TO",
          style: TextStyle(
            color: Colors.pink,
            fontWeight: FontWeight.bold,
            fontSize: 13,
            letterSpacing: 1,
          ),
        ),
        trailing: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.pink.shade300, Colors.pink.shade700],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(12),
          ),
          child: const Text(
            "❤️",
            style: TextStyle(fontSize: 12),
          ),
        ),
        onTap: () {
          Navigator.pop(context);
          _showThanksToDialog();
        },
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        color: isLogout ? Colors.red.withOpacity(0.1) : cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isLogout
              ? Colors.red.withOpacity(0.3)
              : accentColor.withOpacity(0.3),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: (isLogout ? Colors.red : accentColor)
                .withOpacity(0.15),
            blurRadius: 8,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.05),
            blurRadius: 4,
          ),
        ],
      ),
      child: ListTile(
        leading: Icon(icon,
            color: isLogout ? Colors.redAccent : accentColor, size: 20),
        title: Text(
          label,
          style: TextStyle(
            color: isLogout ? Colors.redAccent : textPrimary,
            fontWeight: FontWeight.w500,
            fontSize: 13,
          ),
        ),
        trailing: isLogout
            ? null
            : Icon(Icons.chevron_right_rounded,
                color: textSecondary, size: 18),
        onTap: onTap,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      extendBody: true,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: AnimatedBuilder(
          animation: _buttonPulseAnimation,
          builder: (context, child) {
            return Transform.scale(
              scale: _buttonPulseAnimation.value,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                decoration: BoxDecoration(
                  color: cardColor,
                  borderRadius: BorderRadius.circular(25),
                  border: Border.all(
                    color: primaryColor.withOpacity(0.5),
                  ),
                  boxShadow: neonGlow(opacity: 0.5),
                ),
                child: const Text(
                  "NEVERLOUS PROJECT ULTRA",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                    letterSpacing: 1,
                  ),
                ),
              ),
            );
          },
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 8),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: primaryColor.withOpacity(0.5)),
              boxShadow: neonGlow(blur: 8, spread: 0.3, opacity: 0.4),
            ),
            child: IconButton(
              icon: Icon(Icons.headset_mic_rounded,
                  color: accentColor, size: 20),
              onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (context) => const ContactPage())),
            ),
          ),
          Container(
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: primaryColor.withOpacity(0.5)),
              boxShadow: neonGlow(blur: 8, spread: 0.3, opacity: 0.4),
            ),
            child: IconButton(
              icon: Icon(FontAwesomeIcons.circleUser,
                  color: accentColor, size: 20),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (context) => ProfilePage(
                        username: username,
                        password: password,
                        role: role,
                        expiredDate: expiredDate,
                        sessionKey: sessionKey)),
              ),
            ),
          ),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: Stack(
        children: [
          // Background
          Container(
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topCenter,
                radius: 1.5,
                colors: [
                  Color(0xFF0F2547),
                  Color(0xFF050B1A),
                  Color(0xFF000000),
                ],
                stops: [0.0, 0.5, 1.0],
              ),
            ),
          ),

          // 3D Bubbles
          Positioned.fill(
            child: CustomPaint(
              painter: _DashboardBubblePainter3D(
                color: accentColor.withOpacity(0.12),
                count: 20,
                animation: _bubbleAnimationController,
              ),
            ),
          ),

          // Glow Orbs
          Positioned(
            top: -80,
            right: -80,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    primaryColor.withOpacity(0.25),
                    Colors.transparent,
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: primaryColor.withOpacity(0.3),
                    blurRadius: 80,
                    spreadRadius: 40,
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: -40,
            left: -60,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    accentColor.withOpacity(0.15),
                    Colors.transparent,
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: accentColor.withOpacity(0.2),
                    blurRadius: 60,
                    spreadRadius: 30,
                  ),
                ],
              ),
            ),
          ),

          // Konten
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: _bottomNavIndex == 0
                    ? _buildDashboardHome()
                    : _bottomNavIndex == 4
                        ? _toolsPage
                        : _selectedPage,
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(28),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
            child: Container(
              height: 58,
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.5),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(
                  color: primaryColor.withOpacity(0.35),
                  width: 1,
                ),
                boxShadow: neonGlow(opacity: 0.4),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildNavItem(Icons.home_rounded, "Home", 0),
                    _buildNavItem(FontAwesomeIcons.whatsapp, "WhatsApp", 1),
                    _buildNavItem(Icons.devices_rounded, "Rat", 2),
                    _buildNavItem(Icons.info_rounded, "Info", 3),
                    _buildNavItem(Icons.handyman_rounded, "Tools", 4),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    _onlineTimer?.cancel();
    _clockTimer?.cancel();
    _serverTimer?.cancel();
    _digitalClockTimer?.cancel();
    _channel?.sink.close(status.goingAway);
    _animationController.dispose();
    _bubbleAnimationController.dispose();
    _buttonPulseController.dispose();
    _qaPageController.dispose();
    super.dispose();
  }
}

class _QuickActionData {
  final IconData icon;
  final IconData bgIcon;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  final List<Color> rainbowColors;
  final VoidCallback onTap;

  const _QuickActionData({
    required this.icon,
    required this.bgIcon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.rainbowColors,
    required this.onTap,
  });
}