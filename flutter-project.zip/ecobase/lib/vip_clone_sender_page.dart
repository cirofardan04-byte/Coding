import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class VipCloneSenderPage extends StatefulWidget {
  final String sessionKey;
  const VipCloneSenderPage({super.key, required this.sessionKey});

  @override
  State<VipCloneSenderPage> createState() => _VipCloneSenderPageState();
}

class _VipCloneSenderPageState extends State<VipCloneSenderPage>
    with TickerProviderStateMixin {
  static const String baseUrl = 'http://raulllll.panelantirusuh.biz.id:10361';

  List<Map<String, dynamic>> _senders = [];
  bool _isLoading = false;
  String? _errorMsg;
  final Set<String> _cloningIds = {};

  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  late VideoPlayerController _backgroundVideoController;
  bool _backgroundVideoInitialized = false;

  // ====== NEON BLUE LIGHT THEME (BLACK BASE) ======
  final Color primaryColor = const Color(0xFF00B0FF);
  final Color accentColor = const Color(0xFF00B0FF);
  final Color backgroundColor = const Color(0xFF000000);
  final Color surfaceColor = const Color(0xFF050B1A);
  final Color cardColor = const Color(0xFF0F2547);
  final Color textPrimary = Colors.white;
  final Color textSecondary = const Color(0xFFB3E5FC);

  // White glow helper (dual shadow)
  List<BoxShadow> neonGlow({
    Color color = const Color(0xFF00B0FF),
    double blur = 16,
    double spread = 1.5,
    double opacity = 0.55,
  }) {
    return [
      BoxShadow(
        color: color.withOpacity(opacity),
        blurRadius: blur,
        spreadRadius: spread,
      ),
      BoxShadow(
        color: Colors.white.withOpacity(0.18),
        blurRadius: blur * 0.6,
        spreadRadius: 0.5,
      ),
    ];
  }

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
    _fetchSenders();
    _initBackgroundVideo();
  }

  void _initBackgroundVideo() {
    _backgroundVideoController =
        VideoPlayerController.asset('assets/videos/splash.mp4')
          ..initialize().then((_) {
            if (mounted) {
              setState(() => _backgroundVideoInitialized = true);
              _backgroundVideoController.setLooping(true);
              _backgroundVideoController.setVolume(0);
              _backgroundVideoController.play();
            }
          }).catchError((error) {
            debugPrint("Background video error: $error");
          });
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _backgroundVideoController.dispose();
    super.dispose();
  }

  Future<void> _fetchSenders() async {
    setState(() {
      _isLoading = true;
      _errorMsg = null;
    });
    try {
      final res = await http
          .get(Uri.parse('$baseUrl/scanSenders?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        setState(() {
          _senders = List<Map<String, dynamic>>.from(data['senders'] ?? []);
        });
      } else {
        setState(() => _errorMsg = data['message'] ?? 'Gagal memuat data.');
      }
    } catch (e) {
      setState(() => _errorMsg = 'Koneksi gagal: $e');
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _cloneSender(Map<String, dynamic> sender) async {
    final uid = '${sender['ownerUsername']}_${sender['sessionName']}';
    setState(() => _cloningIds.add(uid));

    try {
      final res = await http
          .post(
            Uri.parse('$baseUrl/cloneSender'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'key': widget.sessionKey,
              'sessionName': sender['sessionName'],
              'ownerUsername': sender['ownerUsername'],
            }),
          )
          .timeout(const Duration(seconds: 20));

      final data = jsonDecode(res.body);
      if (!mounted) return;

      if (data['valid'] == true) {
        _showSnack('✅ ${data['message']}', isError: false);
        setState(() {
          final idx = _senders.indexWhere((s) =>
              s['sessionName'] == sender['sessionName'] &&
              s['ownerUsername'] == sender['ownerUsername']);
          if (idx != -1) _senders[idx]['alreadyCloned'] = true;
        });
      } else {
        _showSnack('❌ ${data['message'] ?? 'Gagal clone sender.'}');
      }
    } catch (e) {
      if (mounted) _showSnack('❌ Koneksi gagal: $e');
    } finally {
      if (mounted) setState(() => _cloningIds.remove(uid));
    }
  }

  void _showSnack(String msg, {bool isError = true}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg,
          style: const TextStyle(color: Colors.white, fontSize: 12)),
      backgroundColor: isError ? Colors.red.shade700 : Colors.green.shade700,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 3),
    ));
  }

  Color _roleColor(String role) {
    switch (role.toLowerCase()) {
      case 'dev':
      case 'developer':
        return const Color(0xFFFFD700);
      case 'ceo':
        return const Color(0xFFFF6B35);
      case 'high_admin':
        return const Color(0xFFFF4757);
      case 'owner':
        return const Color(0xFFFF6B81);
      case 'admin':
        return const Color(0xFFECCC68);
      case 'reseller':
        return const Color(0xFF70A1FF);
      case 'vip':
        return const Color(0xFFA29BFE);
      case 'trial':
        return const Color(0xFF607D8B);
      default:
        return const Color(0xFF57606F);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: primaryColor.withOpacity(0.45)),
              boxShadow: neonGlow(blur: 8, spread: 0.3, opacity: 0.35),
            ),
            child:
                Icon(Icons.arrow_back_ios_new, color: accentColor, size: 18),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [primaryColor, accentColor]),
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: primaryColor.withOpacity(0.6),
                blurRadius: 16,
                spreadRadius: 1,
              ),
              BoxShadow(
                color: Colors.white.withOpacity(0.2),
                blurRadius: 8,
              ),
            ],
          ),
          child: const Text(
            'SCAN SENDER',
            style: TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
        ),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: primaryColor.withOpacity(0.45)),
              boxShadow: neonGlow(blur: 8, spread: 0.3, opacity: 0.35),
            ),
            child: IconButton(
              icon: Icon(Icons.refresh_rounded, color: accentColor),
              onPressed: _fetchSenders,
              tooltip: 'Refresh',
            ),
          ),
        ],
      ),
      body: Stack(
        children: [
          if (_backgroundVideoInitialized)
            SizedBox(
              width: double.infinity,
              height: double.infinity,
              child: VideoPlayer(_backgroundVideoController),
            )
          else
            Container(color: backgroundColor),

          // Overlay biru neon gelap
          Container(
            color: const Color(0xFF001028).withOpacity(0.6),
          ),

          RefreshIndicator(
            color: accentColor,
            backgroundColor: surfaceColor,
            onRefresh: _fetchSenders,
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildInfoCard(),
                  const SizedBox(height: 20),
                  if (_isLoading)
                    _buildLoadingState()
                  else if (_errorMsg != null)
                    _buildErrorState()
                  else if (_senders.isEmpty)
                    _buildEmptyState()
                  else
                    _buildSenderList(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoCard() => Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: surfaceColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: primaryColor.withOpacity(0.45)),
          boxShadow: neonGlow(blur: 14, spread: 0.5, opacity: 0.35),
        ),
        child: Row(children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [primaryColor, accentColor]),
              borderRadius: BorderRadius.circular(8),
              boxShadow: neonGlow(blur: 10, spread: 0.5, opacity: 0.6),
            ),
            child:
                const Icon(Icons.radar_rounded, color: Colors.white, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
              child:
                  Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('VIP Sender Scanner',
                style: TextStyle(
                    color: accentColor,
                    fontWeight: FontWeight.bold,
                    fontSize: 13,
                    letterSpacing: 1,
                    shadows: [
                      Shadow(
                        color: accentColor.withOpacity(0.5),
                        blurRadius: 10,
                      ),
                    ])),
            const SizedBox(height: 3),
            Text(
              'Scan sender aktif dari semua akun. Klik Tambah untuk clone ke private sender kamu.',
              style: TextStyle(color: textSecondary, fontSize: 11, height: 1.4),
            ),
          ])),
        ]),
      );

  Widget _buildLoadingState() => Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 60),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            AnimatedBuilder(
              animation: _pulseAnim,
              builder: (_, __) => Transform.scale(
                scale: _pulseAnim.value,
                child: Icon(Icons.radar_rounded,
                    color: accentColor, size: 48),
              ),
            ),
            const SizedBox(height: 16),
            Text('Scanning sender aktif...',
                style: TextStyle(
                    color: accentColor, fontSize: 12, letterSpacing: 1)),
          ]),
        ),
      );

  Widget _buildErrorState() => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.red.withOpacity(0.12),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.red.withOpacity(0.45)),
          boxShadow: [
            BoxShadow(
              color: Colors.red.withOpacity(0.4),
              blurRadius: 12,
            ),
            BoxShadow(
              color: Colors.white.withOpacity(0.15),
              blurRadius: 6,
            ),
          ],
        ),
        child: Row(children: [
          const Icon(Icons.error_outline_rounded, color: Colors.red, size: 20),
          const SizedBox(width: 10),
          Expanded(
              child: Text(_errorMsg!,
                  style: const TextStyle(color: Colors.red, fontSize: 12))),
        ]),
      );

  Widget _buildEmptyState() => Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 60),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.wifi_off_rounded,
                color: accentColor.withOpacity(0.5), size: 48),
            const SizedBox(height: 12),
            Text('Tidak ada sender aktif ditemukan',
                style: TextStyle(color: textSecondary, fontSize: 13)),
            const SizedBox(height: 6),
            Text('Refresh untuk scan ulang',
                style:
                    TextStyle(color: textSecondary.withOpacity(0.5), fontSize: 11)),
          ]),
        ),
      );

  Widget _buildSenderList() => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(children: [
            Icon(Icons.sensors_rounded, color: accentColor, size: 16),
            const SizedBox(width: 6),
            Text(
              '${_senders.length} SENDER DITEMUKAN',
              style: TextStyle(
                color: accentColor,
                fontSize: 11,
                fontWeight: FontWeight.bold,
                letterSpacing: 1.5,
                shadows: [
                  Shadow(
                    color: accentColor.withOpacity(0.4),
                    blurRadius: 8,
                  ),
                ],
              ),
            ),
          ]),
          const SizedBox(height: 12),
          ..._senders.map((sender) => _buildSenderCard(sender)),
        ],
      );

  Widget _buildSenderCard(Map<String, dynamic> sender) {
    final uid = '${sender['ownerUsername']}_${sender['sessionName']}';
    final isCloning = _cloningIds.contains(uid);
    final alreadyCloned = sender['alreadyCloned'] == true;
    final roleColor = _roleColor(sender['ownerRole'] ?? 'member');

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: alreadyCloned
              ? Colors.green.withOpacity(0.6)
              : primaryColor.withOpacity(0.45),
        ),
        boxShadow: alreadyCloned
            ? [
                BoxShadow(
                  color: Colors.green.withOpacity(0.4),
                  blurRadius: 12,
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.15),
                  blurRadius: 6,
                ),
              ]
            : neonGlow(blur: 10, spread: 0.5, opacity: 0.35),
      ),
      child: Row(children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [primaryColor, accentColor]),
            borderRadius: BorderRadius.circular(10),
            boxShadow: neonGlow(blur: 10, spread: 0.5, opacity: 0.55),
          ),
          child: Icon(
            alreadyCloned
                ? Icons.check_circle_rounded
                : Icons.phone_android_rounded,
            color: Colors.white,
            size: 20,
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(
            sender['sessionName'] ?? '-',
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 13,
            ),
          ),
          const SizedBox(height: 4),
          Row(children: [
            const Icon(Icons.person_rounded, size: 11, color: Colors.white38),
            const SizedBox(width: 3),
            Text(
              sender['ownerUsername'] ?? '-',
              style: const TextStyle(color: Colors.white54, fontSize: 11),
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: roleColor.withOpacity(0.18),
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: roleColor.withOpacity(0.5)),
                boxShadow: [
                  BoxShadow(
                    color: roleColor.withOpacity(0.4),
                    blurRadius: 6,
                  ),
                  BoxShadow(
                    color: Colors.white.withOpacity(0.12),
                    blurRadius: 3,
                  ),
                ],
              ),
              child: Text(
                (sender['ownerRole'] ?? 'member').toUpperCase(),
                style: TextStyle(
                    color: roleColor,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 0.8),
              ),
            ),
          ]),
          if (alreadyCloned) ...[
            const SizedBox(height: 4),
            Text('✓ Sudah di-clone ke private sender',
                style: TextStyle(color: Colors.green.shade400, fontSize: 10)),
          ],
        ])),
        if (alreadyCloned)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.green.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.green.withOpacity(0.5)),
              boxShadow: [
                BoxShadow(
                  color: Colors.green.withOpacity(0.4),
                  blurRadius: 10,
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.15),
                  blurRadius: 5,
                ),
              ],
            ),
            child: const Text('Cloned',
                style: TextStyle(
                    color: Colors.green,
                    fontSize: 11,
                    fontWeight: FontWeight.bold)),
          )
        else if (isCloning)
          SizedBox(
            width: 20,
            height: 20,
            child: CircularProgressIndicator(
                strokeWidth: 2, color: accentColor),
          )
        else
          GestureDetector(
            onTap: () => _showConfirmDialog(sender),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [primaryColor, accentColor]),
                borderRadius: BorderRadius.circular(8),
                boxShadow: neonGlow(blur: 10, spread: 0.5, opacity: 0.55),
              ),
              child: const Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.add_rounded, color: Colors.white, size: 14),
                SizedBox(width: 4),
                Text('Tambah',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.bold,
                    )),
              ]),
            ),
          ),
      ]),
    );
  }

  void _showConfirmDialog(Map<String, dynamic> sender) {
    final roleColor = _roleColor(sender['ownerRole'] ?? 'member');

    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: TweenAnimationBuilder(
          duration: const Duration(milliseconds: 300),
          tween: Tween<double>(begin: 0, end: 1),
          builder: (context, double scale, child) {
            return Transform.scale(scale: scale, child: child);
          },
          child: Container(
            margin: const EdgeInsets.all(20),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(32),
              border:
                  Border.all(color: primaryColor.withOpacity(0.55), width: 1.5),
              boxShadow: neonGlow(blur: 20, spread: 1, opacity: 0.5),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient:
                        LinearGradient(colors: [primaryColor, accentColor]),
                    shape: BoxShape.circle,
                    boxShadow: neonGlow(opacity: 0.6),
                  ),
                  child: const Icon(Icons.copy_all_rounded,
                      color: Colors.white, size: 28),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Clone Sender",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Clone sender ini ke private sender kamu?',
                  style: TextStyle(color: textSecondary, fontSize: 13),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: surfaceColor,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: primaryColor.withOpacity(0.45)),
                    boxShadow: neonGlow(blur: 10, spread: 0.5, opacity: 0.3),
                  ),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _infoRow('Sender', sender['sessionName'] ?? '-'),
                        const SizedBox(height: 6),
                        _infoRow(
                            'Dari akun', sender['ownerUsername'] ?? '-'),
                        const SizedBox(height: 6),
                        _infoRow('Role',
                            (sender['ownerRole'] ?? 'member').toUpperCase(),
                            color: roleColor),
                      ]),
                ),
                const SizedBox(height: 12),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF59E0B).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                        color: const Color(0xFFF59E0B).withOpacity(0.5)),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFF59E0B).withOpacity(0.4),
                        blurRadius: 10,
                      ),
                      BoxShadow(
                        color: Colors.white.withOpacity(0.12),
                        blurRadius: 5,
                      ),
                    ],
                  ),
                  child: const Row(
                    children: [
                      Icon(Icons.info_outline,
                          color: Color(0xFFF59E0B), size: 16),
                      SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'Sender asli tidak akan terhapus. Clone akan aktif di private sender kamu dan bisa dipakai untuk bug.',
                          style: TextStyle(
                              color: Color(0xFFF59E0B),
                              fontSize: 10,
                              height: 1.4),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.06),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                                color: Colors.white.withOpacity(0.2)),
                          ),
                          child: Center(
                            child: Text(
                              "BATAL",
                              style: TextStyle(
                                  color: textSecondary,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                          _cloneSender(sender);
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                                colors: [primaryColor, accentColor]),
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: neonGlow(
                                blur: 12, spread: 0.5, opacity: 0.55),
                          ),
                          child: const Center(
                            child: Text(
                              "CLONE",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _infoRow(String label, String val, {Color? color}) => Row(
        children: [
          Text('$label: ',
              style: TextStyle(color: textSecondary, fontSize: 12)),
          Text(val,
              style: TextStyle(
                  color: color ?? accentColor,
                  fontSize: 12,
                  fontWeight: FontWeight.bold)),
        ],
      );
}