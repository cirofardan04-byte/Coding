// minibrowser_tool.dart
// Mini Browser dengan URL bar bebas - Tema Neon Blue Light

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';

class MiniBrowserToolPage extends StatefulWidget {
  const MiniBrowserToolPage({super.key});

  @override
  State<MiniBrowserToolPage> createState() => _MiniBrowserToolPageState();
}

class _MiniBrowserToolPageState extends State<MiniBrowserToolPage> {
  late final WebViewController _controller;
  final TextEditingController _urlController =
      TextEditingController(text: 'https://www.google.com');
  bool _isLoading = true;
  bool _hasError = false;
  int _loadingProgress = 0;
  bool _isEditingUrl = false;

  // ====== NEON BLUE LIGHT THEME (BLACK BASE) ======
  final Color primaryColor = const Color(0xFF00B0FF);
  final Color accentColor = const Color(0xFF00B0FF);
  final Color backgroundColor = const Color(0xFF000000);
  final Color surfaceColor = const Color(0xFF050B1A);
  final Color cardColor = const Color(0xFF0F2547);
  final Color textPrimary = Colors.white;
  final Color textSecondary = const Color(0xFFB3E5FC);

  // White glow helper (dual shadow)
  List<BoxShadow> neonGlow({
    Color color = const Color(0xFF00B0FF),
    double blur = 16,
    double spread = 1.5,
    double opacity = 0.55,
  }) {
    return [
      BoxShadow(
        color: color.withOpacity(opacity),
        blurRadius: blur,
        spreadRadius: spread,
      ),
      BoxShadow(
        color: Colors.white.withOpacity(0.18),
        blurRadius: blur * 0.6,
        spreadRadius: 0.5,
      ),
    ];
  }

  @override
  void initState() {
    super.initState();
    _initWebView();
  }

  @override
  void dispose() {
    _urlController.dispose();
    super.dispose();
  }

  void _initWebView() {
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(backgroundColor)
      ..setUserAgent(
        'Mozilla/5.0 (Linux; Android 14; Pixel 8) '
        'AppleWebKit/537.36 (KHTML, like Gecko) '
        'Chrome/124.0.0.0 Mobile Safari/537.36',
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (url) => setState(() {
            _isLoading = true;
            _hasError = false;
            _urlController.text = url;
          }),
          onProgress: (p) => setState(() => _loadingProgress = p),
          onPageFinished: (url) => setState(() {
            _isLoading = false;
            _urlController.text = url;
          }),
          onWebResourceError: (error) {
            if (error.isForMainFrame == true) {
              setState(() {
                _isLoading = false;
                _hasError = true;
              });
            }
          },
        ),
      )
      ..loadRequest(Uri.parse('https://www.google.com'));
  }

  void _navigateTo(String input) {
    String url = input.trim();
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      if (url.contains(' ') || !url.contains('.')) {
        url =
            'https://www.google.com/search?q=${Uri.encodeComponent(url)}';
      } else {
        url = 'https://$url';
      }
    }
    _controller.loadRequest(Uri.parse(url));
    setState(() => _isEditingUrl = false);
    FocusScope.of(context).unfocus();
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: backgroundColor,
        appBar: _buildAppBar(),
        body: _hasError ? _buildErrorState() : _buildBody(),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: backgroundColor,
      elevation: 0,
      leading: IconButton(
        icon: Icon(Icons.arrow_back_ios_new_rounded,
            color: accentColor, size: 20),
        onPressed: () async {
          if (await _controller.canGoBack()) {
            _controller.goBack();
          } else {
            if (mounted) Navigator.pop(context);
          }
        },
      ),
      title: GestureDetector(
        onTap: () => setState(() => _isEditingUrl = true),
        child: Container(
          height: 38,
          decoration: BoxDecoration(
            color: surfaceColor.withOpacity(0.7),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(
              color: _isEditingUrl
                  ? accentColor
                  : primaryColor.withOpacity(0.35),
              width: 1.5,
            ),
            boxShadow: _isEditingUrl
                ? neonGlow(blur: 12, spread: 0.5, opacity: 0.55)
                : [
                    BoxShadow(
                      color: primaryColor.withOpacity(0.25),
                      blurRadius: 10,
                    ),
                    BoxShadow(
                      color: Colors.white.withOpacity(0.1),
                      blurRadius: 5,
                    ),
                  ],
          ),
          child: Row(
            children: [
              const SizedBox(width: 12),
              Icon(
                Icons.public_rounded,
                color: _isEditingUrl
                    ? accentColor
                    : textSecondary.withOpacity(0.6),
                size: 16,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _isEditingUrl
                    ? TextField(
                        controller: _urlController,
                        autofocus: true,
                        style: TextStyle(
                          color: textPrimary,
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                        ),
                        cursorColor: accentColor,
                        decoration: const InputDecoration(
                          border: InputBorder.none,
                          isDense: true,
                          hintText: 'Cari atau masukkan URL...',
                          hintStyle: TextStyle(
                            color: Colors.white38,
                            fontSize: 12,
                          ),
                        ),
                        onSubmitted: _navigateTo,
                        textInputAction: TextInputAction.go,
                      )
                    : Text(
                        _urlController.text,
                        style: TextStyle(
                          color: textSecondary.withOpacity(0.85),
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
              ),
              if (_isEditingUrl)
                GestureDetector(
                  onTap: () {
                    _urlController.clear();
                  },
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: primaryColor.withOpacity(0.15),
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: primaryColor.withOpacity(0.4),
                        width: 0.8,
                      ),
                      boxShadow: neonGlow(
                          blur: 6, spread: 0.3, opacity: 0.4),
                    ),
                    child: Icon(
                      Icons.close_rounded,
                      color: textSecondary,
                      size: 16,
                    ),
                  ),
                ),
              const SizedBox(width: 8),
            ],
          ),
        ),
      ),
      actions: [
        Container(
          margin: const EdgeInsets.only(right: 4),
          decoration: BoxDecoration(
            color: surfaceColor.withOpacity(0.5),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: primaryColor.withOpacity(0.35),
              width: 0.8,
            ),
            boxShadow:
                neonGlow(blur: 8, spread: 0.3, opacity: 0.35),
          ),
          child: IconButton(
            icon: Icon(Icons.refresh_rounded,
                color: accentColor, size: 20),
            onPressed: () => _controller.reload(),
          ),
        ),
        const SizedBox(width: 4),
      ],
      bottom: _isLoading
          ? PreferredSize(
              preferredSize: const Size.fromHeight(3),
              child: LinearProgressIndicator(
                value: _loadingProgress / 100,
                backgroundColor: surfaceColor,
                valueColor:
                    AlwaysStoppedAnimation<Color>(accentColor),
                minHeight: 3,
              ),
            )
          : null,
    );
  }

  Widget _buildBody() {
    return Stack(
      children: [
        WebViewWidget(controller: _controller),
        if (_isLoading && _loadingProgress < 20)
          Container(
            color: backgroundColor,
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [primaryColor, accentColor],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(22),
                      boxShadow: neonGlow(
                          blur: 25, spread: 1.2, opacity: 0.6),
                    ),
                    child: const Icon(
                      Icons.public_rounded,
                      color: Colors.white,
                      size: 38,
                    ),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    'Memuat halaman...',
                    style: TextStyle(
                      color: textPrimary,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                      shadows: [
                        Shadow(
                          color: accentColor.withOpacity(0.5),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  SizedBox(
                    width: 180,
                    child: LinearProgressIndicator(
                      value: _loadingProgress / 100,
                      backgroundColor: surfaceColor,
                      valueColor: AlwaysStoppedAnimation<Color>(
                          accentColor),
                      borderRadius: BorderRadius.circular(10),
                      minHeight: 4,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: surfaceColor,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: primaryColor.withOpacity(0.4),
                        width: 0.8,
                      ),
                      boxShadow: neonGlow(
                          blur: 8, spread: 0.3, opacity: 0.4),
                    ),
                    child: Text(
                      '$_loadingProgress%',
                      style: TextStyle(
                        color: textSecondary,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: surfaceColor,
                borderRadius: BorderRadius.circular(22),
                border: Border.all(
                  color: Colors.redAccent.withOpacity(0.5),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.redAccent.withOpacity(0.4),
                    blurRadius: 15,
                  ),
                  BoxShadow(
                    color: Colors.white.withOpacity(0.15),
                    blurRadius: 8,
                  ),
                ],
              ),
              child: const Icon(
                Icons.wifi_off_rounded,
                color: Colors.redAccent,
                size: 40,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'Gagal Memuat',
              style: TextStyle(
                color: textPrimary,
                fontSize: 20,
                fontWeight: FontWeight.w700,
                letterSpacing: 1,
                shadows: [
                  Shadow(
                    color: accentColor.withOpacity(0.5),
                    blurRadius: 12,
                  ),
                  Shadow(
                    color: Colors.white.withOpacity(0.15),
                    blurRadius: 6,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Halaman tidak bisa dibuka.\nCek URL atau koneksi internet.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: textSecondary,
                fontSize: 13,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 28),
            GestureDetector(
              onTap: () => _controller.reload(),
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 32, vertical: 14),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [primaryColor, accentColor],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: neonGlow(
                      blur: 20, spread: 1, opacity: 0.6),
                ),
                child: const Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.refresh_rounded,
                        color: Colors.white, size: 18),
                    SizedBox(width: 10),
                    Text(
                      'Coba Lagi',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}