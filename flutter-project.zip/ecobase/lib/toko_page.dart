import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:flutter/services.dart';

class TokoPage extends StatefulWidget {
  const TokoPage({super.key});

  @override
  State<TokoPage> createState() => _TokoPageState();
}

class _TokoPageState extends State<TokoPage> {
  final List<Map<String, dynamic>> products = const [
    {
      "title": "NEVERLOUS PROJECT ULTRA",
      "desc":
          "Aplikasi canggih dengan berbagai fitur premium untuk keamanan dan kebutuhan Anda",
      "price": "BENEFIT PACKAGE",
      "badge": "PREMIUM",
      "icon": FontAwesomeIcons.crown,
      "features": [
        "Member 1 Bulan - Rp 20.000",
        "Member Full Update - Rp 30.000",
        "Reseller Permanent - Rp 50.000",
        "VIP Permanen - Rp 70.000",
        "Owner Permanen - Rp 100.000",
        "High Owner - Rp 150.000",
        "CEO Permanen - Rp 300.000",
      ],
      "link": "https://wa.me/6281929461098"
    },
  ];

  late VideoPlayerController _backgroundVideoController;
  bool _backgroundVideoInitialized = false;

  // ====== NEON BLUE LIGHT THEME (BLACK BASE) ======
  final Color primaryColor = const Color(0xFF00B0FF);
  final Color accentColor = const Color(0xFF00B0FF);
  final Color backgroundColor = const Color(0xFF000000);
  final Color surfaceColor = const Color(0xFF050B1A);
  final Color cardColor = const Color(0xFF0F2547);
  final Color textPrimary = Colors.white;
  final Color textSecondary = const Color(0xFFB3E5FC);

  // White glow helper (dual shadow)
  List<BoxShadow> neonGlow({
    Color color = const Color(0xFF00B0FF),
    double blur = 16,
    double spread = 1.5,
    double opacity = 0.55,
  }) {
    return [
      BoxShadow(
        color: color.withOpacity(opacity),
        blurRadius: blur,
        spreadRadius: spread,
      ),
      BoxShadow(
        color: Colors.white.withOpacity(0.18),
        blurRadius: blur * 0.6,
        spreadRadius: 0.5,
      ),
    ];
  }

  @override
  void initState() {
    super.initState();
    _initBackgroundVideo();
  }

  void _initBackgroundVideo() {
    _backgroundVideoController =
        VideoPlayerController.asset('assets/videos/splash.mp4')
          ..initialize().then((_) {
            if (mounted) {
              setState(() => _backgroundVideoInitialized = true);
              _backgroundVideoController.setLooping(true);
              _backgroundVideoController.setVolume(0);
              _backgroundVideoController.play();
            }
          }).catchError((error) {
            debugPrint("Background video error: $error");
          });
  }

  @override
  void dispose() {
    _backgroundVideoController.dispose();
    super.dispose();
  }

  Future<void> openLink(String url) async {
    final Uri uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  void _copyToClipboard(String text, String message) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(color: Colors.white)),
        backgroundColor: primaryColor,
        behavior: SnackBarBehavior.floating,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  void _showZoomableQRIS() {
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(10),
        child: GestureDetector(
          onTap: () => Navigator.pop(context),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: neonGlow(opacity: 0.6),
            ),
            child: InteractiveViewer(
              minScale: 0.5,
              maxScale: 4.0,
              child: Image.asset(
                'assets/images/qris.jpg',
                fit: BoxFit.contain,
                errorBuilder: (context, error, stackTrace) {
                  return Container(
                    height: 300,
                    width: 300,
                    color: Colors.grey.withOpacity(0.3),
                    child: const Center(
                      child: Text("QRIS Image",
                          style: TextStyle(color: Colors.black)),
                    ),
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [primaryColor, accentColor]),
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: primaryColor.withOpacity(0.6),
                blurRadius: 16,
                spreadRadius: 1,
              ),
              BoxShadow(
                color: Colors.white.withOpacity(0.2),
                blurRadius: 8,
              ),
            ],
          ),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.storefront_rounded,
                  color: Colors.white, size: 18),
              SizedBox(width: 8),
              Text(
                "NEVERLOUS PROJECT STORE",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: primaryColor.withOpacity(0.45)),
              boxShadow: neonGlow(blur: 8, spread: 0.3, opacity: 0.35),
            ),
            child:
                Icon(Icons.arrow_back_ios_new, color: accentColor, size: 18),
          ),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Stack(
        children: [
          if (_backgroundVideoInitialized)
            SizedBox(
              width: double.infinity,
              height: double.infinity,
              child: VideoPlayer(_backgroundVideoController),
            )
          else
            Container(color: backgroundColor),

          // Overlay biru neon gelap
          Container(
            color: const Color(0xFF001028).withOpacity(0.6),
          ),

          ListView.builder(
            padding: const EdgeInsets.only(
                top: 20, left: 20, right: 20, bottom: 40),
            physics: const BouncingScrollPhysics(),
            itemCount: products.length,
            itemBuilder: (context, index) {
              final item = products[index];
              return TweenAnimationBuilder(
                duration: Duration(milliseconds: 400 + (index * 150)),
                tween: Tween<double>(begin: 0, end: 1),
                builder: (context, double value, child) {
                  return Transform.translate(
                    offset: Offset(0, 30 * (1 - value)),
                    child: Opacity(opacity: value, child: child),
                  );
                },
                child: Container(
                  margin: const EdgeInsets.only(bottom: 28),
                  padding: const EdgeInsets.all(22),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(30),
                    color: surfaceColor,
                    border:
                        Border.all(color: primaryColor.withOpacity(0.5), width: 1.5),
                    boxShadow: neonGlow(
                        blur: 30, spread: 1.5, opacity: 0.45),
                  ),
                  child: Column(
                    children: [
                      Align(
                        alignment: Alignment.topRight,
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 18, vertical: 8),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                                colors: [primaryColor, accentColor]),
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: neonGlow(
                                blur: 14, spread: 0.5, opacity: 0.6),
                          ),
                          child: Text(
                            item["badge"],
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 13,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      Container(
                        width: 90,
                        height: 90,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          gradient: LinearGradient(
                              colors: [primaryColor, accentColor]),
                          boxShadow:
                              neonGlow(blur: 30, spread: 1, opacity: 0.6),
                        ),
                        child: Icon(item["icon"],
                            color: Colors.white, size: 40),
                      ),
                      const SizedBox(height: 25),
                      Text(
                        item["title"],
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: textPrimary,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          shadows: [
                            Shadow(
                              color: accentColor.withOpacity(0.3),
                              blurRadius: 10,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        item["desc"],
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: textSecondary,
                          fontSize: 14,
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 24),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 10),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              primaryColor.withOpacity(0.2),
                              accentColor.withOpacity(0.15),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(
                              color: accentColor.withOpacity(0.5)),
                          boxShadow: neonGlow(
                              blur: 12, spread: 0.5, opacity: 0.4),
                        ),
                        child: Text(
                          item["price"],
                          style: TextStyle(
                            color: accentColor,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                            shadows: [
                              Shadow(
                                color: accentColor.withOpacity(0.5),
                                blurRadius: 10,
                              ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 28),
                      SizedBox(
                        width: double.infinity,
                        height: 58,
                        child: OutlinedButton(
                          style: OutlinedButton.styleFrom(
                            side: BorderSide(
                                color: accentColor.withOpacity(0.8),
                                width: 1.5),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30)),
                            backgroundColor: surfaceColor,
                          ),
                          onPressed: () {
                            _showDetailModal(item);
                          },
                          child: Text(
                            "Lihat Detail",
                            style: TextStyle(
                              color: accentColor,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 18),
                      SizedBox(
                        width: double.infinity,
                        height: 60,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.transparent,
                            shadowColor: primaryColor.withOpacity(0.5),
                            elevation: 15,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30)),
                            padding: EdgeInsets.zero,
                          ),
                          onPressed: () {
                            _showPaymentModal(item);
                          },
                          child: Ink(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                  colors: [primaryColor, accentColor]),
                              borderRadius: BorderRadius.circular(30),
                              boxShadow: neonGlow(
                                  blur: 22, spread: 1, opacity: 0.6),
                            ),
                            child: Container(
                              alignment: Alignment.center,
                              child: const Text(
                                "Pesan Sekarang",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  void _showDetailModal(Map<String, dynamic> item) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (modalContext) {
        return Container(
          margin: const EdgeInsets.all(18),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: surfaceColor,
            borderRadius: BorderRadius.circular(30),
            border:
                Border.all(color: primaryColor.withOpacity(0.55), width: 1.5),
            boxShadow: neonGlow(blur: 30, spread: 1.5, opacity: 0.5),
          ),
          child: SafeArea(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        width: 45,
                        height: 45,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                              colors: [primaryColor, accentColor]),
                          shape: BoxShape.circle,
                          boxShadow: neonGlow(
                              blur: 12, spread: 0.5, opacity: 0.55),
                        ),
                        child: IconButton(
                          icon: const Icon(Icons.close,
                              color: Colors.white, size: 20),
                          onPressed: () => Navigator.pop(modalContext),
                        ),
                      ),
                      Text(
                        "DETAIL PRODUK",
                        style: TextStyle(
                          color: accentColor,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                          shadows: [
                            Shadow(
                              color: accentColor.withOpacity(0.5),
                              blurRadius: 10,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 45),
                    ],
                  ),
                  const SizedBox(height: 20),
                  Container(
                    width: 80,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient:
                          LinearGradient(colors: [primaryColor, accentColor]),
                      boxShadow:
                          neonGlow(blur: 25, spread: 1, opacity: 0.6),
                    ),
                    child:
                        Icon(item["icon"], color: Colors.white, size: 35),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    item["title"],
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: textPrimary,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    item["desc"],
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: textSecondary,
                      fontSize: 14,
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 30),
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: cardColor,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          color: primaryColor.withOpacity(0.45)),
                      boxShadow: neonGlow(
                          blur: 14, spread: 0.5, opacity: 0.35),
                    ),
                    child: Column(
                      children: List.generate(
                        (item["features"] as List<String>).length,
                        (index) {
                          final feature =
                              (item["features"] as List<String>)[index];
                          return Container(
                            margin: const EdgeInsets.only(bottom: 14),
                            child: Row(
                              children: [
                                Container(
                                  width: 24,
                                  height: 24,
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(colors: [
                                      primaryColor,
                                      accentColor
                                    ]),
                                    borderRadius: BorderRadius.circular(8),
                                    boxShadow: neonGlow(
                                        blur: 8,
                                        spread: 0.3,
                                        opacity: 0.5),
                                  ),
                                  child: const Icon(Icons.check,
                                      color: Colors.white, size: 14),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Text(
                                    feature,
                                    style: TextStyle(
                                      color: textPrimary,
                                      fontSize: 14,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),
                  SizedBox(
                    width: double.infinity,
                    height: 55,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        elevation: 10,
                        padding: EdgeInsets.zero,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30)),
                      ),
                      onPressed: () {
                        Navigator.pop(modalContext);
                        _showPaymentModal(item);
                      },
                      child: Ink(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                              colors: [primaryColor, accentColor]),
                          borderRadius: BorderRadius.circular(30),
                          boxShadow: neonGlow(
                              blur: 20, spread: 1, opacity: 0.55),
                        ),
                        child: const Center(
                          child: Text(
                            "Pesan Sekarang",
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 18,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void _showPaymentModal(Map<String, dynamic> item) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (modalContext) {
        return _PaymentModalContent(
          modalContext: modalContext,
          item: item,
          primaryColor: primaryColor,
          accentColor: accentColor,
          surfaceColor: surfaceColor,
          cardColor: cardColor,
          textPrimary: textPrimary,
          textSecondary: textSecondary,
          openLink: openLink,
          copyToClipboard: _copyToClipboard,
          onTapQRIS: _showZoomableQRIS,
        );
      },
    );
  }
}

// ================= PAYMENT MODAL CONTENT =================
class _PaymentModalContent extends StatefulWidget {
  final BuildContext modalContext;
  final Map<String, dynamic> item;
  final Color primaryColor;
  final Color accentColor;
  final Color surfaceColor;
  final Color cardColor;
  final Color textPrimary;
  final Color textSecondary;
  final Function(String) openLink;
  final Function(String, String) copyToClipboard;
  final VoidCallback onTapQRIS;

  const _PaymentModalContent({
    required this.modalContext,
    required this.item,
    required this.primaryColor,
    required this.accentColor,
    required this.surfaceColor,
    required this.cardColor,
    required this.textPrimary,
    required this.textSecondary,
    required this.openLink,
    required this.copyToClipboard,
    required this.onTapQRIS,
  });

  @override
  State<_PaymentModalContent> createState() => _PaymentModalContentState();
}

class _PaymentModalContentState extends State<_PaymentModalContent> {
  String _selectedPaymentMethod = 'qris';
  String _selectedProduct = '';

  List<BoxShadow> _neonGlow({
    Color? color,
    double blur = 16,
    double spread = 1.2,
    double opacity = 0.5,
  }) {
    final c = color ?? widget.primaryColor;
    return [
      BoxShadow(
        color: c.withOpacity(opacity),
        blurRadius: blur,
        spreadRadius: spread,
      ),
      BoxShadow(
        color: Colors.white.withOpacity(0.18),
        blurRadius: blur * 0.6,
        spreadRadius: 0.5,
      ),
    ];
  }

  @override
  void initState() {
    super.initState();
    _selectedProduct = (widget.item["features"] as List<String>)[0];
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(18),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: widget.surfaceColor,
        borderRadius: BorderRadius.circular(30),
        border:
            Border.all(color: widget.primaryColor.withOpacity(0.55), width: 1.5),
        boxShadow: _neonGlow(blur: 30, spread: 1.5, opacity: 0.5),
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 45,
                    height: 45,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                          colors: [widget.primaryColor, widget.accentColor]),
                      shape: BoxShape.circle,
                      boxShadow: _neonGlow(
                          blur: 12, spread: 0.5, opacity: 0.55),
                    ),
                    child: IconButton(
                      icon: const Icon(Icons.arrow_back_ios_new,
                          color: Colors.white, size: 20),
                      onPressed: () => Navigator.pop(widget.modalContext),
                    ),
                  ),
                  Text(
                    "PEMBAYARAN",
                    style: TextStyle(
                      color: widget.accentColor,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1,
                      shadows: [
                        Shadow(
                          color: widget.accentColor.withOpacity(0.5),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 45),
                ],
              ),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: widget.cardColor,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                      color: widget.primaryColor.withOpacity(0.45)),
                  boxShadow: _neonGlow(
                      blur: 12, spread: 0.5, opacity: 0.3),
                ),
                child: Row(
                  children: [
                    Icon(Icons.shopping_bag_rounded,
                        color: widget.accentColor, size: 24),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Produk Dipilih",
                            style: TextStyle(
                                color: widget.textSecondary, fontSize: 11),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            _selectedProduct,
                            style: TextStyle(
                                color: widget.textPrimary,
                                fontSize: 14,
                                fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                  color: widget.cardColor,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                      color: widget.primaryColor.withOpacity(0.45)),
                  boxShadow: _neonGlow(
                      blur: 12, spread: 0.5, opacity: 0.3),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: _selectedProduct,
                    dropdownColor: widget.surfaceColor,
                    style:
                        TextStyle(color: widget.textPrimary, fontSize: 14),
                    isExpanded: true,
                    icon: Icon(Icons.arrow_drop_down,
                        color: widget.accentColor),
                    items: (widget.item["features"] as List<String>)
                        .map((product) {
                      return DropdownMenuItem(
                        value: product,
                        child: Text(product,
                            style: TextStyle(color: widget.textPrimary)),
                      );
                    }).toList(),
                    onChanged: (value) {
                      if (value != null) {
                        setState(() => _selectedProduct = value);
                      }
                    },
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Text(
                "METODE PEMBAYARAN",
                style: TextStyle(
                  color: widget.textSecondary,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  _buildPaymentMethodButton(
                      "QRIS", Icons.qr_code_scanner_rounded, 'qris'),
                  const SizedBox(width: 12),
                  _buildPaymentMethodButton(
                      "DANA", FontAwesomeIcons.wallet, 'dana'),
                  const SizedBox(width: 12),
                  _buildPaymentMethodButton("SeaBank",
                      Icons.account_balance_rounded, 'seabank'),
                ],
              ),
              const SizedBox(height: 24),
              if (_selectedPaymentMethod == 'qris') _buildQrisContent(),
              if (_selectedPaymentMethod == 'dana') _buildDanaContent(),
              if (_selectedPaymentMethod == 'seabank')
                _buildSeaBankContent(),
              const SizedBox(height: 20),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: widget.cardColor,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                      color: widget.primaryColor.withOpacity(0.45)),
                  boxShadow: _neonGlow(
                      blur: 12, spread: 0.5, opacity: 0.3),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.info_outline,
                            color: widget.accentColor, size: 18),
                        const SizedBox(width: 8),
                        Text(
                          "CARA MEMBELI",
                          style: TextStyle(
                            color: widget.accentColor,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Text(
                      "1. Pilih produk yang diinginkan\n2. Transfer ke QRIS / DANA / SeaBank sesuai nominal produk\n3. Screenshot bukti transfer\n4. Kirim bukti transfer ke Contact di bawah",
                      style: TextStyle(
                        color: widget.textSecondary,
                        fontSize: 12,
                        height: 1.6,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: _buildContactButton(
                      icon: FontAwesomeIcons.whatsapp,
                      label: "WhatsApp",
                      color: const Color(0xFF25D366),
                      url: "https://wa.me/6281929461098",
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: _buildContactButton(
                      icon: FontAwesomeIcons.telegram,
                      label: "Telegram",
                      color: const Color(0xFF0088cc),
                      url: "https://t.me/kaichonew",
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPaymentMethodButton(
      String label, IconData icon, String method) {
    final isSelected = _selectedPaymentMethod == method;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _selectedPaymentMethod = method),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            gradient: isSelected
                ? LinearGradient(
                    colors: [widget.primaryColor, widget.accentColor])
                : null,
            color: isSelected ? null : widget.cardColor,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isSelected
                  ? widget.accentColor
                  : widget.primaryColor.withOpacity(0.45),
              width: isSelected ? 1.5 : 1,
            ),
            boxShadow:
                isSelected ? _neonGlow(blur: 12, spread: 0.5, opacity: 0.6) : null,
          ),
          child: Column(
            children: [
              Icon(icon,
                  color: isSelected ? Colors.white : widget.accentColor,
                  size: 22),
              const SizedBox(height: 6),
              Text(
                label,
                style: TextStyle(
                  color: isSelected ? Colors.white : widget.textSecondary,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQrisContent() {
    return Column(
      children: [
        GestureDetector(
          onTap: widget.onTapQRIS,
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              border:
                  Border.all(color: widget.primaryColor.withOpacity(0.5)),
              boxShadow: _neonGlow(blur: 20, spread: 1, opacity: 0.5),
            ),
            child: Stack(
              children: [
                Image.asset(
                  'assets/images/qris.jpg',
                  height: 200,
                  width: 200,
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      height: 200,
                      width: 200,
                      color: Colors.grey.withOpacity(0.3),
                      child: const Center(
                        child: Text("QRIS Image",
                            style: TextStyle(color: Colors.black)),
                      ),
                    );
                  },
                ),
                Positioned(
                  bottom: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.6),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.zoom_in, color: Colors.white, size: 16),
                        SizedBox(width: 4),
                        Text(
                          "Tap to zoom",
                          style:
                              TextStyle(color: Colors.white, fontSize: 10),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          "Scan QRIS di atas untuk melakukan pembayaran\n(Tap gambar untuk memperbesar)",
          style: TextStyle(color: widget.textSecondary, fontSize: 12),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildDanaContent() {
    const danaNumber = "085777069326";
    const danaName = "HERNAWATI";

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: widget.cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: widget.primaryColor.withOpacity(0.45)),
        boxShadow: _neonGlow(blur: 12, spread: 0.5, opacity: 0.3),
      ),
      child: Column(
        children: [
          _buildInfoRow(
              "No. DANA",
              danaNumber,
              true,
              () => widget.copyToClipboard(
                  danaNumber, "No DANA berhasil disalin!")),
          const SizedBox(height: 12),
          _buildInfoRow("Nama", danaName, false, null),
        ],
      ),
    );
  }

  Widget _buildSeaBankContent() {
    const seabankNumber = "085777069326";
    const seabankName = "HERNAWATI";

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: widget.cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: widget.primaryColor.withOpacity(0.45)),
        boxShadow: _neonGlow(blur: 12, spread: 0.5, opacity: 0.3),
      ),
      child: Column(
        children: [
          _buildInfoRow(
              "No. Rekening",
              seabankNumber,
              true,
              () => widget.copyToClipboard(
                  seabankNumber, "No Rekening berhasil disalin!")),
          const SizedBox(height: 12),
          _buildInfoRow("Nama", seabankName, false, null),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String label, String value, bool showCopyButton,
      VoidCallback? onCopy) {
    return Row(
      children: [
        Expanded(
          flex: 3,
          child: Text(
            "$label:",
            style: TextStyle(color: widget.textSecondary, fontSize: 13),
          ),
        ),
        Expanded(
          flex: 5,
          child: Text(
            value,
            style: TextStyle(
                color: widget.textPrimary,
                fontSize: 13,
                fontWeight: FontWeight.w500),
            overflow: TextOverflow.ellipsis,
          ),
        ),
        if (showCopyButton)
          Expanded(
            flex: 2,
            child: GestureDetector(
              onTap: onCopy,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  color: widget.primaryColor.withOpacity(0.18),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                      color: widget.primaryColor.withOpacity(0.45)),
                  boxShadow: _neonGlow(
                      blur: 8, spread: 0.3, opacity: 0.4),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.copy, color: widget.accentColor, size: 12),
                    const SizedBox(width: 4),
                    Text(
                      "Salin",
                      style: TextStyle(
                          color: widget.accentColor,
                          fontSize: 9,
                          fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
            ),
          )
        else
          const Expanded(flex: 2, child: SizedBox()),
      ],
    );
  }

  Widget _buildContactButton({
    required IconData icon,
    required String label,
    required Color color,
    required String url,
  }) {
    return GestureDetector(
      onTap: () => widget.openLink(url),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: color.withOpacity(0.5), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.35),
              blurRadius: 12,
            ),
            BoxShadow(
              color: Colors.white.withOpacity(0.15),
              blurRadius: 6,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            FaIcon(icon, color: color, size: 18),
            const SizedBox(width: 8),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}