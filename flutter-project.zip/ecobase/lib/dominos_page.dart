// dominos_page.dart — Game Domino (Neon Blue Light)
import 'dart:math';
import 'package:flutter/material.dart';

class DominosPage extends StatefulWidget {
  const DominosPage({super.key});

  @override
  State<DominosPage> createState() => _DominosPageState();
}

class _DominosPageState extends State<DominosPage> {
  final Color primaryColor = const Color(0xFF00B0FF);
  final Color accentColor = const Color(0xFF00B0FF);
  final Color cardColor = const Color(0xFF0F2547);
  final Color surfaceColor = const Color(0xFF050B1A);
  final Color backgroundColor = const Color(0xFF000000);
  final Color textSecondary = const Color(0xFFB3E5FC);

  final List<List<int>> _deck = [];
  final List<List<int>> _playerHand = [];
  final List<List<int>> _aiHand = [];
  final List<List<int>> _board = [];
  bool _playerTurn = true;
  String _status = 'Giliran kamu';
  int _playerScore = 0;
  int _aiScore = 0;

  @override
  void initState() {
    super.initState();
    _startNewGame();
  }

  void _startNewGame() {
    _deck.clear();
    _playerHand.clear();
    _aiHand.clear();
    _board.clear();
    for (int i = 0; i <= 6; i++) {
      for (int j = i; j <= 6; j++) {
        _deck.add([i, j]);
      }
    }
    _deck.shuffle(Random());
    for (int i = 0; i < 7; i++) {
      _playerHand.add(_deck.removeLast());
      _aiHand.add(_deck.removeLast());
    }
    setState(() {
      _playerTurn = true;
      _status = 'Giliran kamu';
    });
  }

  bool _canPlay(List<int> tile) {
    if (_board.isEmpty) return true;
    final left = _board.first[0];
    final right = _board.last[1];
    return tile[0] == left ||
        tile[1] == left ||
        tile[0] == right ||
        tile[1] == right;
  }

  void _playTile(int index) {
    if (!_playerTurn) return;
    final tile = _playerHand[index];
    if (!_canPlay(tile)) {
      setState(() => _status = 'Kartu tidak cocok!');
      return;
    }
    setState(() {
      _playerHand.removeAt(index);
      _board.add(tile);
      _playerTurn = false;
      _status = 'Giliran AI...';
    });
    Future.delayed(const Duration(milliseconds: 800), _aiMove);
  }

  void _aiMove() {
    for (int i = 0; i < _aiHand.length; i++) {
      if (_canPlay(_aiHand[i])) {
        setState(() {
          _board.add(_aiHand.removeAt(i));
          _playerTurn = true;
          _status = 'Giliran kamu';
        });
        _checkWinner();
        return;
      }
    }
    setState(() {
      _playerTurn = true;
      _status = 'AI pass. Giliran kamu';
    });
  }

  void _checkWinner() {
    if (_playerHand.isEmpty) {
      _playerScore++;
      _showResult('🎉 Kamu Menang!');
    } else if (_aiHand.isEmpty) {
      _aiScore++;
      _showResult('😢 AI Menang!');
    }
  }

  void _showResult(String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: accentColor.withOpacity(0.5)),
        ),
        title: Text(msg, style: const TextStyle(color: Colors.white)),
        content: Text('Skor — Kamu: $_playerScore  AI: $_aiScore',
            style: TextStyle(color: textSecondary)),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _startNewGame();
            },
            child: Text('Main Lagi', style: TextStyle(color: accentColor)),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Tutup', style: TextStyle(color: textSecondary)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: surfaceColor,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('DOMINOS',
            style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                letterSpacing: 2)),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: accentColor),
            onPressed: _startNewGame,
          ),
        ],
      ),
      body: Column(
        children: [
          // Scoreboard
          Container(
            margin: const EdgeInsets.all(10),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: primaryColor.withOpacity(0.5)),
              boxShadow: [
                BoxShadow(color: primaryColor.withOpacity(0.4), blurRadius: 12),
                BoxShadow(color: Colors.white.withOpacity(0.15), blurRadius: 6),
              ],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildScore('KAMU', _playerScore, primaryColor),
                Container(width: 2, height: 40, color: Colors.white24),
                _buildScore('AI', _aiScore, accentColor),
              ],
            ),
          ),
          // Status
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Text(
              _status,
              style: TextStyle(
                  color: accentColor,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 1),
            ),
          ),
          const SizedBox(height: 10),
          // Board
          Expanded(
            flex: 3,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 12),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: surfaceColor,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: primaryColor.withOpacity(0.35)),
                boxShadow: [
                  BoxShadow(
                      color: primaryColor.withOpacity(0.25), blurRadius: 12),
                ],
              ),
              child: _board.isEmpty
                  ? Center(
                      child: Text(
                        'Papan kosong — mainkan kartu pertamamu',
                        style: TextStyle(
                            color: textSecondary.withOpacity(0.6),
                            fontSize: 12),
                      ),
                    )
                  : SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: _board
                            .map((t) => Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 3, vertical: 6),
                                  child: _buildTile(t, highlight: false),
                                ))
                            .toList(),
                      ),
                    ),
            ),
          ),
          // Hand Player
          Container(
            height: 110,
            margin: const EdgeInsets.all(10),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: accentColor.withOpacity(0.35)),
              boxShadow: [
                BoxShadow(color: accentColor.withOpacity(0.3), blurRadius: 12),
                BoxShadow(color: Colors.white.withOpacity(0.15), blurRadius: 6),
              ],
            ),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _playerHand.length,
              itemBuilder: (ctx, i) {
                final tile = _playerHand[i];
                return GestureDetector(
                  onTap: () => _playTile(i),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: _buildTile(tile,
                        highlight: _canPlay(tile) && _playerTurn),
                  ),
                );
              },
            ),
          ),
          // AI Hand count
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Text(
              'Kartu AI: ${_aiHand.length}',
              style: TextStyle(color: textSecondary, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildScore(String label, int score, Color color) {
    return Column(
      children: [
        Text(label,
            style: TextStyle(
                color: color, fontSize: 11, letterSpacing: 1.5, fontWeight: FontWeight.bold)),
        const SizedBox(height: 4),
        Text('$score',
            style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.w900,
                shadows: [
                  Shadow(color: color.withOpacity(0.6), blurRadius: 10),
                ])),
      ],
    );
  }

  Widget _buildTile(List<int> tile, {bool highlight = false}) {
    return Container(
      width: 50,
      height: 100,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: highlight
              ? [primaryColor.withOpacity(0.9), accentColor.withOpacity(0.7)]
              : [Colors.white, const Color(0xFFE0E0E0)],
        ),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: highlight ? accentColor : Color(0xFF00B0FF),
          width: highlight ? 2 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: highlight
                ? accentColor.withOpacity(0.6)
                : Colors.black.withOpacity(0.4),
            blurRadius: highlight ? 14 : 6,
          ),
          if (highlight)
            BoxShadow(color: Colors.white.withOpacity(0.3), blurRadius: 6),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _pip(tile[0]),
          Container(
            height: 1,
            width: 30,
            color: Colors.black.withOpacity(0.4),
          ),
          _pip(tile[1]),
        ],
      ),
    );
  }

  Widget _pip(int value) {
    return Text(
      '$value',
      style: const TextStyle(
        color: Colors.black,
        fontSize: 24,
        fontWeight: FontWeight.w900,
      ),
    );
  }
}