// tools_page.dart
// Tools Dashboard — tampilan neo-brutalism light blue seperti referensi

import 'package:flutter/material.dart';

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> {
  // ====== WARNA (neo-brutalism light blue) ======
  final Color bgColor = const Color(0xFFD6E4FF);
  final Color surfaceColor = const Color(0xFFFFFFFF);
  final Color softBlue = const Color(0xFFEAF1FF);
  final Color borderColor = const Color(0xFF0A0A0A);
  final Color textPrimary = const Color(0xFF0A0A0A);
  final Color textSecondary = const Color(0xFF4A5568);
  final Color accentBlue = const Color(0xFF2563EB);

  final List<Map<String, dynamic>> _tools = const [
    {
      "title": "Chat Tools",
      "subtitle": "Chat Semua User",
      "icon": Icons.chat_bubble_rounded,
      "color": Color(0xFF8B5CF6),
    },
    {
      "title": "DDoS Tools",
      "subtitle": "Attack & Server",
      "icon": Icons.bolt_rounded,
      "color": Color(0xFF2563EB),
    },
    {
      "title": "Network",
      "subtitle": "WiFi & Spam",
      "icon": Icons.wifi_rounded,
      "color": Color(0xFF2563EB),
    },
    {
      "title": "Osint",
      "subtitle": "Investigation",
      "icon": Icons.search_rounded,
      "color": Color(0xFF60A5FA),
    },
    {
      "title": "Downloader",
      "subtitle": "Social Media",
      "icon": Icons.download_rounded,
      "color": Color(0xFF3B82F6),
    },
    {
      "title": "Utilities",
      "subtitle": "Extra Tools",
      "icon": Icons.build_rounded,
      "color": Color(0xFF60A5FA),
    },
    {
      "title": "Islamic",
      "subtitle": "Hadis & Quran",
      "icon": Icons.mosque_rounded,
      "color": Color(0xFF10B981),
    },
    {
      "title": "Quick Access",
      "subtitle": "Favorites",
      "icon": Icons.rocket_launch_rounded,
      "color": Color(0xFF3B82F6),
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildHeaderCard(),
              const SizedBox(height: 20),
              ..._tools.map(_buildToolCard),
            ],
          ),
        ),
      ),
    );
  }

  // ─── HEADER CARD ─────────────────────────────────────────────────────────
  Widget _buildHeaderCard() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
      decoration: BoxDecoration(
        color: surfaceColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: borderColor, width: 2),
        boxShadow: const [
          BoxShadow(color: borderColor, offset: Offset(4, 4)),
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: softBlue,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: borderColor, width: 1.6),
                ),
                child: const Icon(Icons.tune_rounded,
                    color: Color(0xFF2563EB), size: 20),
              ),
              const SizedBox(width: 12),
              RichText(
                text: const TextSpan(
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1.5,
                    color: Color(0xFF0A0A0A),
                  ),
                  children: [
                    TextSpan(text: "TOOLS "),
                    TextSpan(
                      text: "DASHBOARD",
                      style: TextStyle(color: Color(0xFF2563EB)),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          const Text(
            "Advanced Security & Osint Tools",
            style: TextStyle(
              color: Color(0xFF4A5568),
              fontSize: 13,
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }

  // ─── TOOL CARD ───────────────────────────────────────────────────────────
  Widget _buildToolCard(Map<String, dynamic> tool) {
    final Color iconColor = tool['color'] as Color;
    return GestureDetector(
      onTap: () {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("${tool['title']} — Coming Soon"),
            behavior: SnackBarBehavior.floating,
            backgroundColor: accentBlue,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10)),
          ),
        );
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: surfaceColor,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: borderColor, width: 2),
          boxShadow: const [
            BoxShadow(color: borderColor, offset: Offset(4, 4)),
          ],
        ),
        child: Row(
          children: [
            // Icon
            Container(
              width: 46,
              height: 46,
              decoration: BoxDecoration(
                color: softBlue,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: borderColor, width: 1.6),
              ),
              child: Icon(
                tool['icon'] as IconData,
                color: iconColor,
                size: 22,
              ),
            ),
            const SizedBox(width: 14),
            // Title + Subtitle
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    tool['title'] as String,
                    style: const TextStyle(
                      color: Color(0xFF0A0A0A),
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    tool['subtitle'] as String,
                    style: const TextStyle(
                      color: Color(0xFF4A5568),
                      fontSize: 12,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            // Arrow
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: softBlue,
                shape: BoxShape.circle,
                border: Border.all(color: borderColor, width: 1.6),
              ),
              child: const Icon(Icons.chevron_right_rounded,
                  color: Color(0xFF0A0A0A), size: 18),
            ),
          ],
        ),
      ),
    );
  }
}