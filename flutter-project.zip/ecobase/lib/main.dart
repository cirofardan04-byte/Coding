import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import 'login_page.dart';
import 'dashboard_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'landing.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // ====== NEON BLUE LIGHT THEME (BLACK BASE) ======
  static const Color _primary = Color(0xFF00B0FF); // Electric Blue
  static const Color _secondary = Color(0xFF00E5FF); // Cyan Neon
  static const Color _background = Color(0xFF000000); // Black
  static const Color _surface = Color(0xFF050B1A); // Black Navy
  static const Color _card = Color(0xFF0F2547); // Deep Navy Card
  static const Color _textPrimary = Colors.white;
  static const Color _textSecondary = Color(0xFFB3E5FC);

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(390, 844),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (_, child) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'NEVERLOUS PROJECT ULTRA',
        theme: ThemeData(
          brightness: Brightness.dark,
          fontFamily: 'Rajdhani',
          useMaterial3: true,

          // Warna utama
          scaffoldBackgroundColor: _background,
          canvasColor: _background,
          cardColor: _card,
          dividerColor: _primary.withOpacity(0.3),
          splashColor: _primary.withOpacity(0.15),
          highlightColor: _primary.withOpacity(0.08),
          shadowColor: _primary.withOpacity(0.5),

          colorScheme: const ColorScheme.dark(
            primary: _primary,
            secondary: _secondary,
            surface: _surface,
            background: _background,
            onPrimary: Colors.white,
            onSecondary: Colors.white,
            onSurface: _textPrimary,
            onBackground: _textPrimary,
            error: Color(0xFFFF5252),
            onError: Colors.white,
            outline: Color(0xFF1B3A6B),
          ),

          // AppBar: neon blue glow tipis
          appBarTheme: AppBarTheme(
            backgroundColor: _surface.withOpacity(0.95),
            foregroundColor: _textPrimary,
            elevation: 0,
            centerTitle: true,
            iconTheme: const IconThemeData(color: _secondary),
            titleTextStyle: const TextStyle(
              color: _textPrimary,
              fontSize: 16,
              fontWeight: FontWeight.w700,
              letterSpacing: 1.2,
              shadows: [
                Shadow(
                  color: Color(0x6600E5FF),
                  blurRadius: 12,
                ),
                Shadow(
                  color: Color(0x33FFFFFF),
                  blurRadius: 6,
                ),
              ],
            ),
            systemOverlayStyle: const SystemUiOverlayStyle(
              statusBarColor: Colors.transparent,
              statusBarIconBrightness: Brightness.light,
              statusBarBrightness: Brightness.dark,
            ),
          ),

          // Bottom Navigation: neon blue
          bottomNavigationBarTheme: const BottomNavigationBarThemeData(
            backgroundColor: _surface,
            selectedItemColor: _secondary,
            unselectedItemColor: Color(0xFF8FB8DD),
            type: BottomNavigationBarType.fixed,
            selectedLabelStyle: TextStyle(
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
            unselectedLabelStyle: TextStyle(fontSize: 10),
          ),

          // TextField default: neon blue + white glow tipis
          inputDecorationTheme: InputDecorationTheme(
            filled: true,
            fillColor: _card.withOpacity(0.6),
            hintStyle: const TextStyle(color: Color(0xFF8FB8DD)),
            labelStyle: const TextStyle(color: _textSecondary),
            prefixIconColor: _secondary,
            suffixIconColor: _textSecondary,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(
                color: _primary.withOpacity(0.5),
                width: 1.2,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: BorderSide(
                color: _primary.withOpacity(0.5),
                width: 1.2,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(
                color: _secondary,
                width: 1.8,
              ),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(
                color: Color(0xFFFF5252),
                width: 1.4,
              ),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(14),
              borderSide: const BorderSide(
                color: Color(0xFFFF5252),
                width: 1.8,
              ),
            ),
          ),

          // Tombol Elevated
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              backgroundColor: _primary,
              foregroundColor: Colors.white,
              elevation: 6,
              shadowColor: _primary.withOpacity(0.6),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              textStyle: const TextStyle(
                fontWeight: FontWeight.w800,
                letterSpacing: 1.2,
              ),
            ),
          ),

          // Tombol Text
          textButtonTheme: TextButtonThemeData(
            style: TextButton.styleFrom(
              foregroundColor: _secondary,
              textStyle: const TextStyle(
                fontWeight: FontWeight.w700,
                letterSpacing: 1,
              ),
            ),
          ),

          // Tombol Outlined
          outlinedButtonTheme: OutlinedButtonThemeData(
            style: OutlinedButton.styleFrom(
              foregroundColor: _secondary,
              side: BorderSide(color: _primary.withOpacity(0.6), width: 1.4),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
          ),

          // FAB
          floatingActionButtonTheme: FloatingActionButtonThemeData(
            backgroundColor: _primary,
            foregroundColor: Colors.white,
            elevation: 8,
            splashColor: _secondary.withOpacity(0.3),
            highlightElevatide: 12,
          ),

          // Dialog
          dialogTheme: DialogTheme(
            backgroundColor: _surface,
            elevation: 12,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
              side: BorderSide(color: _primary.withOpacity(0.5), width: 1.2),
            ),
            titleTextStyle: const TextStyle(
              color: _textPrimary,
              fontSize: 16,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
            contentTextStyle: const TextStyle(
              color: _textSecondary,
              fontSize: 13,
              height: 1.5,
            ),
          ),

          // SnackBar
          snackBarTheme: SnackBarThemeData(
            backgroundColor: _card,
            contentTextStyle: const TextStyle(
              color: _textPrimary,
              fontWeight: FontWeight.w600,
            ),
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
              side: BorderSide(color: _primary.withOpacity(0.5), width: 1),
            ),
            elevation: 8,
          ),

          // Progress
          progressIndicatorTheme: const ProgressIndicatorThemeData(
            color: _secondary,
            linearTrackColor: Color(0xFF1B3A6B),
            circularTrackColor: Color(0xFF1B3A6B),
          ),

          // Chip
          chipTheme: ChipThemeData(
            backgroundColor: _card,
            selectedColor: _primary.withOpacity(0.3),
            disabledColor: const Color(0xFF1B3A6B),
            labelStyle: const TextStyle(
              color: _textPrimary,
              fontWeight: FontWeight.w600,
            ),
            secondaryLabelStyle: const TextStyle(color: _secondary),
            side: BorderSide(color: _primary.withOpacity(0.5)),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10),
            ),
          ),

          // Switch
          switchTheme: SwitchThemeData(
            thumbColor: MaterialStateProperty.resolveWith((states) {
              if (states.contains(MaterialState.selected)) return _secondary;
              return const Color(0xFF8FB8DD);
            }),
            trackColor: MaterialStateProperty.resolveWith((states) {
              if (states.contains(MaterialState.selected)) {
                return _primary.withOpacity(0.4);
              }
              return const Color(0xFF1B3A6B);
            }),
          ),

          // Slider
          sliderTheme: SliderThemeData(
            activeTrackColor: _primary,
            inactiveTrackColor: const Color(0xFF1B3A6B),
            thumbColor: _secondary,
            overlayColor: _secondary.withOpacity(0.2),
          ),

          // TabBar
          tabBarTheme: const TabBarTheme(
            labelColor: _secondary,
            unselectedLabelColor: Color(0xFF8FB8DD),
            indicatorColor: _secondary,
            labelStyle: TextStyle(
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
            unselectedLabelStyle: TextStyle(fontWeight: FontWeight.w500),
          ),

          // Divider
          dividerTheme: DividerThemeData(
            color: _primary.withOpacity(0.25),
            thickness: 1,
            space: 1,
          ),

          // Icon
          iconTheme: const IconThemeData(color: _secondary, size: 22),

          // Text selection (cursor + highlight)
          textSelectionTheme: TextSelectionThemeData(
            cursorColor: _secondary,
            selectionColor: _primary.withOpacity(0.4),
            selectionHandleColor: _secondary,
          ),

          // Tooltip
          tooltipTheme: TooltipThemeData(
            decoration: BoxDecoration(
              color: _card,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _primary.withOpacity(0.6)),
              boxShadow: [
                BoxShadow(
                  color: _primary.withOpacity(0.4),
                  blurRadius: 12,
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.1),
                  blurRadius: 5,
                ),
              ],
            ),
            textStyle: const TextStyle(
              color: _textPrimary,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),

          // Checkbox
          checkboxTheme: CheckboxThemeData(
            fillColor: MaterialStateProperty.resolveWith((states) {
              if (states.contains(MaterialState.selected)) return _primary;
              return Colors.transparent;
            }),
            checkColor: MaterialStateProperty.all(Colors.white),
            side: BorderSide(color: _primary.withOpacity(0.6), width: 1.6),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(4),
            ),
          ),

          // Radio
          radioTheme: RadioThemeData(
            fillColor: MaterialStateProperty.resolveWith((states) {
              if (states.contains(MaterialState.selected)) return _secondary;
              return const Color(0xFF8FB8DD);
            }),
          ),
        ),
        initialRoute: '/',
        onGenerateRoute: (settings) {
          switch (settings.name) {
            case '/':
              return MaterialPageRoute(builder: (_) => const LandingPage());

            case '/login':
              return MaterialPageRoute(builder: (_) => const LoginPage());

            case '/dashboard':
              final args = settings.arguments as Map<String, dynamic>;
              return MaterialPageRoute(
                builder: (_) => DashboardPage(
                  username: args['username'],
                  password: args['password'],
                  role: args['role'],
                  sessionKey: args['key'],
                  expiredDate: args['expiredDate'],
                  listBug:
                      List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                  news: List<Map<String, dynamic>>.from(args['news'] ?? []),
                ),
              );

            case '/home':
              final args = settings.arguments as Map<String, dynamic>;
              return MaterialPageRoute(
                builder: (_) => HomePage(
                  username: args['username'],
                  password: args['password'],
                  listBug:
                      List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                  role: args['role'],
                  expiredDate: args['expiredDate'],
                  sessionKey: args['sessionKey'],
                ),
              );

            case '/seller':
              final args = settings.arguments as Map<String, dynamic>;
              return MaterialPageRoute(
                builder: (_) => SellerPage(
                  keyToken: args['keyToken'],
                ),
              );

            case '/admin':
              final args = settings.arguments as Map<String, dynamic>;
              return MaterialPageRoute(
                builder: (_) => AdminPage(
                  sessionKey: args['sessionKey'],
                ),
              );

            case '/owner':
              final args = settings.arguments as Map<String, dynamic>;
              return MaterialPageRoute(
                builder: (_) => OwnerPage(
                  sessionKey: args['sessionKey'],
                  username: args['username'],
                ),
              );

            default:
              return MaterialPageRoute(
                builder: (_) => const Scaffold(
                  body: Center(
                    child: Text('404 - Not Found'),
                  ),
                ),
              );
          }
        },
      ),
    );
  }
}