import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'bug_sender.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  // ─── WARNA UI (biru muda + putih + hitam) ───
  static const Color bgColor = Color(0xFFD6E4FF);
  static const Color surfaceColor = Color(0xFFFFFFFF);
  static const Color cardSoft = Color(0xFFEAF1FF);
  static const Color softBlue = Color(0xFFBFD4FF);
  static const Color borderBlack = Color(0xFF0A0A0A);
  static const Color textSecondary = Color(0xFF4A5568);
  static const Color accentBlue = Color(0xFF2563EB);
  static const Color successGreen = Color(0xFF16A34A);
  static const Color dangerRed = Color(0xFFDC2626);

  // ─── State ───
  final TextEditingController targetController = TextEditingController();
  late final AnimationController _pulseController;
  String selectedBugId = "";
  late PageController _bugPageController;
  int _currentBugPage = 0;
  bool isSending = false;
  String? responseMessage;
  String _selectedSenderType = 'private';

  // Target Mode
  String _targetMode = 'single';
  List<String> _multiTargets = [];
  bool _isMultiModeActive = false;

  // ─── Progress ───
  bool _showProgressDialog = false;
  String _progressStatus = "Mengirim bug...";
  double _loadingProgress = 0.0;
  Timer? _progressTimer;
  bool _bugSent = false;
  String _finalMessage = "";

  // ─── Video Banner ───
  VideoPlayerController? _videoController;
  bool _videoInitialized = false;

  // ─── Private Sender ───
  List<Map<String, dynamic>> _privateSenders = [];
  bool _isLoadingSenders = false;
  Timer? _senderPollingTimer;
  static const String baseUrl = "http://raulllll.panelantirusuh.biz.id:10361";
  static const Duration _pollingInterval = Duration(seconds: 10);

  bool get _isMember => widget.role.toLowerCase() == 'member';
  bool get _canSendBug => _privateSenders.isNotEmpty;
  bool get _isVip => [
        'vip',
        'dev',
        'ceo',
        'owner',
        'admin',
        'high_admin'
      ].contains(widget.role.toLowerCase());

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _initVideo();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _bugPageController = PageController();

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }

    _fetchSenders();
    _startPolling();
  }

  void _initAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    )..forward();

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );

    _slideAnimation =
        Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero).animate(
      CurvedAnimation(
          parent: _animationController, curve: Curves.easeOutCubic),
    );
  }

  void _initVideo() {
    _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) {
          setState(() => _videoInitialized = true);
          _videoController?.setLooping(true);
          _videoController?.setVolume(0);
          _videoController?.play();
        }
      }).catchError((_) {
        // Video tidak ditemukan, abaikan
      });
  }

  void _startPolling() {
    _senderPollingTimer = Timer.periodic(_pollingInterval, (_) {
      if (mounted) _fetchSendersSilent();
    });
  }

  Future<void> _fetchSendersSilent() async {
    try {
      final res = await http
          .get(Uri.parse("$baseUrl/mySender?key=${widget.sessionKey}"))
          .timeout(const Duration(seconds: 8));
      final data = jsonDecode(res.body);
      if (data["valid"] == true && mounted) {
        final newPrivate =
            List<Map<String, dynamic>>.from(data["privateConnections"] ?? []);
        if (_listChanged(_privateSenders, newPrivate)) {
          setState(() => _privateSenders = newPrivate);
        }
      }
    } catch (_) {}
  }

  bool _listChanged(
      List<Map<String, dynamic>> oldList, List<Map<String, dynamic>> newList) {
    if (oldList.length != newList.length) return true;
    final oldIds = oldList.map((e) => e['id']?.toString() ?? '').toSet();
    final newIds = newList.map((e) => e['id']?.toString() ?? '').toSet();
    return !oldIds.containsAll(newIds) || !newIds.containsAll(oldIds);
  }

  @override
  void dispose() {
    _senderPollingTimer?.cancel();
    _pulseController.dispose();
    _bugPageController.dispose();
    targetController.dispose();
    _progressTimer?.cancel();
    _animationController.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  Future<void> _fetchSenders() async {
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http
          .get(Uri.parse("$baseUrl/mySender?key=${widget.sessionKey}"));
      final data = jsonDecode(res.body);
      if (data["valid"] == true) {
        setState(() {
          _privateSenders = List<Map<String, dynamic>>.from(
              data["privateConnections"] ?? []);
        });
      }
    } catch (_) {
      _showMessageDialog("Error", "Gagal memuat data private sender.");
    } finally {
      if (mounted) setState(() => _isLoadingSenders = false);
    }
  }

  String? _formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  List<String> _parseTargets(String raw) {
    final parts = raw
        .split(RegExp(r'[\n,;]+'))
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .toList();
    return parts.take(10).toList();
  }

  // ─── SIMPAN MULTI TARGET ───
  void _saveMultiTarget() {
    final raw = targetController.text.trim();
    if (raw.isEmpty) {
      _showMessageDialog("Kosong", "Masukkan minimal 1 nomor target.");
      return;
    }
    final parts = _parseTargets(raw);
    if (parts.isEmpty) {
      _showMessageDialog("Kosong", "Format nomor tidak valid.");
      return;
    }
    setState(() {
      _multiTargets = parts;
      _isMultiModeActive = false;
    });
    _showMessageDialog("Tersimpan", "${parts.length} nomor target berhasil disimpan.");
  }

  // ─── SELESAI MULTI TARGET ───
  void _finishMultiTarget() {
    if (_multiTargets.isEmpty) {
      _showMessageDialog("Kosong", "Belum ada nomor target yang disimpan.");
      return;
    }
    setState(() {
      _isMultiModeActive = false;
      targetController.clear();
    });
    _showMessageDialog("Selesai", "${_multiTargets.length} nomor target siap dikirim.");
  }

  // ============ SEND BUG (MULTI TARGET) ============
  Future<void> _sendBugWithProgress() async {
    List<String> targets = [];
    if (_targetMode == 'single') {
      final raw = targetController.text.trim();
      if (raw.isEmpty) {
        _showMessageDialog("Nomor Kosong", "Masukkan nomor target terlebih dahulu.");
        return;
      }
      targets = [raw];
    } else {
      if (_multiTargets.isEmpty) {
        _showMessageDialog("Nomor Kosong", "Simpan nomor target terlebih dahulu.");
        return;
      }
      targets = _multiTargets;
    }

    final validTargets = <String>[];
    for (final t in targets) {
      final f = _formatPhoneNumber(t);
      if (f != null) validTargets.add(f);
    }

    if (validTargets.isEmpty) {
      _showMessageDialog(
        "Nomor Invalid",
        "Gunakan format internasional (contoh: +62, +1, +44).",
      );
      return;
    }

    if (!_canSendBug) {
      _showMessageDialog(
          "Tidak Ada Sender", "Tambahkan private sender terlebih dahulu!");
      return;
    }

    setState(() {
      _showProgressDialog = true;
      _progressStatus = "Mengirim bug ke ${validTargets.length} target...";
      _loadingProgress = 0.0;
      _bugSent = false;
      _finalMessage = "";
    });

    _progressTimer?.cancel();
    int step = 0;
    const totalSteps = 5;
    _progressTimer = Timer.periodic(const Duration(milliseconds: 350), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      step++;
      setState(() {
        _loadingProgress = step / totalSteps;
        if (_loadingProgress >= 1.0) {
          _loadingProgress = 1.0;
          timer.cancel();
          _executeSendBugMulti(validTargets);
        }
      });
    });
  }

  Future<void> _executeSendBugMulti(List<String> targets) async {
    final key = widget.sessionKey;

    setState(() {
      isSending = true;
      responseMessage = null;
      _progressStatus = "Memproses ${targets.length} target...";
    });

    int success = 0;
    int failed = 0;
    String lastMsg = "";

    for (final t in targets) {
      try {
        final res = await http
            .get(Uri.parse(
                "$baseUrl/sendBug?key=$key&target=$t&bug=$selectedBugId&senderType=private"))
            .timeout(const Duration(seconds: 30));
        final data = jsonDecode(res.body);
        if (data["sended"] == true) {
          success++;
        } else {
          failed++;
          lastMsg = data["message"]?.toString() ?? lastMsg;
        }
        if (data["cooldown"] == true) {
          lastMsg = "Cooldown: ${data["wait"] ?? "?"}s";
        }
      } catch (_) {
        failed++;
      }
      await Future.delayed(const Duration(milliseconds: 400));
    }

    if (!mounted) return;

    setState(() {
      _finalMessage = "✅ Sukses: $success  |  ❌ Gagal: $failed"
          "${lastMsg.isNotEmpty ? "\n$lastMsg" : ""}";
      _progressStatus = success > 0 ? "Berhasil!" : "Gagal!";
      _bugSent = success > 0;
      isSending = false;
      _loadingProgress = 1.0;
    });

    Future.delayed(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() {
          _showProgressDialog = false;
          responseMessage = _finalMessage;
        });
        _progressTimer?.cancel();
        if (success > 0) {
          targetController.clear();
          if (_targetMode == 'multi') _multiTargets.clear();
        }
      }
    });
  }

  void _showMessageDialog(String title, String msg) {
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          margin: const EdgeInsets.all(20),
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: surfaceColor,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: borderBlack, width: 2),
            boxShadow: const [
              BoxShadow(color: borderBlack, offset: Offset(5, 5)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: softBlue,
                  shape: BoxShape.circle,
                  border: Border.all(color: borderBlack, width: 2),
                ),
                child: const Icon(Icons.warning_rounded,
                    color: borderBlack, size: 28),
              ),
              const SizedBox(height: 16),
              Text(title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: borderBlack,
                      fontSize: 17,
                      fontWeight: FontWeight.w800)),
              const SizedBox(height: 10),
              Text(msg,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: textSecondary, fontSize: 13)),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: accentBlue,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: borderBlack, width: 2),
                    boxShadow: const [
                      BoxShadow(color: borderBlack, offset: Offset(3, 3)),
                    ],
                  ),
                  child: const Center(
                    child: Text("OK",
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProgressDialog() {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(20),
      child: PopScope(
        canPop: false,
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: surfaceColor,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: borderBlack, width: 2),
            boxShadow: const [
              BoxShadow(color: borderBlack, offset: Offset(6, 6)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: softBlue,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: borderBlack, width: 1.5),
                    ),
                    child: const Icon(Icons.send_rounded,
                        color: borderBlack, size: 20),
                  ),
                  const SizedBox(width: 12),
                  const Text(
                    "SENDING BUG",
                    style: TextStyle(
                      color: borderBlack,
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Column(
                children: List.generate(5, (index) {
                  final isActive = _loadingProgress * 5 > index;
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 5),
                    child: Container(
                      height: 8,
                      decoration: BoxDecoration(
                        color: softBlue.withValues(alpha: 0.5),
                        borderRadius: BorderRadius.circular(4),
                      ),
                      child: FractionallySizedBox(
                        alignment: Alignment.centerLeft,
                        widthFactor: isActive ? 1.0 : 0.0,
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: isActive
                                ? const LinearGradient(
                                    colors: [successGreen, Color(0xFF4ADE80)])
                                : const LinearGradient(
                                    colors: [accentBlue, Color(0xFF60A5FA)]),
                            borderRadius: BorderRadius.circular(4),
                            boxShadow: isActive
                                ? [
                                    BoxShadow(
                                      color: successGreen.withValues(alpha: 0.4),
                                      blurRadius: 8,
                                    ),
                                  ]
                                : [
                                    BoxShadow(
                                      color: accentBlue.withValues(alpha: 0.5),
                                      blurRadius: 10,
                                    ),
                                  ],
                          ),
                        ),
                      ),
                    ),
                  );
                }),
              ),
              const SizedBox(height: 18),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: cardSoft,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: borderBlack, width: 1.5),
                ),
                child: Column(
                  children: [
                    Text(
                      _progressStatus,
                      style: const TextStyle(
                        color: borderBlack,
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    if (_finalMessage.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Text(
                        _finalMessage,
                        style: const TextStyle(
                          color: borderBlack,
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgColor,
      body: Stack(
        children: [
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _buildProfileCard(),
                      const SizedBox(height: 16),
                      _buildBannerCard(),
                      const SizedBox(height: 16),
                      _buildTargetInput(),
                      const SizedBox(height: 16),
                      _buildBugPicker(),
                      const SizedBox(height: 16),
                      _buildSenderPicker(),
                      const SizedBox(height: 20),
                      _buildSendButton(),
                      if (responseMessage != null) ...[
                        const SizedBox(height: 16),
                        _buildResponseMessage(),
                      ],
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ),
          if (_showProgressDialog)
            Positioned.fill(
              child: Container(
                color: Colors.black.withValues(alpha: 0.55),
                child: Center(child: _buildProgressDialog()),
              ),
            ),
        ],
      ),
    );
  }

  // ─── PROFILE CARD ────────────────────────────────────────────────────────
  Widget _buildProfileCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: surfaceColor,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: borderBlack, width: 2),
        boxShadow: const [
          BoxShadow(color: borderBlack, offset: Offset(5, 5)),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              color: softBlue,
              shape: BoxShape.circle,
              border: Border.all(color: borderBlack, width: 2),
            ),
            child: const Icon(Icons.person_rounded,
                color: borderBlack, size: 28),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.username,
                  style: const TextStyle(
                    color: borderBlack,
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 3),
                      decoration: BoxDecoration(
                        color: softBlue,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: borderBlack, width: 1.5),
                      ),
                      child: Text(
                        widget.role.toUpperCase(),
                        style: const TextStyle(
                          color: borderBlack,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Flexible(
                      child: Text(
                        "Exp: ${widget.expiredDate}",
                        style: const TextStyle(
                          color: textSecondary,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: const Color(0xFFDCFCE7),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: borderBlack, width: 1.5),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 8,
                  height: 8,
                  child: DecoratedBox(
                    decoration: BoxDecoration(
                      color: successGreen,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
                SizedBox(width: 5),
                Text(
                  "LIVE",
                  style: TextStyle(
                    color: borderBlack,
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── BANNER CARD (VIDEO) ─────────────────────────────────────────────────
  Widget _buildBannerCard() {
    return Container(
      height: 190,
      decoration: BoxDecoration(
        color: const Color(0xFF0B0714),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: borderBlack, width: 2),
        boxShadow: const [
          BoxShadow(color: borderBlack, offset: Offset(5, 5)),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_videoInitialized && _videoController != null)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController!.value.size.width,
                  height: _videoController!.value.size.height,
                  child: VideoPlayer(_videoController!),
                ),
              )
            else
              const ColoredBox(
                color: Color(0xFF0B0714),
                child: Center(
                  child: Icon(Icons.image_rounded,
                      color: Colors.white24, size: 60),
                ),
              ),
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Colors.black.withValues(alpha: 0.0),
                      Colors.black.withValues(alpha: 0.55),
                    ],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── TARGET INPUT ────────────────────────────────────────────────────────
  Widget _buildTargetInput() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: surfaceColor,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: borderBlack, width: 2),
        boxShadow: const [
          BoxShadow(color: borderBlack, offset: Offset(5, 5)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(Icons.phone_android_rounded, "NOMOR TARGET"),
          const SizedBox(height: 12),

          // Mode Selector
          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() {
                    _targetMode = 'single';
                    _isMultiModeActive = false;
                    _multiTargets.clear();
                    targetController.clear();
                  }),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: _targetMode == 'single' ? softBlue : surfaceColor,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: borderBlack, width: 2),
                    ),
                    child: const Center(
                      child: Text(
                        "SATU TARGET",
                        style: TextStyle(
                          color: borderBlack,
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() {
                    _targetMode = 'multi';
                    _isMultiModeActive = true;
                    targetController.clear();
                  }),
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: _targetMode == 'multi' ? softBlue : surfaceColor,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: borderBlack, width: 2),
                    ),
                    child: const Center(
                      child: Text(
                        "BANYAK TARGET",
                        style: TextStyle(
                          color: borderBlack,
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          // Input Field
          if (_targetMode == 'single')
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: cardSoft,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: borderBlack, width: 1.6),
              ),
              child: Row(
                children: [
                  const Icon(Icons.phone_rounded,
                      color: accentBlue, size: 18),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: targetController,
                      keyboardType: TextInputType.phone,
                      style: const TextStyle(
                          color: borderBlack,
                          fontSize: 13,
                          fontWeight: FontWeight.w600),
                      cursorColor: accentBlue,
                      decoration: const InputDecoration(
                        hintText: "Contoh: +62xxxxxxxxxx",
                        hintStyle: TextStyle(
                          color: Color(0xFF94A3B8),
                          fontSize: 12,
                        ),
                        border: InputBorder.none,
                        isDense: true,
                      ),
                    ),
                  ),
                ],
              ),
            )
          else ...[
            if (!_isMultiModeActive && _multiTargets.isNotEmpty)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                margin: const EdgeInsets.only(bottom: 10),
                decoration: BoxDecoration(
                  color: cardSoft,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: borderBlack, width: 1.6),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "Daftar Nomor Tersimpan:",
                      style: TextStyle(
                        color: borderBlack,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 6),
                    ..._multiTargets.asMap().entries.map((e) => Text(
                          "${e.key + 1}. ${e.value}",
                          style: const TextStyle(
                            color: textSecondary,
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                          ),
                        )),
                  ],
                ),
              ),
            if (_isMultiModeActive) ...[
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: cardSoft,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: borderBlack, width: 1.6),
                ),
                child: TextField(
                  controller: targetController,
                  maxLines: 6,
                  minLines: 3,
                  keyboardType: TextInputType.multiline,
                  style: const TextStyle(
                      color: borderBlack,
                      fontSize: 13,
                      fontWeight: FontWeight.w600),
                  cursorColor: accentBlue,
                  decoration: const InputDecoration(
                    hintText:
                        "Contoh:\n+62xxxxxxxxxx\n+62xxxxxxxxxx\n+62xxxxxxxxxx\n(max 10 nomor)",
                    hintStyle: TextStyle(
                      color: Color(0xFF94A3B8),
                      fontSize: 12,
                      height: 1.5,
                    ),
                    border: InputBorder.none,
                    isDense: true,
                  ),
                ),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: _saveMultiTarget,
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: accentBlue,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: borderBlack, width: 2),
                          boxShadow: const [
                            BoxShadow(
                                color: borderBlack, offset: Offset(3, 3)),
                          ],
                        ),
                        child: const Center(
                          child: Text(
                            "SIMPAN NOMOR",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: GestureDetector(
                      onTap: _finishMultiTarget,
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        decoration: BoxDecoration(
                          color: successGreen,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: borderBlack, width: 2),
                          boxShadow: const [
                            BoxShadow(
                                color: borderBlack, offset: Offset(3, 3)),
                          ],
                        ),
                        child: const Center(
                          child: Text(
                            "SELESAI",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ],
      ),
    );
  }

  // ─── BUG PICKER ──────────────────────────────────────────────────────────
  Widget _buildBugPicker() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: surfaceColor,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: borderBlack, width: 2),
        boxShadow: const [
          BoxShadow(color: borderBlack, offset: Offset(5, 5)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _sectionTitle(Icons.shield_rounded, "PILIH PAYLOAD"),
              const Spacer(),
              const Text(
                "geser →",
                style: TextStyle(
                  color: textSecondary,
                  fontSize: 11,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (widget.listBug.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 24),
              child: Center(
                child: Text("Tidak ada payload tersedia",
                    style: TextStyle(color: textSecondary, fontSize: 12)),
              ),
            )
          else
            SizedBox(
              height: 130,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                itemCount: widget.listBug.length,
                itemBuilder: (context, i) {
                  final bug = widget.listBug[i];
                  final active = bug['bug_id'] == selectedBugId;
                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        selectedBugId = bug['bug_id'];
                        _currentBugPage = i;
                      });
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: 130,
                      margin: const EdgeInsets.only(right: 12),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: active ? accentBlue : softBlue,
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: borderBlack,
                          width: active ? 2 : 1.6,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: borderBlack,
                            offset: Offset(active ? 4 : 2, active ? 4 : 2),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(6),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(8),
                                  border: Border.all(
                                      color: borderBlack, width: 1.2),
                                ),
                                child: Icon(Icons.shield_rounded,
                                    color: active
                                        ? accentBlue
                                        : borderBlack,
                                    size: 14),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(6),
                                  border:
                                      Border.all(color: borderBlack, width: 1),
                                ),
                                child: Text(
                                  "#${(i + 1).toString().padLeft(2, '0')}",
                                  style: const TextStyle(
                                    color: borderBlack,
                                    fontSize: 9,
                                    fontWeight: FontWeight.w800,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const Spacer(),
                          Text(
                            (bug['bug_name'] ?? 'Unknown').toString(),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: active ? Colors.white : borderBlack,
                              fontSize: 12,
                              fontWeight: FontWeight.w800,
                              height: 1.2,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: softBlue.withValues(alpha: 0.6),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: borderBlack, width: 1.4),
            ),
            child: Row(
              children: [
                const Icon(Icons.shield_rounded,
                    color: accentBlue, size: 16),
                const SizedBox(width: 8),
                Expanded(
                  child: RichText(
                    text: TextSpan(
                      style: const TextStyle(
                          fontSize: 11, color: borderBlack),
                      children: [
                        const TextSpan(
                          text: "Payload aktif: ",
                          style: TextStyle(fontWeight: FontWeight.w600),
                        ),
                        TextSpan(
                          text: widget.listBug.isEmpty
                              ? "-"
                              : (widget.listBug
                                      .firstWhere(
                                        (b) => b['bug_id'] == selectedBugId,
                                        orElse: () => widget.listBug[0],
                                      )['bug_name'] ??
                                  "-"),
                          style: const TextStyle(
                              fontWeight: FontWeight.w800,
                              color: Color(0xFF1D4ED8)),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── SENDER PICKER ───────────────────────────────────────────────────────
  Widget _buildSenderPicker() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: surfaceColor,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: borderBlack, width: 2),
        boxShadow: const [
          BoxShadow(color: borderBlack, offset: Offset(5, 5)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _sectionTitle(Icons.send_rounded, "PILIH SENDER"),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _senderOption(
                  label: "PRIVATE",
                  icon: Icons.person_rounded,
                  value: 'private',
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _senderOption(
                  label: "GLOBAL",
                  icon: Icons.public_rounded,
                  value: 'global',
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          GestureDetector(
            onTap: () async {
              final result = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => BugSenderPage(
                    sessionKey: widget.sessionKey,
                    username: widget.username,
                    role: widget.role,
                  ),
                ),
              );
              if (result == true && mounted) _fetchSenders();
            },
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 12),
              decoration: BoxDecoration(
                color: softBlue,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: borderBlack, width: 2),
                boxShadow: const [
                  BoxShadow(color: borderBlack, offset: Offset(3, 3)),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.add_rounded,
                      color: borderBlack, size: 18),
                  const SizedBox(width: 8),
                  const Text(
                    "TAMBAH SENDER",
                    style: TextStyle(
                      color: borderBlack,
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1,
                    ),
                  ),
                  const Spacer(),
                  Container(
                    margin: const EdgeInsets.only(right: 12),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: surfaceColor,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: borderBlack, width: 1.2),
                    ),
                    child: Text(
                      "${_privateSenders.length}",
                      style: const TextStyle(
                        color: borderBlack,
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _senderOption({
    required String label,
    required IconData icon,
    required String value,
  }) {
    final active = _selectedSenderType == value;
    return GestureDetector(
      onTap: () => setState(() => _selectedSenderType = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 18),
        decoration: BoxDecoration(
          color: active ? accentBlue : softBlue,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: borderBlack,
            width: active ? 2 : 1.6,
          ),
          boxShadow: [
            BoxShadow(
              color: borderBlack,
              offset: Offset(active ? 4 : 2, active ? 4 : 2),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                border: Border.all(color: borderBlack, width: 1.4),
              ),
              child: Icon(icon,
                  color: active ? accentBlue : borderBlack,
                  size: 20),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                color: active ? Colors.white : borderBlack,
                fontSize: 12,
                fontWeight: FontWeight.w800,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── SEND BUTTON ─────────────────────────────────────────────────────────
  Widget _buildSendButton() {
    final bool canSend = _canSendBug && !isSending;
    return GestureDetector(
      onTap: canSend ? _sendBugWithProgress : null,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        height: 56,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF2563EB), Color(0xFF60A5FA)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: borderBlack, width: 2),
          boxShadow: [
            BoxShadow(
              color: accentBlue.withValues(alpha: canSend ? 0.5 : 0.2),
              blurRadius: canSend ? 20 : 8,
              spreadRadius: canSend ? 1 : 0,
            ),
            const BoxShadow(
              color: borderBlack,
              offset: Offset(4, 4),
            ),
          ],
        ),
        child: Center(
          child: isSending
              ? const SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                      color: Colors.white, strokeWidth: 2.5),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.rocket_launch_rounded,
                        color: Colors.white, size: 20),
                    const SizedBox(width: 10),
                    Text(
                      canSend ? "KIRIM BUG NYA BRAY" : "TAMBAH SENDER DULU",
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1.4,
                      ),
                    ),
                    const SizedBox(width: 8),
                    const Icon(Icons.arrow_forward_rounded,
                        color: Colors.white, size: 18),
                  ],
                ),
        ),
      ),
    );
  }

  // ─── SECTION TITLE ───────────────────────────────────────────────────────
  Widget _sectionTitle(IconData icon, String text) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 18,
          decoration: BoxDecoration(
            color: accentBlue,
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 8),
        Icon(icon, color: borderBlack, size: 16),
        const SizedBox(width: 6),
        Text(
          text,
          style: const TextStyle(
            color: borderBlack,
            fontSize: 12,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.5,
          ),
        ),
      ],
    );
  }

  // ─── RESPONSE MESSAGE ────────────────────────────────────────────────────
  Widget _buildResponseMessage() {
    final bool isSuccess = responseMessage!.contains('✅');
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: surfaceColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isSuccess ? successGreen : dangerRed,
          width: 2,
        ),
        boxShadow: [
          BoxShadow(
            color: isSuccess ? successGreen : dangerRed,
            offset: const Offset(4, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(
            isSuccess ? Icons.check_circle : Icons.error,
            color: isSuccess ? successGreen : dangerRed,
            size: 20,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              responseMessage!,
              style: TextStyle(
                color: isSuccess ? successGreen : dangerRed,
                fontWeight: FontWeight.w700,
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }
}