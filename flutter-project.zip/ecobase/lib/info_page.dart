import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class InfoPage extends StatefulWidget {
  final String sessionKey;

  const InfoPage({super.key, required this.sessionKey});

  @override
  State<InfoPage> createState() => _InfoPageState();
}

class _InfoPageState extends State<InfoPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _pulseAnimation;
  late Animation<double> _rotateAnimation;

  Map<String, dynamic>? serverInfo;
  bool isLoading = true;

  bool isApiOnline = false;
  int apiPingMs = 0;
  Color apiStatusColor = Colors.grey;
  String apiStatusText = "Checking...";
  Timer? _pingTimer;

  // ====== NEON BLUE LIGHT THEME (BLACK BASE) ======
  final Color primaryColor = const Color(0xFF00B0FF);
  final Color accentColor = const Color(0xFF00B0FF);
  final Color glowColor = const Color(0xFF80D8FF);
  final Color backgroundColor = const Color(0xFF000000);
  final Color surfaceColor = const Color(0xFF050B1A);
  final Color cardColor = const Color(0xFF0F2547);
  final Color textPrimary = Colors.white;
  final Color textSecondary = const Color(0xFFB3E5FC);

  // White glow helper (dual shadow)
  List<BoxShadow> neonGlow({
    Color color = const Color(0xFF00B0FF),
    double blur = 16,
    double spread = 1.5,
    double opacity = 0.55,
  }) {
    return [
      BoxShadow(
        color: color.withOpacity(opacity),
        blurRadius: blur,
        spreadRadius: spread,
      ),
      BoxShadow(
        color: Colors.white.withOpacity(0.18),
        blurRadius: blur * 0.6,
        spreadRadius: 0.5,
      ),
    ];
  }

  // ─── RULES LIST ──────────────────────────────────────────
  final List<Map<String, String>> rulesList = [
    {
      "title": "Larangan Barter Akun",
      "desc":
          "Akun tidak boleh ditukar dengan barang, jasa, atau akun lain dalam bentuk apa pun."
    },
    {
      "title": "Larangan Membagikan Akun",
      "desc":
          "Setiap akun bersifat pribadi dan hanya boleh digunakan oleh pemilik akun yang terdaftar."
    },
    {
      "title": "Larangan Menjual Akun",
      "desc":
          "Member TIDAK diperbolehkan menjual akun. Penjualan akun hanya boleh dilakukan oleh role yang diizinkan secara resmi."
    },
    {
      "title": "Larangan Jual Durasi Ilegal",
      "desc":
          "Dilarang menjual akses harian, mingguan, trial, atau sejenisnya di luar ketentuan yang telah ditetapkan."
    },
    {
      "title": "Larangan Banting Harga",
      "desc":
          "Dilarang merusak atau menurunkan harga yang telah ditentukan (banting harga) di bawah ketentuan NEVERLOUS PROJECT Ultra."
    },
    {
      "title": "Larangan Spam & Toxic",
      "desc":
          "Dilarang melakukan spam, toxic, atau menyebarkan konten negatif yang dapat mengganggu kenyamanan pengguna lain."
    },
  ];

  @override
  void initState() {
    super.initState();
    _initAnimations();
    _fetchServerInfo();
    _startApiPingLoop();
  }

  void _initAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    )..forward();

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );

    _slideAnimation =
        Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero).animate(
      CurvedAnimation(
          parent: _animationController, curve: Curves.easeOutCubic),
    );

    _scaleAnimation = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOutBack),
    );

    _pulseAnimation = Tween<double>(begin: 0.97, end: 1.03).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    _rotateAnimation = Tween<double>(begin: -0.01, end: 0.01).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _fetchServerInfo() async {
    try {
      final res = await http.get(
        Uri.parse(
            'http://raulllll.panelantirusuh.biz.id:10361/getServerInfo?key=${widget.sessionKey}'),
      );
      if (res.statusCode == 200) {
        setState(() {
          serverInfo = jsonDecode(res.body);
          isLoading = false;
        });
      } else {
        setState(() {
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
    }
  }

  void _startApiPingLoop() {
    _checkApiPing();
    _pingTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      _checkApiPing();
    });
  }

  Future<void> _checkApiPing() async {
    final start = DateTime.now();
    try {
      final res = await http.get(
        Uri.parse(
            'http://raulllll.panelantirusuh.biz.id:10361/ping?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 3));

      final end = DateTime.now();
      final duration = end.difference(start).inMilliseconds;

      if (res.statusCode == 200) {
        setState(() {
          isApiOnline = true;
          apiPingMs = duration;
          if (duration < 200) {
            apiStatusColor = Colors.greenAccent;
          } else if (duration < 500) {
            apiStatusColor = Colors.amber;
          } else {
            apiStatusColor = Colors.orangeAccent;
          }
          apiStatusText = "Online (${duration}ms)";
        });
      } else {
        throw Exception("Failed");
      }
    } catch (e) {
      setState(() {
        isApiOnline = false;
        apiPingMs = 0;
        apiStatusColor = Colors.redAccent;
        apiStatusText = "Offline";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Scaffold(
        backgroundColor: backgroundColor,
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(
                color: accentColor,
                strokeWidth: 3,
              ),
              const SizedBox(height: 16),
              Text(
                'Memuat Info...',
                style: TextStyle(
                  color: textSecondary.withOpacity(0.5),
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: backgroundColor,
      body: Stack(
        children: [
          // ─── BACKGROUND ──────────────────────────────────────
          Container(
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topCenter,
                radius: 1.5,
                colors: [
                  Color(0xFF0F2547),
                  Color(0xFF050B1A),
                  Color(0xFF000000),
                ],
                stops: [0.0, 0.5, 1.0],
              ),
            ),
          ),

          // ─── EFEK GELEMBUNG 3D ──────────────────────────────────
          Positioned.fill(
            child: CustomPaint(
              painter: _InfoBubblePainter3D(
                color: accentColor.withOpacity(0.12),
                count: 20,
                animation: _animationController,
              ),
            ),
          ),

          // ─── GLOW ORBS ────────────────────────────────────────────
          Positioned(
            top: -80,
            right: -80,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    primaryColor.withOpacity(0.28),
                    Colors.transparent,
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: primaryColor.withOpacity(0.35),
                    blurRadius: 80,
                    spreadRadius: 40,
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: -40,
            left: -60,
            child: Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    accentColor.withOpacity(0.18),
                    Colors.transparent,
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: accentColor.withOpacity(0.25),
                    blurRadius: 60,
                    spreadRadius: 30,
                  ),
                ],
              ),
            ),
          ),

          // ─── KONTEN ──────────────────────────────────────────────
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.only(
                      left: 20, right: 20, bottom: 20, top: 10),
                  child: Column(
                    children: [
                      _buildStatusCard(),
                      const SizedBox(height: 20),
                      _buildRulesList(),
                      const SizedBox(height: 20),
                      _buildSanctionCard(),
                      const SizedBox(height: 20),
                      _buildDisclaimerFooter(),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==================== STATUS CARD ====================
  Widget _buildStatusCard() {
    return AnimatedBuilder(
      animation: _scaleAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      surfaceColor.withOpacity(0.7),
                      surfaceColor.withOpacity(0.4),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: accentColor.withOpacity(0.4),
                    width: 1.5,
                  ),
                  boxShadow: [
                    ...neonGlow(blur: 30, spread: 1, opacity: 0.4),
                    BoxShadow(
                      color: Colors.black.withOpacity(0.5),
                      blurRadius: 30,
                      spreadRadius: 5,
                      offset: const Offset(0, 12),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [primaryColor, accentColor],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        shape: BoxShape.circle,
                        boxShadow: neonGlow(opacity: 0.6),
                      ),
                      child: const Icon(Icons.dns_rounded,
                          color: Colors.white, size: 30),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        AnimatedBuilder(
                          animation: _pulseAnimation,
                          builder: (context, child) {
                            return Transform.scale(
                              scale: _pulseAnimation.value,
                              child: Container(
                                width: 10,
                                height: 10,
                                decoration: BoxDecoration(
                                  color: apiStatusColor,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color:
                                          apiStatusColor.withOpacity(0.7),
                                      blurRadius: 15,
                                      spreadRadius: 3,
                                    ),
                                    BoxShadow(
                                      color: Colors.white.withOpacity(0.3),
                                      blurRadius: 6,
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                        const SizedBox(width: 10),
                        Text(
                          "SERVER STATUS",
                          style: TextStyle(
                            color: textSecondary.withOpacity(0.7),
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            letterSpacing: 2,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    ShaderMask(
                      shaderCallback: (b) => LinearGradient(
                        colors: [Colors.white, accentColor, primaryColor],
                      ).createShader(b),
                      child: Text(
                        apiStatusText.toUpperCase(),
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      height: 1,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.transparent,
                            accentColor.withOpacity(0.4),
                            Colors.transparent,
                          ],
                        ),
                        boxShadow:
                            neonGlow(blur: 8, spread: 0.3, opacity: 0.4),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.security_rounded,
                          size: 14,
                          color: accentColor.withOpacity(0.6),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          "Protected by NEVERLOUS PROJECT Security",
                          style: TextStyle(
                            color: textSecondary.withOpacity(0.4),
                            fontSize: 10,
                            letterSpacing: 0.5,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ==================== RULES LIST ====================
  Widget _buildRulesList() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 4,
              height: 22,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [primaryColor, accentColor],
                ),
                borderRadius: BorderRadius.circular(2),
                boxShadow: neonGlow(blur: 10, spread: 0.5, opacity: 0.6),
              ),
            ),
            const SizedBox(width: 12),
            ShaderMask(
              shaderCallback: (b) => LinearGradient(
                colors: [Colors.white, accentColor, primaryColor],
              ).createShader(b),
              child: const Text(
                "RULES & REGULATIONS",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1.5,
                ),
              ),
            ),
            const Spacer(),
            Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [primaryColor, accentColor],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: neonGlow(blur: 10, spread: 0.5, opacity: 0.6),
              ),
              child: Text(
                "${rulesList.length} RULES",
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        ListView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: rulesList.length,
          itemBuilder: (context, index) {
            final rule = rulesList[index];
            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [
                          surfaceColor.withOpacity(0.6),
                          surfaceColor.withOpacity(0.3),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: accentColor.withOpacity(0.3),
                        width: 1,
                      ),
                      boxShadow: [
                        ...neonGlow(
                            blur: 12, spread: 0.5, opacity: 0.28),
                        BoxShadow(
                          color: Colors.black.withOpacity(0.3),
                          blurRadius: 12,
                          spreadRadius: 2,
                          offset: const Offset(0, 6),
                        ),
                      ],
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 38,
                          height: 38,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [primaryColor, accentColor],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(12),
                            boxShadow:
                                neonGlow(blur: 12, spread: 0.5, opacity: 0.55),
                          ),
                          child: Center(
                            child: Text(
                              "${index + 1}",
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                rule['title']!,
                                style: TextStyle(
                                  color: textPrimary,
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                rule['desc']!,
                                style: TextStyle(
                                  color: textSecondary.withOpacity(0.8),
                                  fontSize: 12,
                                  height: 1.5,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Icon(
                          Icons.gavel_rounded,
                          color: accentColor.withOpacity(0.3),
                          size: 20,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  // ==================== SANKSI CARD ====================
  Widget _buildSanctionCard() {
    const Color warningColor = Color(0xFFF59E0B);

    return AnimatedBuilder(
      animation: _scaleAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(22),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      warningColor.withOpacity(0.15),
                      warningColor.withOpacity(0.05),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(
                    color: warningColor.withOpacity(0.5),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: warningColor.withOpacity(0.35),
                      blurRadius: 20,
                      spreadRadius: 1,
                    ),
                    BoxShadow(
                      color: Colors.white.withOpacity(0.15),
                      blurRadius: 10,
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            warningColor,
                            warningColor.withOpacity(0.7)
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: warningColor.withOpacity(0.5),
                            blurRadius: 20,
                            spreadRadius: 3,
                          ),
                          BoxShadow(
                            color: Colors.white.withOpacity(0.2),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.gavel_rounded,
                        color: Colors.white,
                        size: 30,
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            "SANKSI",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            "Akun akan dihapus secara permanen!",
                            style: TextStyle(
                              color: warningColor,
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Icon(
                                Icons.block_rounded,
                                color: warningColor.withOpacity(0.6),
                                size: 12,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                "Tidak ada toleransi / refund",
                                style: TextStyle(
                                  color: textSecondary.withOpacity(0.6),
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ==================== FOOTER ====================
  Widget _buildDisclaimerFooter() {
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    surfaceColor.withOpacity(0.6),
                    surfaceColor.withOpacity(0.3),
                  ],
                ),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: accentColor.withOpacity(0.3),
                  width: 1,
                ),
                boxShadow: [
                  ...neonGlow(blur: 12, spread: 0.5, opacity: 0.28),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 12,
                    spreadRadius: 2,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [primaryColor, accentColor],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(10),
                      boxShadow:
                          neonGlow(blur: 10, spread: 0.5, opacity: 0.5),
                    ),
                    child: const Icon(
                      Icons.info_outline_rounded,
                      color: Colors.white,
                      size: 16,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      "By using this application, you agree to all the terms and regulations above.",
                      style: TextStyle(
                        color: textSecondary.withOpacity(0.6),
                        fontSize: 11,
                        height: 1.4,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 20),
        Container(
          width: 60,
          height: 2,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [primaryColor, accentColor],
            ),
            borderRadius: BorderRadius.circular(1),
            boxShadow: neonGlow(blur: 8, spread: 0.3, opacity: 0.6),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          "⚡ NEVERLOUS PROJECT SECURE SYSTEM ⚡",
          style: TextStyle(
            color: textSecondary.withOpacity(0.25),
            fontSize: 9,
            fontWeight: FontWeight.w700,
            letterSpacing: 2,
            shadows: [
              Shadow(
                blurRadius: 8,
                color: accentColor.withOpacity(0.2),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ─── 3D BUBBLE PAINTER ──────────────────────────────────────────────────
class _InfoBubblePainter3D extends CustomPainter {
  final Color color;
  final int count;
  final Animation<double> animation;

  _InfoBubblePainter3D({
    required this.color,
    required this.count,
    required this.animation,
  }) : super(repaint: animation);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    final random = math.Random(42);
    final time = animation.value * 2 * math.pi;

    for (int i = 0; i < count; i++) {
      final baseX = (random.nextDouble() + i * 0.08) % 1.0;
      final baseY = (random.nextDouble() + i * 0.12) % 1.0;
      final radius = 10 + (random.nextDouble() + i * 0.015) % 30;

      final floatX = math.sin(time + i * 0.7) * 0.05;
      final floatY = math.cos(time * 0.6 + i * 0.5) * 0.05;

      final x = (baseX + floatX) * size.width;
      final y = (baseY + floatY) * size.height;

      final depth = 1.0 - (y / size.height) * 0.5;
      final opacity =
          (0.015 + (random.nextDouble() + i * 0.005) % 0.05) * depth;
      paint.color = color.withOpacity(opacity);

      final shadowPaint = Paint()
        ..color = Colors.black.withOpacity(0.02 * depth)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(x + 3, y + 4), radius * 0.9, shadowPaint);

      canvas.drawCircle(Offset(x, y), radius, paint);

      final highlightPaint = Paint()
        ..color = Colors.white.withOpacity(
            (0.01 + (random.nextDouble() + i * 0.003) % 0.015) * depth)
        ..style = PaintingStyle.fill;

      canvas.drawCircle(
        Offset(x - radius * 0.3, y - radius * 0.35),
        radius * 0.2,
        highlightPaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _InfoBubblePainter3D oldDelegate) {
    return oldDelegate.animation != animation;
  }
}