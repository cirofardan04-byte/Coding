// role_helper.dart
import 'package:flutter/material.dart';

String _normalize(String role) {
  return role.toLowerCase().replaceAll('_', ' ');
}

// ═══════════════════════════════════════════════════════════════════════════
// NEON BLUE LIGHT PALETTE
// ═══════════════════════════════════════════════════════════════════════════
// Semua warna role diambil dari keluarga biru neon (electric → cyan →
// ice → navy terang) supaya konsisten dengan tema utama aplikasi.
// Setiap role tetap dibedakan lewat shade yang berbeda.
// ═══════════════════════════════════════════════════════════════════════════

/// Electric Blue (paling terang) — DEV
const Color _roleDev = Color(0xFF00B0FF);

/// Cyan Neon — CEO
const Color _roleCeo = Color(0xFF00E5FF);

/// Sky Blue terang — HIGH ADMIN
const Color _roleHighAdmin = Color(0xFF40C4FF);

/// Soft Blue — OWNER
const Color _roleOwner = Color(0xFF29B6F6);

/// Deep Blue — ADMIN
const Color _roleAdmin = Color(0xFF0288D1);

/// Blue Grey terang — RESELLER
const Color _roleReseller = Color(0xFF4FC3F7);

/// Teal Neon — VIP
const Color _roleVip = Color(0xFF00BCD4);

/// Ice Cyan pudar — MEMBER
const Color _roleMember = Color(0xFF80DEEA);

/// Ice Cyan lebih pudar — TRIAL
const Color _roleTrial = Color(0xFFB3E5FC);

/// Fallback netral
const Color _roleFallback = Color(0xFFB3E5FC);

// ─────────────────────────────────────────────────────────────────────────
// ROLE LEVEL & LOGIC (TIDAK DIUBAH)
// ─────────────────────────────────────────────────────────────────────────

/// Mendapatkan level/tingkatan dari sebuah role
int roleLevel(String role) {
  switch (_normalize(role)) {
    case 'dev':
      return 7;
    case 'ceo':
      return 6;
    case 'high admin':
      return 5;
    case 'owner':
      return 4;
    case 'admin':
      return 3;
    case 'reseller':
      return 2;
    case 'vip':
      return 1;
    case 'member':
      return 0;
    case 'trial':
      return 0; // sama level dengan member
    default:
      return -1;
  }
}

/// Label role untuk UI (huruf besar semua)
String roleLabel(String role) {
  switch (_normalize(role)) {
    case 'dev':
      return 'DEV';
    case 'ceo':
      return 'CEO';
    case 'high admin':
      return 'HIGH ADMIN';
    case 'owner':
      return 'OWNER';
    case 'admin':
      return 'ADMIN';
    case 'reseller':
      return 'RESELLER';
    case 'vip':
      return 'VIP';
    case 'member':
      return 'MEMBER';
    case 'trial':
      return 'TRIAL';
    default:
      return role.toUpperCase();
  }
}

/// Role yang dapat dibuat oleh currentRole (dalam bentuk normal)
List<String> creatableRoles(String currentRole) {
  switch (_normalize(currentRole)) {
    case 'dev':
      return [
        'ceo',
        'high admin',
        'owner',
        'admin',
        'reseller',
        'vip',
        'member',
        'trial'
      ];
    case 'ceo':
      return ['high admin', 'owner', 'admin', 'reseller', 'member'];
    case 'high admin':
      return ['owner', 'admin', 'reseller', 'member'];
    case 'owner':
      return ['admin', 'reseller', 'member'];
    case 'admin':
      return ['reseller', 'member'];
    case 'reseller':
      return ['member'];
    default:
      return [];
  }
}

/// Cek apakah currentRole dapat membuat targetRole
bool canCreateRole(String currentRole, String targetRole) {
  final targetNorm = _normalize(targetRole);
  return creatableRoles(currentRole).contains(targetNorm);
}

/// Cek apakah currentRole dapat menghapus targetRole
bool canDeleteUser(String currentRole, String targetRole) {
  final currentLvl = roleLevel(currentRole);
  final targetLvl = roleLevel(targetRole);
  if (targetLvl >= currentLvl) return false;
  if (_normalize(currentRole) == 'dev' &&
      _normalize(targetRole) != 'dev') {
    return true;
  }
  return targetLvl < currentLvl;
}

/// Cek apakah currentRole dapat mengedit (extend durasi) targetRole
bool canEditUser(String currentRole, String targetRole) {
  return canDeleteUser(currentRole, targetRole);
}

/// Maksimal hari yang dapat diberikan oleh currentRole
int maxDays(String currentRole) {
  switch (_normalize(currentRole)) {
    case 'dev':
      return 9999;
    case 'ceo':
      return 999;
    case 'high admin':
      return 999;
    case 'owner':
      return 999;
    case 'admin':
      return 999;
    case 'reseller':
      return 999;
    default:
      return 0;
  }
}

/// Daftar semua role (untuk filter dropdown)
List<String> getAllRoles() {
  return [
    'dev',
    'ceo',
    'high admin',
    'owner',
    'admin',
    'reseller',
    'vip',
    'member',
    'trial'
  ];
}

/// Mendapatkan role yang lebih tinggi dari role tertentu
List<String> getHigherRoles(String role) {
  final currentLvl = roleLevel(role);
  return getAllRoles().where((r) => roleLevel(r) > currentLvl).toList();
}

/// Mendapatkan role yang lebih rendah dari role tertentu
List<String> getLowerRoles(String role) {
  final currentLvl = roleLevel(role);
  return getAllRoles().where((r) => roleLevel(r) < currentLvl).toList();
}

/// Cek apakah role valid
bool isValidRole(String role) {
  return getAllRoles().contains(_normalize(role));
}

// ─────────────────────────────────────────────────────────────────────────
// ROLE COLOR — NEON BLUE LIGHT
// ─────────────────────────────────────────────────────────────────────────

/// Warna role untuk UI (semua dalam keluarga neon blue)
Color getRoleColor(String role) {
  switch (_normalize(role)) {
    case 'dev':
      return _roleDev;
    case 'ceo':
      return _roleCeo;
    case 'high admin':
      return _roleHighAdmin;
    case 'owner':
      return _roleOwner;
    case 'admin':
      return _roleAdmin;
    case 'reseller':
      return _roleReseller;
    case 'vip':
      return _roleVip;
    case 'member':
      return _roleMember;
    case 'trial':
      return _roleTrial;
    default:
      return _roleFallback;
  }
}

/// Dual shadow (neon + glow putih tipis) untuk role.
/// Cocok dipakai di Container / badge / avatar yang mewakili sebuah role.
///
/// Contoh:
/// ```dart
/// Container(
///   decoration: BoxDecoration(
///     color: getRoleColor('owner').withOpacity(0.15),
///     borderRadius: BorderRadius.circular(12),
///     border: Border.all(color: getRoleColor('owner')),
///     boxShadow: getRoleGlow(getRoleColor('owner')),
///   ),
/// )
/// ```
List<BoxShadow> getRoleGlow(
  Color color, {
  double blur = 14,
  double spread = 0.6,
  double opacity = 0.55,
}) {
  return [
    BoxShadow(
      color: color.withOpacity(opacity),
      blurRadius: blur,
      spreadRadius: spread,
    ),
    BoxShadow(
      color: Colors.white.withOpacity(0.18),
      blurRadius: blur * 0.6,
      spreadRadius: 0.5,
    ),
  ];
}

/// Gradient untuk role tertentu — konsisten dengan palet neon blue.
/// Cocok dipakai sebagai `gradient` di BoxDecoration.
LinearGradient getRoleGradient(String role) {
  final c = getRoleColor(role);
  return LinearGradient(
    colors: [c, c.withOpacity(0.55)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

// ─────────────────────────────────────────────────────────────────────────
// ROLE ICON & DESCRIPTION
// ─────────────────────────────────────────────────────────────────────────

/// Ikon role untuk UI
IconData getRoleIcon(String role) {
  switch (_normalize(role)) {
    case 'dev':
      return Icons.code;
    case 'ceo':
      return Icons.celebration;
    case 'high admin':
      return Icons.security;
    case 'owner':
      return Icons.workspace_premium;
    case 'admin':
      return Icons.admin_panel_settings;
    case 'reseller':
      return Icons.storefront;
    case 'vip':
      return Icons.star;
    default:
      return Icons.person;
  }
}

/// Deskripsi role
String getRoleDescription(String role) {
  switch (_normalize(role)) {
    case 'dev':
      return 'Developer - Akses penuh ke semua fitur';
    case 'ceo':
      return 'CEO - Bisa membuat High Admin ke bawah';
    case 'high admin':
      return 'High Admin - Bisa membuat Owner ke bawah';
    case 'owner':
      return 'Owner - Bisa membuat Admin ke bawah';
    case 'admin':
      return 'Admin - Bisa membuat Reseller ke bawah';
    case 'reseller':
      return 'Reseller - Bisa membuat Member';
    case 'vip':
      return 'VIP - Tidak bisa membuat akun';
    case 'member':
      return 'Member - Tidak bisa membuat akun';
    case 'trial':
      return 'Trial - Tidak bisa membuat akun, akses terbatas';
    default:
      return 'Role tidak dikenal';
  }
}