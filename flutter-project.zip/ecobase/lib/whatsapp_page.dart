// whatsapp_page.dart — Chat mirip WhatsApp (Neon Blue Light)
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:path_provider/path_provider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// ═══════════════════════════════════════════════════════════════════════
// WHATSAPP PAGE (user list)
// ═══════════════════════════════════════════════════════════════════════
class WhatsAppPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;
  const WhatsAppPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<WhatsAppPage> createState() => _WhatsAppPageState();
}

class _WhatsAppPageState extends State<WhatsAppPage>
    with SingleTickerProviderStateMixin {
  final Color primaryColor = const Color(0xFF00B0FF);
  final Color accentColor = const Color(0xFF00B0FF);
  final Color backgroundColor = const Color(0xFF000000);
  final Color cardColor = const Color(0xFF0F2547);
  final Color surfaceColor = const Color(0xFF050B1A);
  final Color textSecondary = const Color(0xFFB3E5FC);

  List<Map<String, dynamic>> _users = [];
  List<Map<String, dynamic>> _filtered = [];
  bool _loading = true;
  final _searchCtrl = TextEditingController();
  late TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 2, vsync: this);
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    setState(() => _loading = true);
    try {
      final res = await http
          .get(Uri.parse(
              'http://raulllll.panelantirusuh.biz.id:10361/chat/users?key=${widget.sessionKey}'))
          .timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final list = (data['users'] as List? ?? [])
            .map((e) => Map<String, dynamic>.from(e))
            .where((u) => u['username'] != widget.username)
            .toList();
        setState(() {
          _users = list;
          _filtered = list;
        });
      }
    } catch (_) {}
    setState(() => _loading = false);
  }

  void _applyFilter(String q) {
    setState(() {
      if (q.isEmpty) {
        _filtered = _users;
      } else {
        _filtered = _users
            .where((u) => (u['username'] ?? '')
                .toString()
                .toLowerCase()
                .contains(q.toLowerCase()))
            .toList();
      }
    });
  }

  @override
  void dispose() {
    _tabs.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      appBar: AppBar(
        backgroundColor: surfaceColor,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'WhatsApp',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            letterSpacing: 1,
          ),
        ),
        bottom: TabBar(
          controller: _tabs,
          indicatorColor: accentColor,
          labelColor: accentColor,
          unselectedLabelColor: Colors.white54,
          tabs: const [
            Tab(text: 'Chat'),
            Tab(text: 'Kontak'),
          ],
        ),
      ),
      body: _loading
          ? Center(child: CircularProgressIndicator(color: accentColor))
          : TabBarView(
              controller: _tabs,
              children: [
                _buildChatTab(),
                _buildContactTab(),
              ],
            ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: primaryColor,
        onPressed: _fetchUsers,
        child: const Icon(Icons.refresh, color: Colors.white),
      ),
    );
  }

  Widget _buildChatTab() {
    if (_filtered.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(FontAwesomeIcons.commentSlash,
                color: textSecondary.withOpacity(0.4), size: 50),
            const SizedBox(height: 12),
            Text('Belum ada chat',
                style: TextStyle(color: textSecondary, fontSize: 14)),
          ],
        ),
      );
    }
    return ListView.builder(
      itemCount: _filtered.length,
      itemBuilder: (ctx, i) => _buildChatItem(_filtered[i]),
    );
  }

  Widget _buildContactTab() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            controller: _searchCtrl,
            onChanged: _applyFilter,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              hintText: 'Cari user...',
              hintStyle: TextStyle(color: textSecondary.withOpacity(0.5)),
              prefixIcon: Icon(Icons.search, color: accentColor),
              filled: true,
              fillColor: cardColor,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(14),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ),
        Expanded(
          child: _filtered.isEmpty
              ? Center(
                  child: Text('Tidak ada user',
                      style: TextStyle(color: textSecondary)))
              : ListView.builder(
                  itemCount: _filtered.length,
                  itemBuilder: (ctx, i) => _buildChatItem(_filtered[i]),
                ),
        ),
      ],
    );
  }

  Widget _buildChatItem(Map<String, dynamic> user) {
    final name = user['username']?.toString() ?? 'User';
    final role = user['role']?.toString() ?? 'member';
    final online = user['online'] == true;

    return GestureDetector(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => ChatRoomPage(
            sessionKey: widget.sessionKey,
            myUsername: widget.username,
            toUsername: name,
            toRole: role,
          ),
        ),
      ),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: primaryColor.withOpacity(0.35)),
          boxShadow: [
            BoxShadow(color: primaryColor.withOpacity(0.2), blurRadius: 10),
            BoxShadow(color: Colors.white.withOpacity(0.1), blurRadius: 5),
          ],
        ),
        child: Row(
          children: [
            Stack(
              children: [
                CircleAvatar(
                  radius: 24,
                  backgroundColor: primaryColor.withOpacity(0.2),
                  child: Text(
                    name.isNotEmpty ? name[0].toUpperCase() : '?',
                    style: TextStyle(
                      color: accentColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ),
                if (online)
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: BoxDecoration(
                        color: Colors.green,
                        shape: BoxShape.circle,
                        border: Border.all(color: cardColor, width: 2),
                      ),
                    ),
                  ),
              ],
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(name,
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 14)),
                  const SizedBox(height: 2),
                  Text(role.toUpperCase(),
                      style: TextStyle(
                          color: textSecondary.withOpacity(0.6),
                          fontSize: 10,
                          letterSpacing: 1)),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: accentColor),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
// CHAT ROOM PAGE
// ═══════════════════════════════════════════════════════════════════════
class ChatRoomPage extends StatefulWidget {
  final String sessionKey;
  final String myUsername;
  final String toUsername;
  final String toRole;
  const ChatRoomPage({
    super.key,
    required this.sessionKey,
    required this.myUsername,
    required this.toUsername,
    required this.toRole,
  });

  @override
  State<ChatRoomPage> createState() => _ChatRoomPageState();
}

class _ChatRoomPageState extends State<ChatRoomPage> {
  final Color primaryColor = const Color(0xFF00B0FF);
  final Color accentColor = const Color(0xFF00B0FF);
  final Color cardColor = const Color(0xFF0F2547);
  final Color surfaceColor = const Color(0xFF050B1A);
  final Color textSecondary = const Color(0xFFB3E5FC);

  final _msgCtrl = TextEditingController();
  final _scrollCtrl = ScrollController();
  final List<Map<String, dynamic>> _messages = [];
  Timer? _poll;

  final AudioRecorder _recorder = AudioRecorder();
  bool _isRecording = false;
  final AudioPlayer _player = AudioPlayer();

  @override
  void initState() {
    super.initState();
    _loadMessages();
    _poll = Timer.periodic(const Duration(seconds: 3), (_) => _loadMessages());
  }

  Future<void> _loadMessages() async {
    try {
      final res = await http
          .get(Uri.parse(
              'http://raulllll.panelantirusuh.biz.id:10361/chat/messages?key=${widget.sessionKey}&to=${widget.toUsername}'))
          .timeout(const Duration(seconds: 6));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final list = (data['messages'] as List? ?? [])
            .map((e) => Map<String, dynamic>.from(e))
            .toList();
        if (!mounted) return;
        setState(() {
          _messages
            ..clear()
            ..addAll(list);
        });
        _scrollBottom();
      }
    } catch (_) {}
  }

  void _scrollBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollCtrl.hasClients) {
        _scrollCtrl.animateTo(
          _scrollCtrl.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _sendMessage({
    String? text,
    String? imagePath,
    String? videoPath,
    String? voicePath,
  }) async {
    final body = {
      'key': widget.sessionKey,
      'from': widget.myUsername,
      'to': widget.toUsername,
      'type': imagePath != null
          ? 'image'
          : videoPath != null
              ? 'video'
              : voicePath != null
                  ? 'voice'
                  : 'text',
      'text': text ?? '',
      'path': imagePath ?? videoPath ?? voicePath ?? '',
      'time': DateTime.now().toIso8601String(),
    };
    try {
      await http
          .post(
            Uri.parse('http://raulllll.panelantirusuh.biz.id:10361/chat/send'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 10));
      _loadMessages();
    } catch (_) {}
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final file = await picker.pickImage(
        source: ImageSource.gallery, imageQuality: 70);
    if (file == null) return;
    await _sendMessage(imagePath: file.path);
  }

  Future<void> _pickVideo() async {
    final picker = ImagePicker();
    final file = await picker.pickVideo(source: ImageSource.gallery);
    if (file == null) return;
    await _sendMessage(videoPath: file.path);
  }

  Future<void> _startRecord() async {
    if (await _recorder.hasPermission()) {
      final dir = await getTemporaryDirectory();
      final path =
          '${dir.path}/vn_${DateTime.now().millisecondsSinceEpoch}.m4a';
      await _recorder.start(const RecordConfig(), path: path);
      if (!mounted) return;
      setState(() => _isRecording = true);
    }
  }

  Future<void> _stopRecord() async {
    final path = await _recorder.stop();
    if (!mounted) return;
    setState(() => _isRecording = false);
    if (path != null) {
      await _sendMessage(voicePath: path);
    }
  }

  Future<void> _playVoice(String pathOrUrl) async {
    try {
      await _player.stop();
      if (pathOrUrl.startsWith('http')) {
        await _player.play(UrlSource(pathOrUrl));
      } else {
        await _player.play(DeviceFileSource(pathOrUrl));
      }
    } catch (_) {}
  }

  @override
  void dispose() {
    _poll?.cancel();
    _msgCtrl.dispose();
    _scrollCtrl.dispose();
    _recorder.dispose();
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF000000),
      appBar: AppBar(
        backgroundColor: surfaceColor,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: Row(
          children: [
            CircleAvatar(
              radius: 16,
              backgroundColor: primaryColor.withOpacity(0.2),
              child: Text(
                widget.toUsername.isNotEmpty
                    ? widget.toUsername[0].toUpperCase()
                    : '?',
                style: TextStyle(color: accentColor, fontSize: 14),
              ),
            ),
            const SizedBox(width: 10),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(widget.toUsername,
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 14,
                        fontWeight: FontWeight.w600)),
                Text(widget.toRole.toUpperCase(),
                    style: TextStyle(
                        color: textSecondary.withOpacity(0.6),
                        fontSize: 10,
                        letterSpacing: 1)),
              ],
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollCtrl,
              padding: const EdgeInsets.all(12),
              itemCount: _messages.length,
              itemBuilder: (ctx, i) => _buildBubble(_messages[i]),
            ),
          ),
          if (_isRecording)
            Container(
              padding: const EdgeInsets.all(12),
              color: Colors.red.withOpacity(0.15),
              child: const Row(
                children: [
                  Icon(Icons.fiber_manual_record, color: Colors.red, size: 14),
                  SizedBox(width: 8),
                  Text('Merekam voice note...',
                      style: TextStyle(color: Colors.white)),
                ],
              ),
            ),
          _buildComposer(),
        ],
      ),
    );
  }

  Widget _buildBubble(Map<String, dynamic> msg) {
    final isMe = msg['from'] == widget.myUsername;
    final type = msg['type'] ?? 'text';
    return Align(
      alignment: isMe ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.all(10),
        constraints:
            BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: isMe
                ? [primaryColor.withOpacity(0.85), accentColor.withOpacity(0.6)]
                : [cardColor, cardColor.withOpacity(0.8)],
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: isMe ? accentColor.withOpacity(0.5) : Colors.white12,
          ),
          boxShadow: [
            BoxShadow(
              color: (isMe ? accentColor : primaryColor).withOpacity(0.3),
              blurRadius: 8,
            ),
            BoxShadow(color: Colors.white.withOpacity(0.1), blurRadius: 4),
          ],
        ),
        child: _buildBubbleContent(type, msg),
      ),
    );
  }

  Widget _buildBubbleContent(String type, Map<String, dynamic> msg) {
    if (type == 'image') {
      final path = msg['path']?.toString() ?? '';
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: path.startsWith('http')
                ? Image.network(path, width: 180, fit: BoxFit.cover)
                : Image.file(File(path), width: 180, fit: BoxFit.cover),
          ),
          const SizedBox(height: 4),
          if ((msg['text'] ?? '').toString().isNotEmpty)
            Text(msg['text'].toString(),
                style: const TextStyle(color: Colors.white, fontSize: 13)),
        ],
      );
    }
    if (type == 'voice') {
      final path = msg['path']?.toString() ?? '';
      return Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            onPressed: () => _playVoice(path),
            icon: Icon(Icons.play_arrow_rounded, color: accentColor),
          ),
          Text('Voice Note',
              style: TextStyle(color: textSecondary, fontSize: 12)),
        ],
      );
    }
    if (type == 'video') {
      return Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.videocam, color: accentColor),
          const SizedBox(width: 8),
          const Text('Video',
              style: TextStyle(color: Colors.white, fontSize: 13)),
        ],
      );
    }
    return Text(
      msg['text']?.toString() ?? '',
      style: const TextStyle(color: Colors.white, fontSize: 14),
    );
  }

  Widget _buildComposer() {
    return Container(
      padding: const EdgeInsets.all(8),
      color: surfaceColor,
      child: Row(
        children: [
          IconButton(
            onPressed: _pickImage,
            icon: Icon(Icons.photo, color: accentColor),
          ),
          IconButton(
            onPressed: _pickVideo,
            icon: Icon(Icons.videocam, color: accentColor),
          ),
          Expanded(
            child: TextField(
              controller: _msgCtrl,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: 'Ketik pesan...',
                hintStyle: TextStyle(color: textSecondary.withOpacity(0.5)),
                filled: true,
                fillColor: cardColor,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(24),
                  borderSide: BorderSide.none,
                ),
                contentPadding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              ),
            ),
          ),
          GestureDetector(
            onLongPress: _startRecord,
            onLongPressUp: _stopRecord,
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 4),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: _isRecording ? Colors.red : primaryColor,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: (_isRecording ? Colors.red : primaryColor)
                        .withOpacity(0.5),
                    blurRadius: 10,
                  ),
                  BoxShadow(
                      color: Colors.white.withOpacity(0.15), blurRadius: 5),
                ],
              ),
              child: Icon(
                _isRecording ? Icons.mic : Icons.mic_none,
                color: Colors.white,
                size: 20,
              ),
            ),
          ),
          IconButton(
            onPressed: () {
              final t = _msgCtrl.text.trim();
              if (t.isEmpty) return;
              _msgCtrl.clear();
              _sendMessage(text: t);
            },
            icon: Icon(Icons.send, color: accentColor),
          ),
        ],
      ),
    );
  }
}