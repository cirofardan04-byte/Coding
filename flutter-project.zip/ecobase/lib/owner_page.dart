import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'role_helper.dart';

class OwnerPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String currentUserRole;

  const OwnerPage({
    super.key,
    required this.sessionKey,
    required this.username,
    this.currentUserRole = 'owner',
  });

  @override
  State<OwnerPage> createState() => _OwnerPageState();
}

class _OwnerPageState extends State<OwnerPage> {
  late String sessionKey;
  late String currentUserRole;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];

  late List<String> allRoleList;
  String selectedFilterRole = 'all';

  List<String> creatableRoleList = [];
  String selectedCreateRole = 'member';

  int currentPage = 1;
  int itemsPerPage = 25;

  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  final deleteController = TextEditingController();
  final editUsernameController = TextEditingController();
  final editDayController = TextEditingController();

  bool isLoading = false;

  late VideoPlayerController _backgroundVideoController;
  bool _backgroundVideoInitialized = false;

  // ====== NEON BLUE LIGHT THEME (BLACK BASE) ======
  final Color primaryColor = const Color(0xFF00B0FF);
  final Color accentColor = const Color(0xFF00B0FF);
  final Color backgroundColor = const Color(0xFF000000);
  final Color surfaceColor = const Color(0xFF050B1A);
  final Color cardColor = const Color(0xFF0F2547);
  final Color textPrimary = Colors.white;
  final Color textSecondary = const Color(0xFFB3E5FC);

  // White glow helper (dual shadow)
  List<BoxShadow> neonGlow({
    Color color = const Color(0xFF00B0FF),
    double blur = 16,
    double spread = 1.5,
    double opacity = 0.55,
  }) {
    return [
      BoxShadow(
        color: color.withOpacity(opacity),
        blurRadius: blur,
        spreadRadius: spread,
      ),
      BoxShadow(
        color: Colors.white.withOpacity(0.18),
        blurRadius: blur * 0.6,
        spreadRadius: 0.5,
      ),
    ];
  }

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    currentUserRole = widget.currentUserRole;
    _initRoleLists();
    _fetchUsers();
    _initBackgroundVideo();
  }

  void _initBackgroundVideo() {
    _backgroundVideoController =
        VideoPlayerController.asset('assets/videos/splash.mp4')
          ..initialize().then((_) {
            if (mounted) {
              setState(() => _backgroundVideoInitialized = true);
              _backgroundVideoController.setLooping(true);
              _backgroundVideoController.setVolume(0);
              _backgroundVideoController.play();
            }
          }).catchError((error) {
            debugPrint("Background video error: $error");
          });
  }

  void _initRoleLists() {
    allRoleList = ['all', ...getAllRoles()];
    creatableRoleList = creatableRoles(currentUserRole);
    if (creatableRoleList.isNotEmpty) {
      selectedCreateRole = creatableRoleList.first;
    }
    selectedFilterRole = 'all';
  }

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse(
            'http://raulllll.panelantirusuh.biz.id:10361/listUsers?key=$sessionKey'),
      );
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['authorized'] == true) {
        fullUserList = data['users'] ?? [];
        _applyFilter();
      } else {
        _alert("Info", data['message'] ?? 'Gagal memuat user.');
      }
    } catch (_) {
      _alert("Error", "Gagal terhubung ke server.");
    }
    setState(() => isLoading = false);
  }

  void _applyFilter() {
    setState(() {
      currentPage = 1;
      if (selectedFilterRole == 'all') {
        filteredList = List.from(fullUserList);
      } else {
        filteredList = fullUserList
            .where((u) =>
                u['role'].toString().toLowerCase() ==
                selectedFilterRole.toLowerCase())
            .toList();
      }
    });
  }

  List<dynamic> _getCurrentPageData() {
    if (filteredList.isEmpty) return [];
    final start = (currentPage - 1) * itemsPerPage;
    final end = start + itemsPerPage;
    if (start >= filteredList.length) return [];
    return filteredList.sublist(
        start, end > filteredList.length ? filteredList.length : end);
  }

  int get totalPages =>
      filteredList.isEmpty ? 1 : (filteredList.length / itemsPerPage).ceil();

  bool _canDeleteUser(String targetRole) =>
      canDeleteUser(currentUserRole, targetRole);
  bool _canEditUser(String targetRole) =>
      canEditUser(currentUserRole, targetRole);

  Future<void> _deleteUser() async {
    final username = deleteController.text.trim();
    if (username.isEmpty) {
      _alert("Peringatan", "Masukkan username yang ingin dihapus.");
      return;
    }

    final targetUser = fullUserList.firstWhere(
      (u) => u['username'] == username,
      orElse: () => null,
    );

    if (targetUser == null) {
      _alert("Error", "User tidak ditemukan.");
      return;
    }

    final targetRole = targetUser['role'].toString().toLowerCase();
    if (!_canDeleteUser(targetRole)) {
      _alert("⛔ Akses Ditolak",
          "Anda tidak memiliki izin untuk menghapus user dengan role ${roleLabel(targetRole)}.\nHanya bisa menghapus role yang levelnya lebih rendah.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(
        Uri.parse(
            'http://raulllll.panelantirusuh.biz.id:10361/deleteUser?key=$sessionKey&username=$username'),
      );
      final data = jsonDecode(res.body);
      if (data['deleted'] == true) {
        _alert("Sukses", "User berhasil dihapus.");
        deleteController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal menghapus user.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _createAccount() async {
    final u = createUsernameController.text.trim();
    final p = createPasswordController.text.trim();
    final d = createDayController.text.trim();

    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    if (!canCreateRole(currentUserRole, selectedCreateRole)) {
      _alert("⛔ Akses Ditolak",
          "Anda tidak memiliki izin untuk membuat user dengan role ${roleLabel(selectedCreateRole)}.");
      return;
    }

    final days = int.tryParse(d);
    final maxDur = maxDays(currentUserRole);
    if (days != null && days > maxDur) {
      _alert("Peringatan",
          "Maksimal durasi untuk ${roleLabel(currentUserRole)} adalah $maxDur hari.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        'http://raulllll.panelantirusuh.biz.id:10361/userAdd?key=$sessionKey&username=$u&password=$p&day=$d&role=$selectedCreateRole',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _alert("Sukses",
            "Akun berhasil dibuat sebagai ${roleLabel(selectedCreateRole)}.");
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        selectedCreateRole =
            creatableRoleList.isNotEmpty ? creatableRoleList.first : 'member';
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal membuat akun.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  Future<void> _editUser() async {
    final u = editUsernameController.text.trim();
    final d = editDayController.text.trim();

    if (u.isEmpty || d.isEmpty) {
      _alert("Peringatan", "Semua field wajib diisi.");
      return;
    }

    final targetUser = fullUserList.firstWhere(
      (user) => user['username'] == u,
      orElse: () => null,
    );

    if (targetUser == null) {
      _alert("Error", "User tidak ditemukan.");
      return;
    }

    final targetRole = targetUser['role'].toString().toLowerCase();
    if (!_canEditUser(targetRole)) {
      _alert("⛔ Akses Ditolak",
          "Anda tidak memiliki izin untuk mengedit user dengan role ${roleLabel(targetRole)}.");
      return;
    }

    final days = int.tryParse(d);
    final maxDur = maxDays(currentUserRole);
    if (days != null && days > maxDur) {
      _alert("Peringatan",
          "Maksimal tambahan durasi untuk ${roleLabel(currentUserRole)} adalah $maxDur hari.");
      return;
    }

    setState(() => isLoading = true);
    try {
      final url = Uri.parse(
        'http://raulllll.panelantirusuh.biz.id:10361/editUser?key=$sessionKey&username=$u&addDays=$d',
      );
      final res = await http.get(url);
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _alert("Sukses", "Durasi berhasil diperbarui.");
        editUsernameController.clear();
        editDayController.clear();
        _fetchUsers();
      } else {
        _alert("Gagal", data['message'] ?? 'Gagal mengubah durasi.');
      }
    } catch (_) {
      _alert("Error", "Gagal menghubungi server.");
    }
    setState(() => isLoading = false);
  }

  void _alert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: TweenAnimationBuilder(
          duration: const Duration(milliseconds: 300),
          tween: Tween<double>(begin: 0, end: 1),
          builder: (context, double scale, child) =>
              Transform.scale(scale: scale, child: child),
          child: Container(
            margin: const EdgeInsets.all(20),
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: cardColor,
              borderRadius: BorderRadius.circular(32),
              border:
                  Border.all(color: primaryColor.withOpacity(0.55), width: 1.5),
              boxShadow: neonGlow(opacity: 0.5),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient:
                        LinearGradient(colors: [primaryColor, accentColor]),
                    shape: BoxShape.circle,
                    boxShadow: neonGlow(opacity: 0.6),
                  ),
                  child: Icon(
                      title == "Sukses"
                          ? Icons.check_circle
                          : Icons.warning_rounded,
                      color: Colors.white,
                      size: 32),
                ),
                const SizedBox(height: 20),
                Text(title,
                    style: TextStyle(
                        color: textPrimary,
                        fontSize: 20,
                        fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Text(message,
                    textAlign: TextAlign.center,
                    style: TextStyle(color: textSecondary, fontSize: 14)),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                            colors: [primaryColor, accentColor]),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: neonGlow(opacity: 0.5),
                      ),
                      child: const Center(
                          child: Text("OK",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold))),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInput({
    required String label,
    required TextEditingController controller,
    required IconData icon,
    TextInputType type = TextInputType.text,
    String hint = "",
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: Container(
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: primaryColor.withOpacity(0.45)),
          boxShadow: neonGlow(blur: 10, spread: 0.5, opacity: 0.35),
        ),
        child: TextField(
          controller: controller,
          keyboardType: type,
          style: TextStyle(color: textPrimary),
          cursorColor: accentColor,
          decoration: InputDecoration(
            labelText: label,
            hintText: hint,
            hintStyle: TextStyle(color: textSecondary.withOpacity(0.6)),
            labelStyle: TextStyle(color: textSecondary),
            prefixIcon: Icon(icon, color: accentColor, size: 20),
            border: InputBorder.none,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          ),
        ),
      ),
    );
  }

  Widget _buildGlassCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 500),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) => Opacity(
        opacity: value,
        child:
            Transform.translate(offset: Offset(0, 20 * (1 - value)), child: child),
      ),
      child: Container(
        margin: const EdgeInsets.only(bottom: 24),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: surfaceColor,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: primaryColor.withOpacity(0.45), width: 1),
          boxShadow: neonGlow(blur: 18, spread: 1, opacity: 0.4),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    gradient:
                        LinearGradient(colors: [primaryColor, accentColor]),
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: neonGlow(opacity: 0.55),
                  ),
                  child: Icon(icon, color: Colors.white, size: 20),
                ),
                const SizedBox(width: 12),
                Text(title,
                    style: TextStyle(
                        color: textPrimary,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1)),
              ],
            ),
            const SizedBox(height: 20),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _buildUserItem(Map user) {
    final targetRole = user['role'].toString().toLowerCase();
    final canDelete = _canDeleteUser(targetRole);
    final canEdit = _canEditUser(targetRole);

    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 300),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) => Opacity(
        opacity: value,
        child:
            Transform.translate(offset: Offset(0, 20 * (1 - value)), child: child),
      ),
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: primaryColor.withOpacity(0.4)),
          boxShadow: neonGlow(blur: 10, spread: 0.5, opacity: 0.35),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient:
                    LinearGradient(colors: [primaryColor, accentColor]),
                shape: BoxShape.circle,
                boxShadow: neonGlow(opacity: 0.6),
              ),
              child: Text(user['username'][0].toUpperCase(),
                  style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14)),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(user['username'],
                      style: TextStyle(
                          color: textPrimary,
                          fontWeight: FontWeight.bold,
                          fontSize: 15)),
                  const SizedBox(height: 4),
                  Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: primaryColor.withOpacity(0.18),
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                              color: primaryColor.withOpacity(0.45)),
                          boxShadow: neonGlow(
                              blur: 6, spread: 0.3, opacity: 0.4),
                        ),
                        child: Text(roleLabel(targetRole),
                            style: TextStyle(
                                color: accentColor,
                                fontSize: 10,
                                fontWeight: FontWeight.w600)),
                      ),
                      Text("Exp: ${user['expiredDate']}",
                          style: TextStyle(
                              color: textSecondary, fontSize: 11)),
                      Text("Parent: ${user['parent'] ?? 'SYSTEM'}",
                          style: TextStyle(
                              color: textSecondary, fontSize: 11)),
                    ],
                  ),
                ],
              ),
            ),
            if (canEdit)
              GestureDetector(
                onTap: () {
                  editUsernameController.text = user['username'];
                  _alert("Info",
                      "Masukkan jumlah hari untuk memperpanjang durasi ${user['username']}.");
                },
                child: Container(
                  padding: const EdgeInsets.all(8),
                  margin: const EdgeInsets.only(right: 8),
                  decoration: BoxDecoration(
                    color: Colors.blue.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                    border:
                        Border.all(color: Colors.blue.withOpacity(0.5)),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.blue.withOpacity(0.4),
                        blurRadius: 10,
                      ),
                      BoxShadow(
                        color: Colors.white.withOpacity(0.12),
                        blurRadius: 5,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.edit_calendar,
                      color: Colors.blueAccent, size: 20),
                ),
              ),
            if (canDelete)
              GestureDetector(
                onTap: () async {
                  final confirm = await showDialog<bool>(
                    context: context,
                    builder: (_) => Dialog(
                      backgroundColor: Colors.transparent,
                      child: TweenAnimationBuilder(
                        duration: const Duration(milliseconds: 300),
                        tween: Tween<double>(begin: 0, end: 1),
                        builder: (context, double scale, child) =>
                            Transform.scale(scale: scale, child: child),
                        child: Container(
                          margin: const EdgeInsets.all(20),
                          padding: const EdgeInsets.all(24),
                          decoration: BoxDecoration(
                            color: cardColor,
                            borderRadius: BorderRadius.circular(32),
                            border: Border.all(
                                color: const Color(0xFFEF4444)
                                    .withOpacity(0.6),
                                width: 1.5),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFFEF4444)
                                    .withOpacity(0.45),
                                blurRadius: 16,
                                spreadRadius: 1.5,
                              ),
                              BoxShadow(
                                color: Colors.white.withOpacity(0.15),
                                blurRadius: 8,
                              ),
                            ],
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(16),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFEF4444)
                                      .withOpacity(0.15),
                                  shape: BoxShape.circle,
                                  border: Border.all(
                                      color: const Color(0xFFEF4444)
                                          .withOpacity(0.4)),
                                ),
                                child: const Icon(
                                    Icons.warning_amber_rounded,
                                    color: Color(0xFFEF4444),
                                    size: 32),
                              ),
                              const SizedBox(height: 20),
                              const Text("Konfirmasi Hapus",
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 20)),
                              const SizedBox(height: 8),
                              Text("Hapus user ${user['username']}?",
                                  style: TextStyle(
                                      color: textSecondary, fontSize: 14),
                                  textAlign: TextAlign.center),
                              const SizedBox(height: 24),
                              Row(
                                children: [
                                  Expanded(
                                    child: GestureDetector(
                                      onTap: () =>
                                          Navigator.pop(context, false),
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 12),
                                        decoration: BoxDecoration(
                                          color: Colors.white
                                              .withOpacity(0.05),
                                          borderRadius:
                                              BorderRadius.circular(16),
                                          border: Border.all(
                                              color: Colors.white
                                                  .withOpacity(0.15)),
                                        ),
                                        child: Center(
                                            child: Text("BATAL",
                                                style: TextStyle(
                                                    color: textSecondary,
                                                    fontWeight:
                                                        FontWeight.w600))),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: GestureDetector(
                                      onTap: () =>
                                          Navigator.pop(context, true),
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            vertical: 12),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFEF4444)
                                              .withOpacity(0.15),
                                          borderRadius:
                                              BorderRadius.circular(16),
                                          border: Border.all(
                                              color: const Color(0xFFEF4444)
                                                  .withOpacity(0.5)),
                                        ),
                                        child: const Center(
                                            child: Text("HAPUS",
                                                style: TextStyle(
                                                    color:
                                                        Color(0xFFEF4444),
                                                    fontWeight:
                                                        FontWeight.w600))),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                  if (confirm == true) {
                    deleteController.text = user['username'];
                    _deleteUser();
                  }
                },
                child: Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEF4444).withOpacity(0.15),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: const Color(0xFFEF4444).withOpacity(0.4)),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFFEF4444).withOpacity(0.4),
                        blurRadius: 10,
                      ),
                      BoxShadow(
                        color: Colors.white.withOpacity(0.12),
                        blurRadius: 5,
                      ),
                    ],
                  ),
                  child: const Icon(Icons.delete_outline,
                      color: Color(0xFFEF4444), size: 20),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildPagination() {
    if (totalPages <= 1) return const SizedBox.shrink();
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: List.generate(totalPages > 10 ? 10 : totalPages, (index) {
        final page = index + 1;
        return GestureDetector(
          onTap: () => setState(() => currentPage = page),
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              gradient: currentPage == page
                  ? LinearGradient(colors: [primaryColor, accentColor])
                  : null,
              color: currentPage == page ? null : cardColor,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: currentPage == page
                    ? accentColor
                    : primaryColor.withOpacity(0.4),
              ),
              boxShadow: currentPage == page
                  ? neonGlow(blur: 12, spread: 0.5, opacity: 0.5)
                  : null,
            ),
            child: Text("$page",
                style: TextStyle(
                    color:
                        currentPage == page ? Colors.white : textSecondary,
                    fontSize: 12,
                    fontWeight: currentPage == page
                        ? FontWeight.bold
                        : FontWeight.normal)),
          ),
        );
      }),
    );
  }

  @override
  void dispose() {
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    deleteController.dispose();
    editUsernameController.dispose();
    editDayController.dispose();
    _backgroundVideoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final maxDur = maxDays(currentUserRole);
    final canCreate = creatableRoleList.isNotEmpty;

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Stack(
        children: [
          if (_backgroundVideoInitialized)
            SizedBox(
              width: double.infinity,
              height: double.infinity,
              child: VideoPlayer(_backgroundVideoController),
            )
          else
            Container(color: backgroundColor),

          // Overlay biru neon gelap
          Container(
            color: const Color(0xFF001028).withOpacity(0.6),
          ),

          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  TweenAnimationBuilder(
                    duration: const Duration(milliseconds: 600),
                    tween: Tween<double>(begin: 0, end: 1),
                    builder: (context, double value, child) => Opacity(
                        opacity: value,
                        child: Transform.scale(scale: value, child: child)),
                    child: Column(
                      children: [
                        Container(
                          width: 70,
                          height: 70,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                                colors: [primaryColor, accentColor]),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                color: primaryColor.withOpacity(0.7),
                                blurRadius: 30,
                                spreadRadius: 5,
                              ),
                              BoxShadow(
                                color: Colors.white.withOpacity(0.25),
                                blurRadius: 14,
                                spreadRadius: 1,
                              ),
                            ],
                          ),
                          child: const Center(
                              child: Icon(Icons.workspace_premium,
                                  color: Colors.white, size: 36)),
                        ),
                        const SizedBox(height: 16),
                        ShaderMask(
                          shaderCallback: (bounds) => LinearGradient(
                            colors: [
                              Colors.white,
                              accentColor,
                              primaryColor,
                            ],
                          ).createShader(bounds),
                          child: Text(
                              "${roleLabel(currentUserRole)} DASHBOARD",
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 2)),
                        ),
                        const SizedBox(height: 8),
                        if (maxDur > 0)
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 12, vertical: 4),
                            decoration: BoxDecoration(
                              color: primaryColor.withOpacity(0.18),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                  color: primaryColor.withOpacity(0.45)),
                              boxShadow: neonGlow(
                                  blur: 8, spread: 0.3, opacity: 0.4),
                            ),
                            child: Text("Maksimal Durasi: $maxDur Hari",
                                style: TextStyle(
                                    color: accentColor, fontSize: 12)),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  _buildGlassCard(
                    title: "DELETE USER",
                    icon: FontAwesomeIcons.userSlash,
                    children: [
                      _buildInput(
                          label: "Username Target",
                          controller: deleteController,
                          icon: FontAwesomeIcons.user),
                      const SizedBox(height: 8),
                      Container(
                        height: 50,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                              colors: [
                                Color(0xFFEF4444),
                                Color(0xFFB91C1C)
                              ]),
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: const Color(0xFFEF4444)
                                  .withOpacity(0.5),
                              blurRadius: 14,
                              spreadRadius: 1,
                            ),
                            BoxShadow(
                              color: Colors.white.withOpacity(0.15),
                              blurRadius: 8,
                            ),
                          ],
                        ),
                        child: ElevatedButton(
                          onPressed: isLoading ? null : _deleteUser,
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              shadowColor: Colors.transparent),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.delete,
                                  size: 18, color: Colors.white),
                              SizedBox(width: 8),
                              Text("DELETE ACCOUNT",
                                  style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1,
                                      color: Colors.white)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),

                  if (canCreate)
                    _buildGlassCard(
                      title: "CREATE ACCOUNT",
                      icon: FontAwesomeIcons.userPlus,
                      children: [
                        _buildInput(
                            label: "Username",
                            controller: createUsernameController,
                            icon: FontAwesomeIcons.user),
                        _buildInput(
                            label: "Password",
                            controller: createPasswordController,
                            icon: FontAwesomeIcons.lock),
                        _buildInput(
                          label: "Durasi (Hari)",
                          controller: createDayController,
                          icon: FontAwesomeIcons.calendarDay,
                          type: TextInputType.number,
                          hint: "Maksimal $maxDur hari",
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16, vertical: 4),
                          decoration: BoxDecoration(
                            color: cardColor,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                                color: primaryColor.withOpacity(0.45)),
                            boxShadow: neonGlow(
                                blur: 10, spread: 0.5, opacity: 0.3),
                          ),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<String>(
                              value: selectedCreateRole,
                              dropdownColor: surfaceColor,
                              style: TextStyle(color: textPrimary),
                              items: creatableRoleList.map((role) {
                                return DropdownMenuItem(
                                    value: role,
                                    child: Text(roleLabel(role)));
                              }).toList(),
                              onChanged: (val) => setState(
                                  () => selectedCreateRole = val ?? 'member'),
                            ),
                          ),
                        ),
                        const SizedBox(height: 16),
                        Container(
                          height: 50,
                          width: double.infinity,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                                colors: [primaryColor, accentColor]),
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: neonGlow(opacity: 0.55),
                          ),
                          child: ElevatedButton(
                            onPressed: isLoading ? null : _createAccount,
                            style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.transparent,
                                shadowColor: Colors.transparent),
                            child: isLoading
                                ? const SizedBox(
                                    width: 20,
                                    height: 20,
                                    child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Colors.white))
                                : const Text("CREATE ACCOUNT",
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 1)),
                          ),
                        ),
                      ],
                    ),

                  _buildGlassCard(
                    title: "EXTEND DURATION",
                    icon: FontAwesomeIcons.clock,
                    children: [
                      _buildInput(
                          label: "Username Target",
                          controller: editUsernameController,
                          icon: FontAwesomeIcons.userEdit),
                      _buildInput(
                        label: "Tambah Hari",
                        controller: editDayController,
                        icon: FontAwesomeIcons.calendarPlus,
                        type: TextInputType.number,
                        hint: "Maksimal $maxDur hari",
                      ),
                      const SizedBox(height: 8),
                      Container(
                        height: 50,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                              colors: [
                                Color(0xFF3B82F6),
                                Color(0xFF1D4ED8)
                              ]),
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.blue.withOpacity(0.5),
                              blurRadius: 14,
                              spreadRadius: 1,
                            ),
                            BoxShadow(
                              color: Colors.white.withOpacity(0.15),
                              blurRadius: 8,
                            ),
                          ],
                        ),
                        child: ElevatedButton(
                          onPressed: isLoading ? null : _editUser,
                          style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.transparent,
                              shadowColor: Colors.transparent),
                          child: const Text("ADD DAYS",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1)),
                        ),
                      ),
                    ],
                  ),

                  _buildGlassCard(
                    title: "USER LIST",
                    icon: FontAwesomeIcons.users,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 4),
                        decoration: BoxDecoration(
                          color: cardColor,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                              color: primaryColor.withOpacity(0.45)),
                          boxShadow: neonGlow(
                              blur: 10, spread: 0.5, opacity: 0.3),
                        ),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton<String>(
                            value: selectedFilterRole,
                            dropdownColor: surfaceColor,
                            style: TextStyle(color: textPrimary),
                            items: allRoleList.map((role) {
                              return DropdownMenuItem(
                                value: role,
                                child: Text(role == 'all'
                                    ? 'SEMUA ROLE'
                                    : roleLabel(role)),
                              );
                            }).toList(),
                            onChanged: (val) {
                              if (val != null) {
                                selectedFilterRole = val;
                                _applyFilter();
                              }
                            },
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                      isLoading
                          ? Center(
                              child: CircularProgressIndicator(
                                  color: accentColor, strokeWidth: 3))
                          : filteredList.isEmpty
                              ? Center(
                                  child: Text("Tidak ada user",
                                      style:
                                          TextStyle(color: textSecondary)))
                              : Column(
                                  children: [
                                    ..._getCurrentPageData()
                                        .map((u) => _buildUserItem(u))
                                        .toList(),
                                    const SizedBox(height: 16),
                                    _buildPagination(),
                                  ],
                                ),
                    ],
                  ),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}