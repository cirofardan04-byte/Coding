import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'login_page.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<double> _pulseAnimation;
  late Animation<double> _rotateAnimation;

  final String bannerUrl = "https://files.catbox.moe/w7tjwt.jpg/pjsw43.jpg";
  static const String _apiBase = "http://raulllll.panelantirusuh.biz.id:10361";

  // ====== NEON BLUE LIGHT THEME (BLACK BASE) ======
  final Color primaryColor = const Color(0xFF00B0FF);
  final Color accentColor = const Color(0xFF00B0FF);
  final Color darkPrimary = const Color(0xFF0077C2);
  final Color backgroundColor = const Color(0xFF000000);
  final Color surfaceColor = const Color(0xFF050B1A);
  final Color cardColor = const Color(0xFF0F2547);
  final Color textPrimary = Colors.white;
  final Color textSecondary = const Color(0xFFB3E5FC);

  // ─── Live data ─────────────────────────────────────────────
  Timer? _clockTimer;
  Timer? _pingTimer;
  Timer? _weatherTimer;
  String _digitalTime = "00:00:00";
  String _digitalDate = "";
  int _pingMs = 0;
  bool _serverOnline = false;
  String _tempC = "--";
  String _weatherDesc = "Memuat...";
  String _weatherIcon = "🌤️";

  // ─── Tutorial state ────────────────────────────────────────
  late PageController _tutorialCtrl;
  int _tutorialIndex = 0;

  final List<Map<String, dynamic>> _tutorialSlides = [
    {
      "icon": Icons.login_rounded,
      "title": "LANGKAH 1",
      "subtitle": "Login Akun",
      "desc":
          "Masukkan username dan password yang sudah kamu terima dari admin NEVERLOUS PROJECT. Pastikan tidak ada spasi tambahan.",
      "color": const Color(0xFF00B0FF),
    },
    {
      "icon": Icons.rocket_launch_rounded,
      "title": "LANGKAH 2",
      "subtitle": "Pilih Fitur & Sender",
      "desc":
          "Setelah login, pilih fitur yang kamu butuhkan (Bug, RAT, WhatsApp, dll). Tambahkan sender terlebih dahulu sebelum mengirim bug.",
      "color": const Color(0xFF00E5FF),
    },
    {
      "icon": Icons.verified_user_rounded,
      "title": "LANGKAH 3",
      "subtitle": "Gunakan Dengan Bijak",
      "desc":
          "Gunakan APK ini hanya untuk keperluan yang sah. Pelanggaran aturan akan berakibat akun dihapus permanen tanpa refund.",
      "color": const Color(0xFF4DD0E1),
    },
  ];

  bool _showTutorial = true;

  // White glow helper (dual shadow)
  List<BoxShadow> neonGlow({
    Color color = const Color(0xFF00B0FF),
    double blur = 16,
    double spread = 1.5,
    double opacity = 0.55,
  }) {
    return [
      BoxShadow(
        color: color.withOpacity(opacity),
        blurRadius: blur,
        spreadRadius: spread,
      ),
      BoxShadow(
        color: Colors.white.withOpacity(0.18),
        blurRadius: blur * 0.6,
        spreadRadius: 0.5,
      ),
    ];
  }

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..forward();

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );

    _slideAnimation =
        Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero).animate(
      CurvedAnimation(
          parent: _animationController, curve: Curves.easeOutCubic),
    );

    _scaleAnimation = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOutBack),
    );

    _pulseAnimation = Tween<double>(begin: 0.97, end: 1.03).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    _rotateAnimation = Tween<double>(begin: -0.02, end: 0.02).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );

    _tutorialCtrl = PageController();

    _startClock();
    _startPingLoop();
    _fetchWeather();
    _weatherTimer = Timer.periodic(
      const Duration(minutes: 15),
      (_) => _fetchWeather(),
    );
  }

  void _startClock() {
    _updateClock();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      _updateClock();
    });
  }

  void _updateClock() {
    if (!mounted) return;
    final now = DateTime.now();
    setState(() {
      _digitalTime = "${now.hour.toString().padLeft(2, '0')}:"
          "${now.minute.toString().padLeft(2, '0')}:"
          "${now.second.toString().padLeft(2, '0')}";
      _digitalDate = "${now.day.toString().padLeft(2, '0')}/"
          "${now.month.toString().padLeft(2, '0')}/${now.year}";
    });
  }

  void _startPingLoop() {
    _checkPing();
    _pingTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      _checkPing();
    });
  }

  Future<void> _checkPing() async {
    final start = DateTime.now();
    try {
      final res = await http
          .get(Uri.parse("$_apiBase/ping"))
          .timeout(const Duration(seconds: 3));
      final ms = DateTime.now().difference(start).inMilliseconds;
      if (!mounted) return;
      setState(() {
        _serverOnline = res.statusCode == 200;
        _pingMs = ms;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _serverOnline = false;
        _pingMs = 0;
      });
    }
  }

  Future<void> _fetchWeather() async {
    try {
      // Open-Meteo gratis tanpa API key, koordinat Jakarta
      final res = await http.get(Uri.parse(
        'https://api.open-meteo.com/v1/forecast?latitude=-6.2&longitude=106.8&current=temperature_2m,weather_code&timezone=Asia%2FJakarta',
      )).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        final cur = data['current'];
        final t = cur?['temperature_2m'];
        final code = cur?['weather_code'];
        if (!mounted) return;
        setState(() {
          _tempC = t == null ? "--" : "${(t as num).round()}";
          _weatherDesc = _weatherLabel(code is int ? code : 0);
          _weatherIcon = _weatherEmoji(code is int ? code : 0);
        });
      }
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _tempC = "--";
        _weatherDesc = "Offline";
        _weatherIcon = "☁️";
      });
    }
  }

  String _weatherLabel(int code) {
    if (code == 0) return "Cerah";
    if (code <= 3) return "Berawan";
    if (code <= 48) return "Berkabut";
    if (code <= 67) return "Hujan";
    if (code <= 77) return "Salju";
    if (code <= 82) return "Hujan Deras";
    return "Badai";
  }

  String _weatherEmoji(int code) {
    if (code == 0) return "☀️";
    if (code <= 3) return "⛅";
    if (code <= 48) return "🌫️";
    if (code <= 67) return "🌧️";
    if (code <= 77) return "❄️";
    if (code <= 82) return "🌧️";
    return "⛈️";
  }

  @override
  void dispose() {
    _clockTimer?.cancel();
    _pingTimer?.cancel();
    _weatherTimer?.cancel();
    _tutorialCtrl.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _goToLogin() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const LoginPage()),
    );
  }

  void _nextTutorial() {
    if (_tutorialIndex < _tutorialSlides.length - 1) {
      _tutorialCtrl.nextPage(
        duration: const Duration(milliseconds: 350),
        curve: Curves.easeOutCubic,
      );
    } else {
      setState(() => _showTutorial = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_showTutorial) {
      return _buildTutorialScreen();
    }
    return _buildLandingScreen();
  }

  // ═══════════════════════════════════════════════════════════
  // TUTORIAL SCREEN
  // ═══════════════════════════════════════════════════════════
  Widget _buildTutorialScreen() {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topCenter,
                radius: 1.5,
                colors: [
                  Color(0xFF0F2547),
                  Color(0xFF050B1A),
                  Color(0xFF000000),
                ],
                stops: [0.0, 0.5, 1.0],
              ),
            ),
          ),
          Positioned.fill(
            child: CustomPaint(
              painter: _LandingBubblePainter3D(
                color: accentColor.withOpacity(0.15),
                count: 22,
                animation: _animationController,
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                const SizedBox(height: 20),
                _buildAppNameBar(),
                const SizedBox(height: 24),
                Expanded(
                  child: PageView.builder(
                    controller: _tutorialCtrl,
                    itemCount: _tutorialSlides.length,
                    onPageChanged: (i) =>
                        setState(() => _tutorialIndex = i),
                    itemBuilder: (ctx, i) =>
                        _buildTutorialSlide(_tutorialSlides[i]),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(_tutorialSlides.length, (i) {
                    final active = i == _tutorialIndex;
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 250),
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      width: active ? 22 : 8,
                      height: 8,
                      decoration: BoxDecoration(
                        gradient: active
                            ? LinearGradient(
                                colors: [primaryColor, accentColor])
                            : null,
                        color: active ? null : Colors.white24,
                        borderRadius: BorderRadius.circular(4),
                        boxShadow: active
                            ? neonGlow(blur: 12, spread: 0.5, opacity: 0.6)
                            : null,
                      ),
                    );
                  }),
                ),
                const SizedBox(height: 18),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: _buildTutorialButton(),
                ),
                const SizedBox(height: 22),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTutorialSlide(Map<String, dynamic> slide) {
    final c = slide['color'] as Color;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 130,
            height: 130,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [c.withOpacity(0.25), c.withOpacity(0.05)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(32),
              border: Border.all(color: c.withOpacity(0.5), width: 2),
              boxShadow: neonGlow(
                  color: c, blur: 28, spread: 1, opacity: 0.55),
            ),
            child: Icon(slide['icon'] as IconData, color: c, size: 58),
          ),
          const SizedBox(height: 32),
          Text(
            (slide['title'] as String),
            style: TextStyle(
              color: c,
              fontSize: 13,
              fontWeight: FontWeight.w800,
              letterSpacing: 4,
            ),
          ),
          const SizedBox(height: 10),
          ShaderMask(
            shaderCallback: (b) => LinearGradient(
              colors: [Colors.white, accentColor, primaryColor],
            ).createShader(b),
            child: Text(
              (slide['subtitle'] as String),
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.2,
              ),
            ),
          ),
          const SizedBox(height: 18),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
            decoration: BoxDecoration(
              color: surfaceColor.withOpacity(0.7),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: c.withOpacity(0.35), width: 1.4),
              boxShadow: neonGlow(
                  color: c, blur: 16, spread: 0.5, opacity: 0.3),
            ),
            child: Text(
              (slide['desc'] as String),
              textAlign: TextAlign.center,
              style: TextStyle(
                color: textSecondary.withOpacity(0.9),
                fontSize: 13,
                height: 1.6,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTutorialButton() {
    final isLast = _tutorialIndex == _tutorialSlides.length - 1;
    return GestureDetector(
      onTap: _nextTutorial,
      child: Container(
        width: double.infinity,
        height: 48,
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFF00B0FF), Color(0xFF00E5FF)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withOpacity(0.25), width: 1),
          boxShadow: [
            ...neonGlow(color: accentColor, blur: 22, spread: 1, opacity: 0.6),
          ],
        ),
        child: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                isLast ? "MULAI SEKARANG" : "LANJUT",
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 3,
                ),
              ),
              const SizedBox(width: 10),
              Icon(
                isLast
                    ? Icons.check_circle_rounded
                    : Icons.arrow_forward_rounded,
                color: Colors.white,
                size: 18,
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ═══════════════════════════════════════════════════════════
  // LANDING SCREEN
  // ═══════════════════════════════════════════════════════════
  Widget _buildLandingScreen() {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                center: Alignment.topCenter,
                radius: 1.5,
                colors: [
                  Color(0xFF0F2547),
                  Color(0xFF050B1A),
                  Color(0xFF000000),
                ],
                stops: [0.0, 0.5, 1.0],
              ),
            ),
          ),

          Positioned.fill(
            child: CustomPaint(
              painter: _LandingBubblePainter3D(
                color: accentColor.withOpacity(0.15),
                count: 25,
                animation: _animationController,
              ),
            ),
          ),

          Positioned(
            top: -100,
            right: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    primaryColor.withOpacity(0.32),
                    Colors.transparent,
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: primaryColor.withOpacity(0.5),
                    blurRadius: 100,
                    spreadRadius: 50,
                  ),
                ],
              ),
            ),
          ),
          Positioned(
            bottom: -50,
            left: -80,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(
                  colors: [
                    accentColor.withOpacity(0.22),
                    Colors.transparent,
                  ],
                ),
                boxShadow: [
                  BoxShadow(
                    color: accentColor.withOpacity(0.3),
                    blurRadius: 80,
                    spreadRadius: 40,
                  ),
                ],
              ),
            ),
          ),

          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    children: [
                      const SizedBox(height: 12),
                      _buildAppNameBar(),
                      const SizedBox(height: 16),
                      _buildInfoBar(),
                      const SizedBox(height: 20),
                      _build3DBanner(),
                      const SizedBox(height: 20),
                      _build3DSocialMedia(),
                      const SizedBox(height: 24),
                      _build3DMainCard(),
                      const SizedBox(height: 20),
                      _build3DStats(),
                      const SizedBox(height: 24),
                      _build3DFooter(),
                      const SizedBox(height: 16),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── APP NAME BAR ────────────
  Widget _buildAppNameBar() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF001B3A),
            Color(0xFF003366),
            Color(0xFF001B3A),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(
          color: accentColor.withOpacity(0.7),
          width: 1.4,
        ),
        boxShadow: [
          BoxShadow(
            color: primaryColor.withOpacity(0.55),
            blurRadius: 22,
            spreadRadius: 1.5,
          ),
          BoxShadow(
            color: accentColor.withOpacity(0.35),
            blurRadius: 30,
            spreadRadius: 2,
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.2),
            blurRadius: 12,
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.green,
              boxShadow: [
                BoxShadow(
                  color: Colors.green.withOpacity(0.9),
                  blurRadius: 10,
                  spreadRadius: 2,
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.4),
                  blurRadius: 4,
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          ShaderMask(
            shaderCallback: (b) => const LinearGradient(
              colors: [
                Colors.white,
                Color(0xFF00E5FF),
                Color(0xFF00B0FF),
              ],
            ).createShader(b),
            child: const Text(
              "NEVERLOUS PROJECT ULTRA",
              style: TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w900,
                letterSpacing: 3,
                shadows: [
                  Shadow(blurRadius: 14, color: Color(0xFF00E5FF)),
                  Shadow(blurRadius: 6, color: Colors.white54),
                ],
              ),
            ),
          ),
          const SizedBox(width: 10),
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: accentColor.withOpacity(0.6),
              boxShadow: [
                BoxShadow(
                  color: accentColor.withOpacity(0.5),
                  blurRadius: 8,
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.25),
                  blurRadius: 4,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── INFO BAR: Jam + Server + Suhu (kubus) ─────────────────────────────
  Widget _buildInfoBar() {
    final pingColor = !_serverOnline
        ? Colors.redAccent
        : (_pingMs < 200
            ? Colors.greenAccent
            : (_pingMs < 500 ? Colors.amber : Colors.orangeAccent));

    return Row(
      children: [
        Expanded(
          child: _buildInfoCube(
            icon: Icons.access_time_rounded,
            iconColor: primaryColor,
            label: "JAM",
            value: _digitalTime,
            sub: _digitalDate,
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildInfoCube(
            icon: Icons.speed_rounded,
            iconColor: pingColor,
            label: "SERVER",
            value: _serverOnline ? "${_pingMs}ms" : "OFF",
            sub: _serverOnline ? "Online" : "Offline",
          ),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: _buildInfoCube(
            icon: Icons.cloud_rounded,
            iconColor: accentColor,
            label: "CUACA",
            value: "$_tempC°C",
            sub: "$_weatherIcon $_weatherDesc",
          ),
        ),
      ],
    );
  }

  // ═══════════════════════════════════════════════════════════════════════
  // ✅ FIX UTAMA: ganti Container(aspectRatio: 1.0) → AspectRatio widget
  // ═══════════════════════════════════════════════════════════════════════
  Widget _buildInfoCube({
    required IconData icon,
    required Color iconColor,
    required String label,
    required String value,
    required String sub,
  }) {
    return AspectRatio(
      aspectRatio: 1.0,
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              surfaceColor.withOpacity(0.9),
              cardColor.withOpacity(0.55),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: iconColor.withOpacity(0.6), width: 1.4),
          boxShadow: [
            ...neonGlow(color: iconColor, blur: 18, spread: 0.8, opacity: 0.5),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: iconColor.withOpacity(0.15),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: iconColor.withOpacity(0.4),
                      blurRadius: 10,
                    ),
                    BoxShadow(
                      color: Colors.white.withOpacity(0.15),
                      blurRadius: 5,
                    ),
                  ],
                ),
                child: Icon(icon, color: iconColor, size: 14),
              ),
              const SizedBox(height: 6),
              Text(
                label,
                style: TextStyle(
                  color: textSecondary.withOpacity(0.7),
                  fontSize: 7,
                  letterSpacing: 2,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 2),
              FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  value,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    fontFamily: 'monospace',
                    letterSpacing: 0.5,
                    shadows: [
                      Shadow(blurRadius: 10, color: Colors.white24),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 2),
              FittedBox(
                fit: BoxFit.scaleDown,
                child: Text(
                  sub,
                  style: TextStyle(
                    color: textSecondary.withOpacity(0.55),
                    fontSize: 7,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── BANNER 3D ──────────────────────────────────────────────────────────
  Widget _build3DBanner() {
    return AnimatedBuilder(
      animation: _rotateAnimation,
      builder: (context, child) {
        return Transform(
          transform: Matrix4.identity()
            ..setEntry(3, 2, 0.001)
            ..rotateX(_rotateAnimation.value * 0.3)
            ..rotateY(_rotateAnimation.value * 0.5),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Container(
                height: 190,
                margin: const EdgeInsets.only(top: 8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28),
                  boxShadow: [
                    BoxShadow(
                      color: primaryColor.withOpacity(0.7),
                      blurRadius: 40,
                      spreadRadius: 10,
                      offset: const Offset(0, 15),
                    ),
                    BoxShadow(
                      color: accentColor.withOpacity(0.4),
                      blurRadius: 60,
                      spreadRadius: 15,
                      offset: const Offset(0, 25),
                    ),
                    BoxShadow(
                      color: Colors.white.withOpacity(0.15),
                      blurRadius: 30,
                      spreadRadius: 5,
                    ),
                  ],
                ),
              ),
              ClipRRect(
                borderRadius: BorderRadius.circular(28),
                child: Image.network(
                  bannerUrl,
                  height: 180,
                  width: double.infinity,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    height: 180,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [primaryColor, accentColor],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(28),
                      boxShadow: neonGlow(opacity: 0.6),
                    ),
                    child: const Center(
                      child: Text(
                        "NEVERLOUS PROJECT",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 4,
                          shadows: [
                            Shadow(blurRadius: 20, color: Colors.black38),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Container(
                height: 180,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(28),
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withOpacity(0.15),
                      Colors.black.withOpacity(0.35),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 14,
                child: AnimatedBuilder(
                  animation: _pulseAnimation,
                  builder: (context, child) {
                    return Transform.scale(
                      scale: _pulseAnimation.value,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 28, vertical: 10),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(0.75),
                          borderRadius: BorderRadius.circular(24),
                          border: Border.all(
                            color: accentColor.withOpacity(0.5),
                            width: 1.5,
                          ),
                          boxShadow: [
                            ...neonGlow(
                                color: accentColor,
                                blur: 30,
                                spread: 5,
                                opacity: 0.6),
                            BoxShadow(
                              color: Colors.black.withOpacity(0.5),
                              blurRadius: 20,
                              spreadRadius: 2,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.green,
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.green.withOpacity(0.8),
                                    blurRadius: 12,
                                    spreadRadius: 2,
                                  ),
                                  BoxShadow(
                                    color: Colors.white.withOpacity(0.3),
                                    blurRadius: 6,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 10),
                            Text(
                              "NEVERLOUS PROJECT",
                              style: TextStyle(
                                color: accentColor,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 3,
                                shadows: [
                                  Shadow(
                                    color: accentColor.withOpacity(0.7),
                                    blurRadius: 15,
                                  ),
                                  const Shadow(
                                      color: Colors.white38, blurRadius: 6),
                                ],
                              ),
                            ),
                            const SizedBox(width: 10),
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: accentColor.withOpacity(0.4),
                                boxShadow: [
                                  BoxShadow(
                                    color: accentColor.withOpacity(0.3),
                                    blurRadius: 8,
                                  ),
                                  BoxShadow(
                                    color: Colors.white.withOpacity(0.2),
                                    blurRadius: 4,
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
              Positioned(
                top: 0,
                left: 20,
                right: 20,
                child: Container(
                  height: 3,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.transparent,
                        Colors.white.withOpacity(0.25),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  // ─── SOCIAL MEDIA 3D ────────────────────────────────────────────────────
  Widget _build3DSocialMedia() {
    final socials = [
      {
        'icon': FontAwesomeIcons.telegram,
        'label': 'Telegram',
        'url': 'https://t.me/resbobnich',
        'color': const Color(0xFF00B0FF)
      },
      {
        'icon': FontAwesomeIcons.whatsapp,
        'label': 'WhatsApp',
        'url': 'https://wa.me/6281929461098',
        'color': const Color(0xFF00E5FF)
      },
      {
        'icon': FontAwesomeIcons.instagram,
        'label': 'Instagram',
        'url': 'https://www.instagram.com/yawdwy',
        'color': const Color(0xFF4DD0E1)
      },
    ];

    return AnimatedBuilder(
      animation: _scaleAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: socials.map((s) {
              final c = s['color'] as Color;
              return GestureDetector(
                onTap: () => _openUrl(s['url'] as String),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.white.withOpacity(0.07),
                        Colors.white.withOpacity(0.02),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: c.withOpacity(0.45), width: 1.2),
                    boxShadow: [
                      BoxShadow(
                        color: c.withOpacity(0.3),
                        blurRadius: 15,
                        spreadRadius: 2,
                        offset: const Offset(0, 4),
                      ),
                      BoxShadow(
                        color: Colors.white.withOpacity(0.12),
                        blurRadius: 6,
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(s['icon'] as IconData, color: c, size: 16),
                      const SizedBox(width: 6),
                      Text(
                        s['label'] as String,
                        style: const TextStyle(
                          color: Colors.white70,
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        );
      },
    );
  }

  // ─── MAIN CARD 3D ──────────────────────────────────────────────────────
  Widget _build3DMainCard() {
    return AnimatedBuilder(
      animation: _rotateAnimation,
      builder: (context, child) {
        return Transform(
          transform: Matrix4.identity()
            ..setEntry(3, 2, 0.001)
            ..rotateX(_rotateAnimation.value * 0.1)
            ..rotateY(_rotateAnimation.value * 0.2),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  surfaceColor.withOpacity(0.85),
                  surfaceColor.withOpacity(0.45),
                ],
              ),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: accentColor.withOpacity(0.4),
                width: 1.5,
              ),
              boxShadow: [
                ...neonGlow(blur: 30, spread: 1, opacity: 0.4),
                BoxShadow(
                  color: Colors.black.withOpacity(0.6),
                  blurRadius: 40,
                  spreadRadius: 5,
                  offset: const Offset(0, 15),
                ),
              ],
            ),
            child: Stack(
              children: [
                Positioned(
                  top: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                    height: 60,
                    decoration: BoxDecoration(
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(28),
                      ),
                      gradient: LinearGradient(
                        colors: [
                          Colors.white.withOpacity(0.1),
                          Colors.transparent,
                        ],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  accentColor.withOpacity(0.25),
                                  accentColor.withOpacity(0.05),
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: accentColor.withOpacity(0.4),
                                width: 1.5,
                              ),
                              boxShadow: neonGlow(
                                  blur: 15, spread: 0.5, opacity: 0.5),
                            ),
                            child: Icon(
                              Icons.security_rounded,
                              color: accentColor,
                              size: 22,
                            ),
                          ),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 6),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [primaryColor, accentColor],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(16),
                              boxShadow: neonGlow(
                                  blur: 15, spread: 0.5, opacity: 0.6),
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.verified_rounded,
                                    color: Colors.white, size: 14),
                                SizedBox(width: 4),
                                Text(
                                  "VERIFIED",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 9,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          "TOP #1",
                          style: TextStyle(
                            color: accentColor.withOpacity(0.5),
                            fontSize: 9,
                            fontWeight: FontWeight.w700,
                            letterSpacing: 2,
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),
                      Text(
                        "Welcome to Controler App Center, NEVERLOUS PROJECT Is Your Best Choice To Control And Hack Someone's Mobile System Professionally",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white70,
                          fontSize: 13,
                          height: 1.7,
                          fontWeight: FontWeight.w400,
                          shadows: [
                            const Shadow(
                                blurRadius: 10, color: Colors.black26),
                            Shadow(
                              blurRadius: 6,
                              color: accentColor.withOpacity(0.2),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 18),
                      Row(
                        children: [
                          _build3DFeatureButton(
                            label: "STABLE",
                            color: primaryColor,
                            icon: Icons.shield_rounded,
                          ),
                          const SizedBox(width: 10),
                          _build3DFeatureButton(
                            label: "BUGS",
                            color: accentColor,
                            icon: Icons.bug_report_rounded,
                          ),
                          const SizedBox(width: 10),
                          _build3DFeatureButton(
                            label: "RAT",
                            color: const Color(0xFF80D8FF),
                            icon: Icons.computer_rounded,
                          ),
                        ],
                      ),
                      const SizedBox(height: 18),
                      Container(
                        height: 1,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.transparent,
                              accentColor.withOpacity(0.4),
                              Colors.transparent,
                            ],
                          ),
                          boxShadow:
                              neonGlow(blur: 8, spread: 0.3, opacity: 0.4),
                        ),
                      ),
                      const SizedBox(height: 18),
                      _build3DLoginButton(),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _build3DFeatureButton({
    required String label,
    required Color color,
    required IconData icon,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              color.withOpacity(0.25),
              color.withOpacity(0.05),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.5), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.3),
              blurRadius: 15,
              spreadRadius: 2,
              offset: const Offset(0, 4),
            ),
            BoxShadow(
              color: Colors.white.withOpacity(0.12),
              blurRadius: 6,
            ),
          ],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 16),
            const SizedBox(width: 8),
            Text(
              label,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.w700,
                letterSpacing: 0.5,
                shadows: [
                  Shadow(blurRadius: 8, color: Colors.black26),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _build3DLoginButton() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _pulseAnimation.value,
          child: SizedBox(
            width: double.infinity,
            height: 54,
            child: GestureDetector(
              onTap: _goToLogin,
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [primaryColor, accentColor, primaryColor],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(18),
                  boxShadow: [
                    BoxShadow(
                      color: primaryColor.withOpacity(0.7),
                      blurRadius: 30,
                      spreadRadius: 5,
                      offset: const Offset(0, 10),
                    ),
                    BoxShadow(
                      color: accentColor.withOpacity(0.4),
                      blurRadius: 50,
                      spreadRadius: 8,
                    ),
                    BoxShadow(
                      color: Colors.white.withOpacity(0.2),
                      blurRadius: 20,
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    Positioned(
                      top: 0,
                      left: 40,
                      right: 40,
                      child: Container(
                        height: 3,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.white.withOpacity(0.5),
                              Colors.white.withOpacity(0.05),
                            ],
                          ),
                        ),
                      ),
                    ),
                    const Center(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.login_rounded,
                            color: Colors.white,
                            size: 22,
                            shadows: [
                              Shadow(blurRadius: 12, color: Colors.black26),
                            ],
                          ),
                          SizedBox(width: 14),
                          Text(
                            "MASUK",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2.5,
                              shadows: [
                                Shadow(
                                    blurRadius: 12,
                                    color: Colors.black26),
                              ],
                            ),
                          ),
                          SizedBox(width: 14),
                          Icon(
                            Icons.arrow_forward_rounded,
                            color: Colors.white,
                            size: 20,
                            shadows: [
                              Shadow(blurRadius: 12, color: Colors.black26),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  // ─── STATS 3D ──────────────────────────────────────────────────────────
  Widget _build3DStats() {
    return AnimatedBuilder(
      animation: _scaleAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value,
          child: Row(
            children: [
              Expanded(
                child: _build3DStatsCard(
                  icon: Icons.people_alt_rounded,
                  iconColor: primaryColor,
                  value: "99+",
                  label: "User Aktif",
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: _build3DStatsCard(
                  icon: Icons.bug_report_rounded,
                  iconColor: accentColor,
                  value: "99+",
                  label: "Total Fitur",
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _build3DStatsCard({
    required IconData icon,
    required Color iconColor,
    required String value,
    required String label,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            surfaceColor.withOpacity(0.75),
            surfaceColor.withOpacity(0.35),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: iconColor.withOpacity(0.4), width: 1.2),
        boxShadow: [
          BoxShadow(
            color: iconColor.withOpacity(0.3),
            blurRadius: 25,
            spreadRadius: 3,
            offset: const Offset(0, 10),
          ),
          BoxShadow(
            color: Colors.white.withOpacity(0.12),
            blurRadius: 10,
          ),
          BoxShadow(
            color: Colors.black.withOpacity(0.4),
            blurRadius: 25,
            spreadRadius: 3,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  iconColor.withOpacity(0.25),
                  iconColor.withOpacity(0.05),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: iconColor.withOpacity(0.4), width: 1),
              boxShadow: [
                BoxShadow(
                  color: iconColor.withOpacity(0.3),
                  blurRadius: 12,
                ),
                BoxShadow(
                  color: Colors.white.withOpacity(0.12),
                  blurRadius: 6,
                ),
              ],
            ),
            child: Icon(icon, color: iconColor, size: 20),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    shadows: [
                      Shadow(
                        blurRadius: 12,
                        color: iconColor.withOpacity(0.4),
                      ),
                    ],
                  ),
                ),
                Text(
                  label,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.45),
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 0.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── FOOTER 3D ──────────────────────────────────────────────────────────
  Widget _build3DFooter() {
    return Column(
      children: [
        Container(
          width: 60,
          height: 3,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [primaryColor, accentColor],
            ),
            borderRadius: BorderRadius.circular(2),
            boxShadow: neonGlow(blur: 12, spread: 0.5, opacity: 0.6),
          ),
        ),
        const SizedBox(height: 14),
        Text(
          "© 2026 NEVERLOUS PROJECT ULTRA · All Rights Reserved",
          style: TextStyle(
            color: textSecondary.withOpacity(0.25),
            fontSize: 9,
            fontWeight: FontWeight.w600,
            letterSpacing: 1.5,
            shadows: [
              const Shadow(blurRadius: 10, color: Colors.black26),
              Shadow(
                blurRadius: 6,
                color: accentColor.withOpacity(0.15),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

// ─── 3D BUBBLE PAINTER ──────────────────────────────────────────────────
class _LandingBubblePainter3D extends CustomPainter {
  final Color color;
  final int count;
  final Animation<double> animation;

  _LandingBubblePainter3D({
    required this.color,
    required this.count,
    required this.animation,
  }) : super(repaint: animation);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.fill;

    final random = math.Random(42);
    final time = animation.value * 2 * math.pi;

    for (int i = 0; i < count; i++) {
      final baseX = (random.nextDouble() + i * 0.08) % 1.0;
      final baseY = (random.nextDouble() + i * 0.12) % 1.0;
      final radius = 12 + (random.nextDouble() + i * 0.015) % 35;

      final floatX = math.sin(time + i * 0.7) * 0.05;
      final floatY = math.cos(time * 0.6 + i * 0.5) * 0.05;

      final x = (baseX + floatX) * size.width;
      final y = (baseY + floatY) * size.height;

      final depth = 1.0 - (y / size.height) * 0.5;
      final opacity =
          (0.02 + (random.nextDouble() + i * 0.005) % 0.06) * depth;
      paint.color = color.withOpacity(opacity);

      final shadowPaint = Paint()
        ..color = Colors.black.withOpacity(0.03 * depth)
        ..style = PaintingStyle.fill;
      canvas.drawCircle(Offset(x + 4, y + 6), radius * 0.9, shadowPaint);

      canvas.drawCircle(Offset(x, y), radius, paint);

      final highlightPaint = Paint()
        ..color = Colors.white.withOpacity(
            (0.015 + (random.nextDouble() + i * 0.003) % 0.02) * depth)
        ..style = PaintingStyle.fill;

      canvas.drawCircle(
        Offset(x - radius * 0.3, y - radius * 0.35),
        radius * 0.2,
        highlightPaint,
      );

      final highlight2Paint = Paint()
        ..color = Colors.white.withOpacity(
            (0.005 + (random.nextDouble() + i * 0.002) % 0.01) * depth)
        ..style = PaintingStyle.fill;

      canvas.drawCircle(
        Offset(x - radius * 0.1, y - radius * 0.5),
        radius * 0.1,
        highlight2Paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _LandingBubblePainter3D oldDelegate) {
    return oldDelegate.animation != animation;
  }
}