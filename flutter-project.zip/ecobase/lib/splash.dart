import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';
import 'dashboard_page.dart';
import 'login_page.dart';

class SplashScreen extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String sessionKey;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;
  final List<dynamic> news;

  const SplashScreen({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.sessionKey,
    required this.expiredDate,
    required this.listBug,
    required this.news,
  });

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<double> _scaleAnimation;
  late Animation<Offset> _slideAnimation;

  late VideoPlayerController _videoController;
  bool _videoInitialized = false;
  bool _navigated = false;

  // Loading progress 0.0 → 1.0
  double _progress = 0.0;
  Timer? _progressTimer;
  int _progressPercent = 0;

  // ====== NEON BLUE LIGHT THEME (BLACK BASE) ======
  final Color primaryColor = const Color(0xFF00B0FF);
  final Color accentColor = const Color(0xFF00B0FF);
  final Color backgroundColor = const Color(0xFF000000);
  final Color surfaceColor = const Color(0xFF050B1A);
  final Color cardColor = const Color(0xFF0F2547);
  final Color textPrimary = Colors.white;
  final Color textSecondary = const Color(0xFFB3E5FC);

  // RGB gradient untuk progress bar
  static const List<Color> _rgbGradient = [
    Color(0xFFFF1744), // red
    Color(0xFFFF9100), // orange
    Color(0xFFFFEA00), // yellow
    Color(0xFF00E676), // green
    Color(0xFF00E5FF), // cyan
    Color(0xFF2979FF), // blue
    Color(0xFFD500F9), // magenta
  ];

  // White glow helper (dual shadow)
  List<BoxShadow> neonGlow({
    Color color = const Color(0xFF00B0FF),
    double blur = 16,
    double spread = 1.5,
    double opacity = 0.55,
  }) {
    return [
      BoxShadow(
        color: color.withOpacity(opacity),
        blurRadius: blur,
        spreadRadius: spread,
      ),
      BoxShadow(
        color: Colors.white.withOpacity(0.18),
        blurRadius: blur * 0.6,
        spreadRadius: 0.5,
      ),
    ];
  }

  @override
  void initState() {
    super.initState();

    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

    _initAnimations();
    _initVideo();
    _startProgress();
  }

  void _initAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.0, 0.6, curve: Curves.easeOut),
      ),
    );

    _scaleAnimation = Tween<double>(begin: 0.85, end: 1.0).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.0, 0.5, curve: Curves.easeOutBack),
      ),
    );

    _slideAnimation =
        Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: const Interval(0.3, 0.8, curve: Curves.easeOutCubic),
      ),
    );

    _animationController.forward();
  }

  void _initVideo() {
    _videoController =
        VideoPlayerController.asset('assets/videos/splash.mp4')
          ..initialize().then((_) {
            if (!mounted) return;
            setState(() => _videoInitialized = true);
            _videoController.setLooping(false);
            _videoController.setVolume(1.0);
            _videoController.play();
            _videoController.addListener(_onVideoListener);
          }).catchError((e) {
            debugPrint('Video error: $e');
            // fallback: auto lanjut setelah 6 detik
            Future.delayed(const Duration(seconds: 6), () => _goToDashboard());
          });
  }

  void _startProgress() {
    // Progress 0 → 100% dalam 8 detik (8000ms / 80 step)
    const totalMs = 8000;
    const stepMs = 80;
    const steps = totalMs ~/ stepMs; // 100 steps
    int count = 0;
    _progressTimer = Timer.periodic(const Duration(milliseconds: stepMs), (t) {
      if (!mounted) {
        t.cancel();
        return;
      }
      count++;
      setState(() {
        _progress = (count / steps).clamp(0.0, 1.0);
        _progressPercent = (_progress * 100).round();
      });
      if (count >= steps) {
        t.cancel();
      }
    });
  }

  void _onVideoListener() {
    if (!mounted || _navigated) return;
    final pos = _videoController.value.position;
    final dur = _videoController.value.duration;
    if (dur.inMilliseconds > 0 &&
        pos >= dur - const Duration(milliseconds: 200)) {
      _goToDashboard();
    }
  }

  void _goToDashboard() {
    if (_navigated || !mounted) return;
    _navigated = true;

    _progressTimer?.cancel();

    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);

    Navigator.pushReplacement(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 600),
        pageBuilder: (_, __, ___) => DashboardPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          listBug: widget.listBug,
          sessionKey: widget.sessionKey,
          news: widget.news,
        ),
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(opacity: animation, child: child);
        },
      ),
    );
  }

  void _redirectToLogin() async {
    if (!mounted) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('username');
    await prefs.remove('password');
    await prefs.remove('key');
    if (mounted) {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const LoginPage()),
      );
    }
  }

  @override
  void dispose() {
    _progressTimer?.cancel();
    _videoController.removeListener(_onVideoListener);
    _videoController.dispose();
    _animationController.dispose();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ══════════════════════════════════════════
          // 1. VIDEO FULL SCREEN
          // ══════════════════════════════════════════
          if (_videoInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              ),
            )
          else
            Container(
              color: backgroundColor,
              child: Center(
                child: CircularProgressIndicator(
                  color: accentColor,
                  strokeWidth: 2,
                ),
              ),
            ),

          // ══════════════════════════════════════════
          // 2. OVERLAY BIRU NEON GELAP (agar loading terbaca)
          // ══════════════════════════════════════════
          Container(
            color: const Color(0xFF001028).withOpacity(0.55),
          ),

          // ══════════════════════════════════════════
          // 3. BUTTON POJOK KIRI ATAS — Active
          // ══════════════════════════════════════════
          Positioned(
            top: MediaQuery.of(context).padding.top + 16,
            left: 16,
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: ScaleTransition(
                scale: _scaleAnimation,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: const Color(0xFF00E676).withOpacity(0.7),
                      width: 1.2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color(0xFF00E676).withOpacity(0.5),
                        blurRadius: 12,
                      ),
                      BoxShadow(
                        color: Colors.white.withOpacity(0.15),
                        blurRadius: 6,
                      ),
                    ],
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                          color: Color(0xFF00E676),
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: Color(0xFF00E676),
                              blurRadius: 6,
                            ),
                            BoxShadow(
                              color: Colors.white54,
                              blurRadius: 3,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 6),
                      const Text(
                        "Active",
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          color: Color(0xFF00E676),
                          letterSpacing: 0.4,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // ══════════════════════════════════════════
          // 4. BUTTON POJOK KANAN ATAS — Skip
          // ══════════════════════════════════════════
          Positioned(
            top: MediaQuery.of(context).padding.top + 16,
            right: 16,
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: ScaleTransition(
                scale: _scaleAnimation,
                child: GestureDetector(
                  onTap: _goToDashboard,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 7),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: accentColor.withOpacity(0.5),
                        width: 1,
                      ),
                      boxShadow: neonGlow(
                          blur: 10, spread: 0.5, opacity: 0.45),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Text(
                          "Skip",
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                            letterSpacing: 0.4,
                          ),
                        ),
                        const SizedBox(width: 5),
                        Icon(
                          Icons.skip_next_rounded,
                          size: 14,
                          color: accentColor,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

          // ══════════════════════════════════════════
          // 5. BANNER INFORMATION + PROGRESS + TOMBOL LANJUTKAN
          // ══════════════════════════════════════════
          Positioned(
            bottom: 24,
            left: 20,
            right: 20,
            child: SlideTransition(
              position: _slideAnimation,
              child: FadeTransition(
                opacity: _fadeAnimation,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 18, vertical: 16),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.75),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(
                      color: accentColor.withOpacity(0.55),
                      width: 1.2,
                    ),
                    boxShadow: neonGlow(
                        blur: 20, spread: 1, opacity: 0.5),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Label header
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 5),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [primaryColor, accentColor],
                              ),
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: neonGlow(
                                  blur: 12, spread: 0.5, opacity: 0.6),
                            ),
                            child: const Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  Icons.info_outline_rounded,
                                  color: Colors.white,
                                  size: 13,
                                ),
                                SizedBox(width: 6),
                                Text(
                                  "INFORMATION",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 11,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 1.5,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 12),

                      Container(
                        height: 1,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.transparent,
                              accentColor.withOpacity(0.6),
                              Colors.transparent,
                            ],
                          ),
                        ),
                      ),

                      const SizedBox(height: 12),

                      Text(
                        "Gunakan APK dengan bijak tanpa melanggar hukum.",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.95),
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          letterSpacing: 0.3,
                          height: 1.5,
                        ),
                      ),

                      const SizedBox(height: 6),

                      Text(
                        "APK ini dibuat hanya untuk memberantas penipuan.",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: accentColor.withOpacity(0.9),
                          fontSize: 11,
                          fontWeight: FontWeight.w500,
                          letterSpacing: 0.2,
                          height: 1.5,
                        ),
                      ),

                      const SizedBox(height: 14),

                      // ══════════ RGB PROGRESS BAR ══════════
                      Row(
                        children: [
                          Expanded(
                            child: Stack(
                              children: [
                                // Track (background) dengan glow putih tipis
                                Container(
                                  height: 8,
                                  decoration: BoxDecoration(
                                    color: cardColor,
                                    borderRadius: BorderRadius.circular(6),
                                    border: Border.all(
                                      color: primaryColor.withOpacity(0.4),
                                      width: 0.8,
                                    ),
                                    boxShadow: [
                                      BoxShadow(
                                        color:
                                            primaryColor.withOpacity(0.3),
                                        blurRadius: 8,
                                      ),
                                      BoxShadow(
                                        color: Colors.white
                                            .withOpacity(0.1),
                                        blurRadius: 4,
                                      ),
                                    ],
                                  ),
                                ),
                                // Fill RGB gradient
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(6),
                                  child: ShaderMask(
                                    shaderCallback: (rect) {
                                      return const LinearGradient(
                                        colors: _rgbGradient,
                                        begin: Alignment.centerLeft,
                                        end: Alignment.centerRight,
                                      ).createShader(rect);
                                    },
                                    blendMode: BlendMode.srcIn,
                                    child: Container(
                                      height: 8,
                                      width: MediaQuery.of(context)
                                              .size
                                              .width *
                                          _progress,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(6),
                                        boxShadow: [
                                          BoxShadow(
                                            color: accentColor
                                                .withOpacity(0.7),
                                            blurRadius: 10,
                                            spreadRadius: 0.5,
                                          ),
                                          BoxShadow(
                                            color: Colors.white
                                                .withOpacity(0.3),
                                            blurRadius: 5,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 12),
                          // Persentase
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: cardColor,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: primaryColor.withOpacity(0.5),
                              ),
                              boxShadow: neonGlow(
                                  blur: 8, spread: 0.3, opacity: 0.4),
                            ),
                            child: Text(
                              "$_progressPercent%",
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'monospace',
                                letterSpacing: 0.5,
                              ),
                            ),
                          ),
                        ],
                      ),

                      const SizedBox(height: 14),

                      // ══════════ TOMBOL LANJUTKAN ══════════
                      GestureDetector(
                        onTap: _goToDashboard,
                        child: Container(
                          width: double.infinity,
                          height: 46,
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [
                                Color(0xFF00B0FF),
                                Color(0xFF00E5FF),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(14),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.25),
                              width: 1,
                            ),
                            boxShadow: neonGlow(
                                color: accentColor,
                                blur: 22,
                                spread: 1,
                                opacity: 0.6),
                          ),
                          child: const Center(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "LANJUTKAN",
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 13,
                                    fontWeight: FontWeight.w900,
                                    letterSpacing: 3,
                                  ),
                                ),
                                SizedBox(width: 10),
                                Icon(
                                  Icons.arrow_forward_rounded,
                                  color: Colors.white,
                                  size: 18,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}