# ASISTEN YUZI BOT - Setup Guide

## ⚙️ LANGKAH 1 - Setup Bot Telegram

1. Buka [@BotFather](https://t.me/BotFather) di Telegram
2. Kirim `/newbot` dan ikuti instruksi
3. Salin **BOT_TOKEN** yang diberikan
4. Cari tau **OWNER_ID** kamu:
   - Buka [@userinfobot](https://t.me/userinfobot) di Telegram
   - Kirim sembarang pesan, nanti diberikan ID kamu

---

## ⚙️ LANGKAH 2 - Isi config.js

Edit file `config.js`:

```js
module.exports = {
    BOT_TOKEN: '1234567890:AAGxxxxxxxxxxxxx',  // Token dari BotFather
    OWNER_ID: 987654321,                        // Telegram ID kamu (angka)
    OWNER_USERNAME: 'namauser',                // Username tanpa @
    
    WELCOME_MEDIA: '',         // Bisa diisi via Panel Owner di bot
    WELCOME_MEDIA_TYPE: '',    // 'photo' / 'video' / 'audio'
    
    DAILY_LIMIT: 3,            // Limit penggunaan per fitur per hari
    
    GITHUB_TOKEN: 'ghp_xxxxxxxxxxxxxxxxxxx',  // Token GitHub kamu
    GITHUB_OWNER: 'username_github',
    GITHUB_REPO: 'nama_repo',
    GITHUB_BRANCH: 'main',
    GITHUB_WORKFLOW: 'flutter_build.yml',
};
```

> ℹ️ Konfigurasi **database GitHub** (`GITHUB_DB_CONFIG`) TIDAK ada di `config.js` — sengaja diletakkan di `index.js` (lihat LANGKAH 3.5), supaya ikut tersembunyi saat `index.js` di-encrypt/obfuscate.

---

## ⚙️ LANGKAH 3 - Setup GitHub untuk Build Flutter

### 3a. Buat Repository GitHub Baru
1. Buka [github.com/new](https://github.com/new)
2. Nama repo bebas (contoh: `flutter-build-bot`)
3. Set **Private** atau Public (bebas)
4. Centang **Add a README file**
5. Klik **Create repository**

### 3b. Upload Workflow File
1. Di repo GitHub, buka folder `.github/workflows/` (buat jika belum ada)
2. Upload file `flutter_build.yml` ke folder tersebut
3. Atau buat file baru di `.github/workflows/flutter_build.yml` dan paste isi file workflow

### 3c. Buat GitHub Personal Access Token
1. Buka [github.com/settings/tokens](https://github.com/settings/tokens)
2. Klik **Generate new token (classic)**
3. Centang permission:
   - ✅ `repo` (full control)
   - ✅ `workflow`
4. Klik **Generate token**
5. Salin token (format: `ghp_xxxxxxxxxx`) - **SIMPAN, tidak bisa dilihat lagi!**

### 3d. Buat Folder Uploads di Repo
1. Di repo, buat file kosong: `uploads/.gitkeep`
   - Ini dibutuhkan agar folder `uploads/` ada di repo
   - Bot akan upload ZIP ke sini sebelum build

---

## ☁️ LANGKAH 3.5 - Setup Database via GitHub (Permanen)

Database bot (`database.json`, `jobs.json`, `limits.json`, `credits.json`) sekarang **otomatis disinkronkan ke GitHub**, supaya data (whitelist, kredit, limit harian, job build) **tidak hilang** walau hosting/VPS kamu restart atau redeploy.

### Cara kerja
- Saat bot start, index.js menarik (pull) data terbaru dari `raw.githubusercontent.com` ke file lokal.
- Setiap kali ada perubahan data (kredit ditambah, user baru, job build, dll), bot otomatis push (upload) ke repo GitHub via Contents API.
- Kalau GitHub sedang tidak bisa dihubungi, bot **tetap jalan** memakai data lokal (tidak crash).

### Konfigurasi di `index.js`
Cari konstanta `GITHUB_DB_CONFIG` di bagian paling atas `index.js` (sengaja diletakkan di sini, bukan di `config.js`, supaya ikut tersembunyi saat `index.js` di-encrypt/obfuscate):
```js
const GITHUB_DB_CONFIG = {
    owner: 'username_github',   // boleh sama dengan GITHUB_OWNER di config.js
    repo: 'nama_repo',          // boleh sama/beda dengan GITHUB_REPO di config.js
    branch: 'main',
    path: 'database',           // folder di repo untuk simpan file json
    // token: 'ghp_xxxx',        // opsional, token khusus DB. Kosongkan untuk pakai GITHUB_TOKEN dari config.js
};
```

### Yang perlu disiapkan
- Token (`GITHUB_TOKEN` di `config.js`, atau `token` khusus di `GITHUB_DB_CONFIG`) harus punya permission **repo** (read & write contents) ke repo `owner/repo` yang diisi di `GITHUB_DB_CONFIG`.
- Tidak perlu membuat file `database.json` dkk secara manual — bot otomatis membuatnya di folder `database/` pada repo saat pertama kali ada perubahan data.

> ⚠️ Karena `database.json` & `credits.json` berisi data user, sebaiknya gunakan **repo Private** untuk menyimpan database.

---

## 🛡️ SISTEM INTEGRITY CHECK (Anti File Hilang)

`index.js` sekarang menjadi **pusat kontrol** seluruh file project (lihat `utils/integrity.js`).

- **Saat start**: index.js mengecek semua file wajib (`utils/`, `handlers/`, `menus/`, `config.js`, dll). Kalau ada **satu file saja** yang hilang/terhapus, bot **langsung berhenti total** (tidak akan jalan sama sekali) dan menampilkan daftar file yang hilang di log.
- **Saat runtime**: setiap 30 detik, index.js mengecek ulang. Kalau ada file yang terhapus **saat bot sedang berjalan**, bot otomatis mati total (error total) — semua fitur ikut berhenti karena pusatnya (index.js) berhenti.

Untuk menambah/mengurangi file yang dianggap "wajib", edit array `REQUIRED_FILES` di `utils/integrity.js`.

---

## ⚙️ LANGKAH 4 - Jalankan Bot

### Install Node.js (minimal v18)
```bash
node -v  # Cek versi, harus >= 18
```

### Install Dependensi
```bash
npm install
```

### Jalankan Bot
```bash
npm start
# atau
node index.js
```

### Jalankan di Background (Linux/VPS)
```bash
# Pakai PM2
npm install -g pm2
pm2 start index.js --name "asisten-zyaple"
pm2 save
pm2 startup
```

---

## 🎨 LANGKAH 5 - Set Foto/Video/Audio Menu (Opsional)

1. Buka bot di Telegram
2. Kirim `/start`
3. Tekan **⚙️ Panel Owner** (hanya muncul untuk Owner)
4. Pilih:
   - **🖼️ Set Foto Sambutan** — kirim foto
   - **🎬 Set Video Sambutan** — kirim video
   - **🎵 Set Audio Sambutan** — kirim file MP3/audio
5. Setelah itu, setiap orang buka `/start` akan melihat foto/video/audio tersebut

---

## 📋 FITUR BOT

| Fitur | Fungsi |
|-------|--------|
| 🔄 Rename Domain | Ganti domain di seluruh file .dart/.js/.json dalam ZIP |
| 🎨 Recolour | Ganti warna HEX di file .dart project Flutter |
| 🔧 Manage Functions | Ganti fungsi/kode di file .js/.dart dalam ZIP |
| 🗜️ Compress Base | Hapus file build artifact & kompres project |
| 🏗️ Build Flutter | Build APK release via GitHub Actions |
| 🚀 Deploy | Deploy project static/web ke Vercel atau Netlify |

---

## 🚀 DEPLOY (VERCEL & NETLIFY)

Fitur ini mengizinkan user mendeploy project static/web (HTML/CSS/JS atau hasil build seperti folder `dist`/`build`) langsung ke **Vercel** atau **Netlify**, memakai token milik Owner yang sudah dikonfigurasi.

### Setup token
Buka `config.js`, isi bagian:

```js
VERCEL_TOKEN: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxx',   // dari https://vercel.com/account/tokens
VERCEL_TEAM_ID: '',                              // opsional, isi kalau deploy ke Team/Org Vercel
NETLIFY_TOKEN: 'xxxxxxxxxxxxxxxxxxxxxxxxxxxx',  // dari https://app.netlify.com/user/applications
```

### Cara pakai (sisi user)
1. Tekan tombol **🚀 Deploy (Vercel/Netlify)** di menu utama.
2. Pilih platform: **Vercel** atau **Netlify**.
3. Kirim file `.zip` project static/web (pastikan ada `index.html`, baik di root ZIP maupun di dalam 1 folder pembungkus — bot otomatis mendeteksi & menyesuaikan).
4. Bot otomatis upload & deploy, lalu mengirimkan **URL live** hasil deploy.

### Catatan & limit
- Maks ukuran ZIP **±2GB** dan **±1500 file** per project (batas aman untuk deploy langsung lewat API tanpa Git).
- File/folder seperti `node_modules/`, `.git/`, `__MACOSX/` otomatis di-skip.
- Vercel: deploy dibuat dengan `target: production`. Kalau `VERCEL_TEAM_ID` diisi, project dibuat di Team/Org tersebut.
- Netlify: setiap deploy membuat **site baru** (nama otomatis dibuat unik per user).
- Kalau token belum diisi, bot akan membalas error yang menjelaskan token mana yang kurang.

---

## ⚠️ NOTES PENTING

- Pastikan `GITHUB_TOKEN` punya permission `repo` dan `workflow`
- File workflow **harus ada** di `.github/workflows/flutter_build.yml` di repo
- Folder `uploads/` **harus ada** di repo (buat file `.gitkeep` di dalamnya)
- Build bisa memakan waktu **5-15 menit** tergantung ukuran project
- Simpan **Job ID** yang diberikan bot untuk ambil APK nanti
- APK artifact tersedia selama **3 hari** setelah build

---

## 🛠️ TROUBLESHOOTING

**Bot tidak merespons?**
→ Cek BOT_TOKEN di config.js sudah benar

**Build gagal "Upload GitHub gagal"?**
→ Cek GITHUB_TOKEN punya permission `repo`
→ Cek nama GITHUB_OWNER, GITHUB_REPO, GITHUB_BRANCH sudah benar

**Build gagal di GitHub Actions?**
→ Buka tab Actions di repo GitHub kamu untuk lihat error detail
→ Pastikan project Flutter valid dan punya `pubspec.yaml`

**Artifact tidak ditemukan?**
→ Build mungkin masih berjalan, cek status dulu
→ Artifact expired setelah 3 hari
