const AdmZip = require('adm-zip');
const { sendDocumentSmart } = require('../utils/gramjs');

async function handleFunctionsProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, isFinal = false) {
    if (!isFinal) {
        // Step 1: Terima ZIP
        const doc = ctx.message.document;
        if (!doc.file_name?.endsWith('.zip')) {
            return ctx.reply(`<blockquote>❌ File harus berupa <b>.zip</b>!</blockquote>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } });
        }
        const waitMsg = await ctx.reply(`<blockquote>⏳ Mengunduh file...</blockquote>`, { parse_mode: 'HTML' });
        let buffer;
        try {
            buffer = await downloadTelegramFile(ctx, doc.file_id);
        } catch (e) {
            await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                `<blockquote>❌ ${e.message}</blockquote>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } }).catch(() => {});
            return;
        }
        await ctx.telegram.deleteMessage(waitMsg.chat.id, waitMsg.message_id).catch(() => {});
        userState[ctx.from.id] = { step: 'WAIT_FUNC_OLD', zipBuffer: buffer };
        return ctx.reply(
            `<blockquote>✅ <b>File diterima!</b>\n\nKirimkan <b>nama fungsi LAMA</b> atau kode yang ingin diganti.\nContoh: <code>oldFunction</code> atau <code>http://old-api.com</code></blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } }
        );
    }
    
    // Step 2: Proses functions
    const { oldFunc, zipBuffer } = state;
    const newFunc = ctx.message.text.trim();
    delete userState[ctx.from.id];

    if (!canUse(ctx.from.id, 'functions')) {
        return ctx.reply(`<blockquote>⚠️ <b>Kredit kamu habis!</b>\n\nHubungi owner untuk mendapatkan kredit tambahan.</blockquote>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } });
    }

    const procMsg = await ctx.reply(`<blockquote>⏳ <b>Memproses manage functions...</b></blockquote>`, { parse_mode: 'HTML' });

    try {
        const zip = new AdmZip(zipBuffer);
        const outZip = new AdmZip();
        let count = 0;

        for (const entry of zip.getEntries()) {
            if (entry.isDirectory) { outZip.addFile(entry.entryName, Buffer.alloc(0)); continue; }
            let content = entry.getData();
            const name = entry.entryName.toLowerCase();
            if (name.endsWith('.js') || name.endsWith('.ts') || name.endsWith('.json') || name.endsWith('.dart')) {
                const text = content.toString('utf8');
                if (text.includes(oldFunc)) {
                    content = Buffer.from(text.replaceAll(oldFunc, newFunc), 'utf8');
                    count++;
                }
            }
            outZip.addFile(entry.entryName, content);
        }

        spendCredit(ctx.from.id);
        addLimit(ctx.from.id, 'functions');
        await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});
        await sendDocumentSmart(
            ctx, outZip.toBuffer(), `modified_functions_${Date.now()}.zip`,
            { caption: `<blockquote>✅ <b>Manage Functions Selesai!</b>\n\n🔧 Lama: <code>${oldFunc}</code>\n✅ Baru: <code>${newFunc}</code>\n📁 File diubah: <b>${count}</b>\n\n💎 Sisa kredit: <b>${getRemaining(ctx.from.id)}</b></blockquote>`,
              parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'main_menu', style: 'primary' }]] }
            }
        );
    } catch (e) {
        await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});
        await ctx.reply(`<blockquote>❌ <b>Gagal:</b> ${e.message}</blockquote>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } });
    }
}

module.exports = { handleFunctionsProcess };