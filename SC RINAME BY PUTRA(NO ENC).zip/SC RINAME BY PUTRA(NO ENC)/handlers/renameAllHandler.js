// ============================================================
// RENAME ALL HANDLER
// Alur: ZIP → domain baru → domain lama
//       → 1 gambar untuk semua asset gambar (opsional/skip)
//       → 1 video untuk semua asset video (opsional/skip)
//       → nama app baru → nama app lama → PROSES
//
// Logika penggantian asset:
// • 1 file gambar dikirim → ganti SEMUA gambar di assets/ & ic_launcher* (nama file dipertahankan)
// • 1 file video dikirim → ganti SEMUA video di assets/ (nama file dipertahankan)
// ============================================================
const AdmZip = require('adm-zip');
const path   = require('path');
const { sendDocumentSmart } = require('../utils/gramjs');

const TEXT_EXTS  = ['.dart','.js','.json','.yaml','.yml','.xml','.gradle','.properties','.txt','.kt','.swift','.html','.ts','.plist','.env'];
const IMAGE_EXTS = ['.png','.jpg','.jpeg','.webp','.bmp','.gif'];
const VIDEO_EXTS = ['.mp4','.webm','.mov','.avi','.mkv','.m4v'];

function isAssetImage(e) {
    const base  = path.basename(e);
    const lower = e.toLowerCase();
    const ext   = path.extname(base).toLowerCase();
    if (!IMAGE_EXTS.includes(ext)) return false;
    return (
        lower.includes('/assets/') || lower.startsWith('assets/') ||
        (lower.includes('mipmap') && (base.startsWith('ic_launcher') || base.startsWith('ic_background') || base.startsWith('ic_foreground'))) ||
        lower.includes('appicon.appiconset') ||
        (lower.includes('/icons/') && base.startsWith('Icon-')) ||
        base === 'favicon.png' ||
        lower.includes('splash') || lower.includes('launch_background')
    );
}

function isAssetVideo(e) {
    const lower = e.toLowerCase();
    const ext   = path.extname(e).toLowerCase();
    if (!VIDEO_EXTS.includes(ext)) return false;
    return lower.includes('/assets/') || lower.startsWith('assets/');
}

function countAssets(zipBuffer) {
    const zip = new AdmZip(zipBuffer);
    let imgs = 0, vids = 0;
    const iconFormats = {};
    for (const entry of zip.getEntries()) {
        if (entry.isDirectory) continue;
        if (isAssetImage(entry.entryName)) imgs++;
        if (isAssetVideo(entry.entryName)) vids++;
        // Deteksi format ic_launcher
        const base = path.basename(entry.entryName).toLowerCase();
        if (entry.entryName.toLowerCase().includes('mipmap') && base.startsWith('ic_launcher')) {
            const ext = path.extname(base).replace('.', '').toLowerCase();
            if (ext) iconFormats[ext] = (iconFormats[ext] || 0) + 1;
        }
    }
    // Format icon paling dominan
    const sortedFmt = Object.entries(iconFormats).sort((a, b) => b[1] - a[1]);
    const iconFormat = sortedFmt.length > 0 ? sortedFmt[0][0] : 'png';
    return { imgs, vids, iconFormat };
}

// ============================================================
async function handleRenameAllProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining) {
    const userId = ctx.from.id;

    // ── STEP 0: Terima ZIP ─────────────────────────────────
    if (state.step === 'WAIT_RENAMEALL_ZIP') {
        const doc = ctx.message.document;
        if (!doc?.file_name?.endsWith('.zip')) {
            return ctx.reply(`<blockquote>❌ File harus berupa <b>.zip</b>!</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } });
        }
        const waitMsg = await ctx.reply(`<blockquote>⏳ Mengunduh & scan project...</blockquote>`, { parse_mode: 'HTML' });
        let buffer;
        try { buffer = await downloadTelegramFile(ctx, doc.file_id); }
        catch (e) {
            await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                `<blockquote>❌ Gagal download: ${e.message}</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } }).catch(() => {});
            return;
        }
        await ctx.telegram.deleteMessage(waitMsg.chat.id, waitMsg.message_id).catch(() => {});

        const { imgs, vids, iconFormat } = countAssets(buffer);
        userState[userId] = { step: 'WAIT_RENAMEALL_NEW_DOMAIN', zipBuffer: buffer, hasImgs: imgs > 0, hasVids: vids > 0, iconFormat };

        const assetInfo = [];
        if (imgs > 0) assetInfo.push(`🖼 <b>${imgs}</b> gambar/icon (assets + ic_launcher)`);
        if (vids > 0) assetInfo.push(`🎬 <b>${vids}</b> video`);
        const assetLine = assetInfo.length ? assetInfo.join('\n') : '📭 Tidak ada asset gambar/video';

        return ctx.reply(
            `<blockquote>✅ <b>Project diterima!</b>\n\n📦 <b>Asset ditemukan:</b>\n${assetLine}\n\n<b>Step 1 — Domain Baru</b>\nKirim domain baru (dengan port jika ada).\nContoh: <code>api.brand.com:8080</code>\n\n⏭ Ketik <code>skip</code> untuk lewati.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } }
        );
    }

    // ── STEP 1: Domain baru ────────────────────────────────
    if (state.step === 'WAIT_RENAMEALL_NEW_DOMAIN') {
        const text = ctx.message.text?.trim();
        if (!text) return;
        const skip = text.toLowerCase() === 'skip';
        userState[userId] = { ...state, step: 'WAIT_RENAMEALL_OLD_DOMAIN', newDomain: skip ? null : text };
        if (skip) {
            return ctx.reply(`<blockquote>⏭ Domain dilewati.\n\n<b>Step 2 — Domain Lama</b>\nKetik domain lama, atau <code>skip</code> lagi.</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } });
        }
        return ctx.reply(
            `<blockquote>✅ Domain baru: <code>${text}</code>\n\n<b>Step 2 — Domain Lama</b>\nKirim domain lama yang mau diganti.\nContoh: <code>api.old.com:3000</code></blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } }
        );
    }

    // ── STEP 2: Domain lama → lanjut ke gambar / video / nama app
    if (state.step === 'WAIT_RENAMEALL_OLD_DOMAIN') {
        const text = ctx.message.text?.trim();
        if (!text) return;
        const skip = text.toLowerCase() === 'skip';
        const oldDomain = (skip || !state.newDomain) ? null : text;
        const nextState = { ...state, oldDomain };

        if (state.hasImgs) {
            userState[userId] = { ...nextState, step: 'WAIT_RENAMEALL_IMG' };
            return ctx.reply(
                `<blockquote>${oldDomain ? `✅ Domain lama: <code>${oldDomain}</code>\n\n` : ''}<b>Step 3 — Gambar / Icon</b>\n\n🔍 <b>Format icon terdeteksi:</b> <code>${(state.iconFormat || 'png').toUpperCase()}</code>\n\nKirim <b>1 file gambar</b> dalam format <b>${(state.iconFormat || 'png').toUpperCase()}</b> sebagai <b>Dokumen/File</b>.\n\nBot otomatis mengganti:\n• Semua gambar di folder <code>assets/</code>\n• Semua <code>ic_launcher</code> (Android, iOS, Web) — format dipertahankan\n\n⚠️ Nama file asli dipertahankan, hanya kontennya diganti.\n⏭ Ketik <code>skip</code> atau tekan tombol untuk lewati.</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [
                    [{ text: '⏭ Skip Ganti Gambar', callback_data: 'renameall_skip_img', style: 'primary' }],
                    [{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }],
                ]} }
            );
        }
        if (state.hasVids) {
            userState[userId] = { ...nextState, step: 'WAIT_RENAMEALL_VID', imgBuffer: null };
            return promptVideo(ctx);
        }
        userState[userId] = { ...nextState, step: 'WAIT_RENAMEALL_NEW_APPNAME', imgBuffer: null, vidBuffer: null };
        return promptAppName(ctx);
    }

    // ── STEP 3: Terima 1 gambar (ganti semua image asset) ──
    if (state.step === 'WAIT_RENAMEALL_IMG') {
        if (ctx.message.text?.trim().toLowerCase() === 'skip') {
            return afterImg(ctx, state, userState, userId, null);
        }
        const photo = ctx.message.photo;
        const doc   = ctx.message.document;
        const isImgDoc = doc && (doc.mime_type?.startsWith('image/') ||
            IMAGE_EXTS.includes(path.extname(doc.file_name || '').toLowerCase()));

        if (!photo && !isImgDoc) {
            return ctx.reply(`<blockquote>⚠️ Kirim <b>file gambar</b> (PNG/JPG/dll) atau ketik <code>skip</code>.</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [
                    [{ text: '⏭ Skip Ganti Gambar', callback_data: 'renameall_skip_img', style: 'primary' }],
                    [{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }],
                ]} });
        }

        const waitMsg = await ctx.reply(`<blockquote>⏳ Mengunduh gambar...</blockquote>`, { parse_mode: 'HTML' });
        let buf;
        try {
            const fileId = photo ? photo[photo.length - 1].file_id : doc.file_id;
            buf = await downloadTelegramFile(ctx, fileId);
        } catch (e) {
            await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                `<blockquote>❌ Gagal download: ${e.message}</blockquote>`, { parse_mode: 'HTML' }).catch(() => {});
            return;
        }
        await ctx.telegram.deleteMessage(waitMsg.chat.id, waitMsg.message_id).catch(() => {});
        return afterImg(ctx, state, userState, userId, buf);
    }

    // ── STEP 4: Terima 1 video (ganti semua video asset) ───
    if (state.step === 'WAIT_RENAMEALL_VID') {
        if (ctx.message.text?.trim().toLowerCase() === 'skip') {
            return afterVid(ctx, state, userState, userId, null);
        }
        const vid   = ctx.message.video;
        const doc   = ctx.message.document;
        const isVidDoc = doc && (doc.mime_type?.startsWith('video/') ||
            VIDEO_EXTS.includes(path.extname(doc.file_name || '').toLowerCase()));

        if (!vid && !isVidDoc) {
            return ctx.reply(`<blockquote>⚠️ Kirim <b>file video</b> (MP4/dll) sebagai dokumen, atau ketik <code>skip</code>.</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [
                    [{ text: '⏭ Skip Ganti Video', callback_data: 'renameall_skip_vid', style: 'primary' }],
                    [{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }],
                ]} });
        }
        const waitMsg = await ctx.reply(`<blockquote>⏳ Mengunduh video...</blockquote>`, { parse_mode: 'HTML' });
        let buf;
        try {
            buf = await downloadTelegramFile(ctx, (vid || doc).file_id);
        } catch (e) {
            await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                `<blockquote>❌ Gagal download: ${e.message}</blockquote>`, { parse_mode: 'HTML' }).catch(() => {});
            return;
        }
        await ctx.telegram.deleteMessage(waitMsg.chat.id, waitMsg.message_id).catch(() => {});
        return afterVid(ctx, state, userState, userId, buf);
    }

    // ── STEP 5: Nama app baru ──────────────────────────────
    if (state.step === 'WAIT_RENAMEALL_NEW_APPNAME') {
        const text = ctx.message.text?.trim();
        if (!text) return;
        const skip = text.toLowerCase() === 'skip';
        if (skip) return executeRenameAll(ctx, { ...state, newAppName: null, oldAppName: null }, userState, canUse, spendCredit, addLimit, getRemaining);
        userState[userId] = { ...state, step: 'WAIT_RENAMEALL_OLD_APPNAME', newAppName: text };
        return ctx.reply(
            `<blockquote>✅ Nama baru: <code>${text}</code>\n\n<b>Nama App Lama</b>\nKirim nama aplikasi lama yang mau diganti.\nContoh: <code>MyApp</code>\n\n⏭ Ketik <code>skip</code> untuk lewati.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } }
        );
    }

    // ── STEP 6: Nama app lama → EKSEKUSI ──────────────────
    if (state.step === 'WAIT_RENAMEALL_OLD_APPNAME') {
        const text = ctx.message.text?.trim();
        if (!text) return;
        const skip = text.toLowerCase() === 'skip';
        return executeRenameAll(ctx, { ...state, oldAppName: skip ? null : text }, userState, canUse, spendCredit, addLimit, getRemaining);
    }
}

// ── Setelah gambar diterima/skip → lanjut ke video atau nama app
async function afterImg(ctx, state, userState, userId, imgBuffer) {
    if (state.hasVids) {
        userState[userId] = { ...state, step: 'WAIT_RENAMEALL_VID', imgBuffer };
        return promptVideo(ctx);
    }
    userState[userId] = { ...state, step: 'WAIT_RENAMEALL_NEW_APPNAME', imgBuffer, vidBuffer: null };
    return promptAppName(ctx);
}

// ── Setelah video diterima/skip → lanjut ke nama app
async function afterVid(ctx, state, userState, userId, vidBuffer) {
    userState[userId] = { ...state, step: 'WAIT_RENAMEALL_NEW_APPNAME', vidBuffer };
    return promptAppName(ctx);
}

async function promptVideo(ctx) {
    return ctx.reply(
        `<blockquote><b>Step — Video</b>\n\nKirim <b>1 file video</b> sebagai dokumen (MP4/dll).\n\nBot otomatis mengganti semua video di folder <code>assets/</code> — nama file asli dipertahankan.\n\n⏭ Ketik <code>skip</code> atau tekan tombol untuk lewati.</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [
            [{ text: '⏭ Skip Ganti Video', callback_data: 'renameall_skip_vid', style: 'primary' }],
            [{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }],
        ]} }
    );
}

async function promptAppName(ctx) {
    return ctx.reply(
        `<blockquote><b>Step — Nama App</b>\n\nKirim <b>nama aplikasi baru</b>.\nContoh: <code>Super Brand App</code>\n\n⏭ Ketik <code>skip</code> untuk lewati.</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } }
    );
}

// ── Eksekusi semua proses rename ───────────────────────────
async function executeRenameAll(ctx, state, userState, canUse, spendCredit, addLimit, getRemaining) {
    const userId = ctx.from.id;
    delete userState[userId];

    if (!canUse(userId, 'renameall')) {
        return ctx.reply(`<blockquote>⚠️ <b>Kredit kamu habis!</b>\n\nHubungi owner untuk mendapatkan kredit tambahan.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } });
    }

    const { zipBuffer, newDomain, oldDomain, imgBuffer, vidBuffer, newAppName, oldAppName } = state;

    const procMsg = await ctx.reply(
        `<blockquote>⚙️ <b>RENAME ALL — MEMPROSES...</b>\n\n${oldDomain && newDomain ? `🌐 Domain: <code>${oldDomain}</code> → <code>${newDomain}</code>` : '🌐 Domain: dilewati'}\n${imgBuffer ? '🖼 Gambar/icon: akan diganti' : '🖼 Gambar: dilewati'}\n${vidBuffer ? '🎬 Video: akan diganti' : '🎬 Video: dilewati'}\n${oldAppName && newAppName ? `📱 Nama: <code>${oldAppName}</code> → <code>${newAppName}</code>` : '📱 Nama App: dilewati'}\n\n⏳ Mohon tunggu...</blockquote>`,
        { parse_mode: 'HTML' }
    );

    try {
        const zip    = new AdmZip(zipBuffer);
        const outZip = new AdmZip();
        let domainCount = 0, imgCount = 0, vidCount = 0, appCount = 0;

        for (const entry of zip.getEntries()) {
            if (entry.isDirectory) { outZip.addFile(entry.entryName, Buffer.alloc(0)); continue; }

            let content     = entry.getData();
            const entryName = entry.entryName;
            const ext       = path.extname(entryName).toLowerCase();

            // 1️⃣ Ganti semua gambar & icon dengan 1 file gambar
            if (imgBuffer && isAssetImage(entryName)) {
                // Nama file dipertahankan (entryName sama), konten diganti
                outZip.addFile(entryName, imgBuffer);
                imgCount++;
                continue;
            }

            // 2️⃣ Ganti semua video dengan 1 file video
            if (vidBuffer && isAssetVideo(entryName)) {
                outZip.addFile(entryName, vidBuffer);
                vidCount++;
                continue;
            }

            // 3️⃣ Ganti domain & nama app di file teks
            if (TEXT_EXTS.includes(ext)) {
                let text    = content.toString('utf8');
                let changed = false;
                if (oldDomain && newDomain && text.includes(oldDomain)) {
                    text = text.replaceAll(oldDomain, newDomain);
                    domainCount++;
                    changed = true;
                }
                if (oldAppName && newAppName && text.includes(oldAppName)) {
                    text = text.replaceAll(oldAppName, newAppName);
                    appCount++;
                    changed = true;
                }
                if (changed) content = Buffer.from(text, 'utf8');
            }

            outZip.addFile(entryName, content);
        }

        spendCredit(userId);
        addLimit(userId, 'renameall');
        await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});

        const summary = [
            oldDomain && newDomain ? `🌐 Domain diganti di <b>${domainCount}</b> file` : '🌐 Domain: dilewati',
            imgBuffer ? `🖼 Gambar/Icon diganti: <b>${imgCount}</b> file` : '🖼 Gambar: dilewati',
            vidBuffer ? `🎬 Video diganti: <b>${vidCount}</b> file` : '🎬 Video: dilewati',
            oldAppName && newAppName ? `📱 Nama app diganti di <b>${appCount}</b> file` : '📱 Nama App: dilewati',
        ].join('\n');

        // Nama file output otomatis — prioritas: nama app baru > domain baru > timestamp
        const safeName = (str) => str ? str.replace(/[^a-zA-Z0-9_\-]/g, '_').replace(/_+/g, '_').slice(0, 40) : null;
        const autoLabel = safeName(newAppName) || safeName(newDomain) || Date.now().toString();
        const outputFilename = `renameall_${autoLabel}.zip`;

        await sendDocumentSmart(
            ctx, outZip.toBuffer(), outputFilename,
            { caption: `<blockquote>✅ <b>RENAME ALL SELESAI!</b>\n\n${summary}\n\n💎 Sisa kredit: <b>${getRemaining(userId)}</b></blockquote>`,
              parse_mode: 'HTML',
              reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'main_menu', style: 'primary' }]] } }
        );
    } catch (e) {
        await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});
        await ctx.reply(`<blockquote>❌ <b>Rename All Gagal:</b> ${e.message}</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } });
    }
}

module.exports = { handleRenameAllProcess };
