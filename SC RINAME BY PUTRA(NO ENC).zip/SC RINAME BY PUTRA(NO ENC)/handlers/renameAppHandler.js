const AdmZip = require('adm-zip');
const { sendDocumentSmart } = require('../utils/gramjs');

async function handleRenameAppProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, isFinal = false) {
    if (!isFinal) {
        // Step 1: Terima ZIP
        const doc = ctx.message.document;
        if (!doc.file_name?.endsWith('.zip')) {
            return ctx.reply(`<blockquote>❌ File harus berupa <b>.zip</b> project Flutter!</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } });
        }
        const waitMsg = await ctx.reply(`<blockquote>⏳ Mengunduh file...</blockquote>`, { parse_mode: 'HTML' });
        let buffer;
        try {
            buffer = await downloadTelegramFile(ctx, doc.file_id);
        } catch (e) {
            await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                `<blockquote>❌ ${e.message}</blockquote>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } }).catch(() => {});
            return;
        }
        await ctx.telegram.deleteMessage(waitMsg.chat.id, waitMsg.message_id).catch(() => {});
        userState[ctx.from.id] = { step: 'WAIT_APP_OLD_NAME', zipBuffer: buffer };
        return ctx.reply(
            `<blockquote>✅ <b>File diterima!</b>\n\nKirimkan <b>nama aplikasi LAMA</b> yang ingin diganti.\nContoh: <code>MyApp</code> atau <code>Flutter Demo</code></blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } }
        );
    }

    // Step 2: Proses rename nama app
    const { oldAppName, zipBuffer } = state;
    const newAppName = ctx.message.text.trim();
    delete userState[ctx.from.id];

    if (!canUse(ctx.from.id, 'renameapp')) {
        return ctx.reply(`<blockquote>⚠️ <b>Kredit kamu habis!</b>\n\nHubungi owner untuk mendapatkan kredit tambahan.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } });
    }

    const procMsg = await ctx.reply(`<blockquote>⏳ <b>Mengganti nama aplikasi...</b></blockquote>`, { parse_mode: 'HTML' });

    try {
        const zip = new AdmZip(zipBuffer);
        const outZip = new AdmZip();
        let count = 0;

        // File yang perlu diubah untuk rename app name di Flutter
        const targetFiles = [
            'pubspec.yaml',
            'android/app/src/main/AndroidManifest.xml',
            'android/app/src/main/res/values/strings.xml',
            'ios/Runner/Info.plist',
            'lib/main.dart',
        ];

        for (const entry of zip.getEntries()) {
            if (entry.isDirectory) { outZip.addFile(entry.entryName, Buffer.alloc(0)); continue; }
            let content = entry.getData();
            const name = entry.entryName;

            // Cek apakah file ini target atau mengandung nama lama
            const isText = name.endsWith('.dart') || name.endsWith('.yaml') || name.endsWith('.yml') ||
                           name.endsWith('.xml') || name.endsWith('.plist') || name.endsWith('.json') ||
                           name.endsWith('.gradle') || name.endsWith('.kt') || name.endsWith('.swift') ||
                           name.endsWith('.html') || name.endsWith('.js') || name.endsWith('.ts');

            if (isText) {
                const text = content.toString('utf8');
                if (text.includes(oldAppName)) {
                    content = Buffer.from(text.replaceAll(oldAppName, newAppName), 'utf8');
                    count++;
                }
            }
            outZip.addFile(name, content);
        }

        spendCredit(ctx.from.id);
        addLimit(ctx.from.id, 'renameapp');
        await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});
        await sendDocumentSmart(
            ctx, outZip.toBuffer(), `renamed_app_${Date.now()}.zip`,
            {
                caption: `<blockquote>✅ <b>Rename Nama App Selesai!</b>\n\n📱 Lama: <code>${oldAppName}</code>\n✅ Baru: <code>${newAppName}</code>\n📁 File diubah: <b>${count}</b>\n\n💎 Sisa kredit: <b>${getRemaining(ctx.from.id)}</b></blockquote>`,
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'main_menu', style: 'primary' }]] }
            }
        );
    } catch (e) {
        await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});
        await ctx.reply(`<blockquote>❌ <b>Gagal:</b> ${e.message}</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } });
    }
}

module.exports = { handleRenameAppProcess };
