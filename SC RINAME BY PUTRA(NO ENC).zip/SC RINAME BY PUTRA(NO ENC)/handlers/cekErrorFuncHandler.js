// ============================================================
// CEK ERROR FUNC HANDLER
// User kirim teks code func langsung → analisis error + deteksi AI
// ============================================================

// ─── DETEKSI KODE BUATAN AI ───────────────────────────────
function detectAiGenerated(code) {
    let score = 0;
    const signals = [];

    // Pola komentar khas AI
    const aiCommentPatterns = [
        /\/\/\s*(TODO|FIXME|NOTE|HINT|Step \d+|This function|Helper function|Main function|Utility|Example usage)/i,
        /\/\/\s*(Handle|Process|Check|Validate|Initialize|Setup|Configure)\s+\w+/i,
        /\/\*\*[\s\S]*?@param[\s\S]*?\*\//,  // JSDoc lengkap (AI sering generate ini)
    ];
    for (const pat of aiCommentPatterns) {
        if (pat.test(code)) { score += 2; signals.push('Komentar khas AI ditemukan'); break; }
    }

    // Nama variabel generik khas AI
    const genericNames = /\b(result|data|response|output|input|value|item|element|temp|tmp|helper|util|payload|callback|handler|obj|arr|str|num)\b/g;
    const genericMatches = (code.match(genericNames) || []).length;
    if (genericMatches >= 4) { score += 2; signals.push(`Banyak nama variabel generik (${genericMatches}x)`); }

    // Struktur terlalu rapi: try-catch di semua async + error.message
    if (/try\s*\{[\s\S]*?catch\s*\(e\)\s*\{[\s\S]*?e\.message/i.test(code)) {
        score += 2; signals.push('Pola try-catch dengan e.message sangat khas AI');
    }

    // Console.log dengan string template literal berlebihan
    const templateLogs = (code.match(/console\.(log|error)\(`[^`]{10,}`\)/g) || []).length;
    if (templateLogs >= 2) { score += 1; signals.push(`Console log dengan template literal (${templateLogs}x)`); }

    // Arrow function + async berlebihan (AI suka semua jadi async arrow)
    const asyncArrows = (code.match(/=\s*async\s*\([^)]*\)\s*=>/g) || []).length;
    if (asyncArrows >= 3) { score += 2; signals.push(`Banyak async arrow function (${asyncArrows}x)`); }

    // Komentar per baris (AI suka jelasin tiap baris)
    const lines = code.split('\n').filter(l => l.trim());
    const commentLines = lines.filter(l => l.trim().startsWith('//'));
    const commentRatio = commentLines.length / lines.length;
    if (commentRatio > 0.3) { score += 2; signals.push(`Rasio komentar tinggi (${Math.round(commentRatio * 100)}% baris = komentar)`); }

    // Return object literal langsung (AI suka)
    if (/return\s*\{[\s\S]{5,200}\};/.test(code)) { score += 1; signals.push('Return object literal langsung'); }

    // Destrukturisasi parameter berlebihan
    const destructParams = (code.match(/function\s*\w*\s*\(\s*\{[^}]+\}/g) || []).length;
    if (destructParams >= 2) { score += 1; signals.push(`Destrukturisasi parameter (${destructParams}x)`); }

    const isAi = score >= 5;
    return { isAi, score, signals };
}

// ─── ANALISIS ERROR FUNC ──────────────────────────────────
function analyzeFunc(code) {
    const lines = code.split('\n');
    const errors = [];
    const warnings = [];

    // Bracket balance global
    const openBrace = (code.match(/\{/g) || []).length;
    const closeBrace = (code.match(/\}/g) || []).length;
    if (openBrace !== closeBrace) {
        errors.push(`❌ Bracket { } tidak seimbang — buka: ${openBrace}, tutup: ${closeBrace}. Cek penutup fungsi di akhir kode.`);
    }

    const openParen = (code.match(/\(/g) || []).length;
    const closeParen = (code.match(/\)/g) || []).length;
    if (openParen !== closeParen) {
        errors.push(`❌ Kurung ( ) tidak seimbang — buka: ${openParen}, tutup: ${closeParen}. Kemungkinan ada pemanggilan fungsi yang tidak ditutup.`);
    }

    // Deteksi fungsi yang dideklarasikan
    const declaredFuncs = new Map();
    const funcPatterns = [
        /(?:^|\s)function\s+(\w+)\s*\(/gm,
        /(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?\([^)]*\)\s*=>/gm,
        /(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s*)?function/gm,
        /(?:^|\s)async\s+function\s+(\w+)\s*\(/gm,
    ];
    for (const pat of funcPatterns) {
        pat.lastIndex = 0;
        let m;
        while ((m = pat.exec(code)) !== null) {
            const name = m[1];
            if (!name || name.length < 2) continue;
            const ln = code.substring(0, m.index).split('\n').length;
            if (declaredFuncs.has(name)) {
                errors.push(`❌ Fungsi duplikat: \`${name}\` dideklarasikan 2x (pertama di baris ${declaredFuncs.get(name)}, lagi di baris ${ln}). Hapus salah satunya.`);
            } else {
                declaredFuncs.set(name, ln);
            }
        }
    }

    // Cek baris per baris
    lines.forEach((line, i) => {
        const ln = i + 1;
        const t = line.trim();
        if (!t || t.startsWith('//') || t.startsWith('*') || t.startsWith('/*')) return;

        // Syntax: tanda kutip tidak ditutup
        const singleQ = (t.match(/(?<!\\)'/g) || []).length;
        const doubleQ = (t.match(/(?<!\\)"/g) || []).length;
        if (singleQ % 2 !== 0) {
            errors.push(`❌ Baris ${ln}: Tanda kutip tunggal (') tidak ditutup → \`${t.substring(0, 60)}\``);
        }
        if (doubleQ % 2 !== 0) {
            errors.push(`❌ Baris ${ln}: Tanda kutip ganda (") tidak ditutup → \`${t.substring(0, 60)}\``);
        }

        // Async tanpa await di dalamnya (terlalu dangkal, skip)

        // Pakai == bukan ===
        if (/[^=!<>]={2}[^=]/.test(t) && !/['"`]/.test(t.substring(0, t.search(/={2}/)))) {
            warnings.push(`⚠️ Baris ${ln}: Pakai \`==\` bukan \`===\` → \`${t.substring(0, 60)}\` (bisa bug type coercion)`);
        }

        // var masih dipakai
        if (/^\s*var\s+/.test(line)) {
            warnings.push(`⚠️ Baris ${ln}: Masih pakai \`var\` → ganti ke \`const\` atau \`let\``);
        }

        // console.log tertinggal
        if (/console\.(log|warn|debug)\s*\(/.test(t)) {
            warnings.push(`⚠️ Baris ${ln}: \`console.log\` tertinggal → sebaiknya dihapus di production`);
        }

        // Empty catch
        if (/catch\s*\([^)]*\)\s*\{\s*\}/.test(t)) {
            errors.push(`❌ Baris ${ln}: Empty catch block → error ditelan diam-diam, tambahkan penanganan error`);
        }

        // Return di luar fungsi (sangat dasar)
        // Skip: terlalu banyak false positive

        // Semicolon hilang di akhir statement sederhana
        if (
            /^(const|let|var|return|throw)\s+/.test(t) &&
            !t.endsWith('{') && !t.endsWith(',') && !t.endsWith(';') &&
            !t.endsWith('(') && !t.endsWith(')')  && !t.includes('=>')
        ) {
            warnings.push(`⚠️ Baris ${ln}: Mungkin kurang titik koma (;) → \`${t.substring(0, 60)}\``);
        }

        // Undefined reference sederhana: fungsi dipanggil tapi tidak dideklarasikan di scope
        // Skip: butuh full parser, terlalu banyak FP

        // Async function tanpa try/catch
        if (/async\s+function\s+\w+|=\s*async\s*\(|=\s*async\s+function/.test(t)) {
            const block = lines.slice(i, Math.min(i + 20, lines.length)).join('\n');
            if (!block.includes('try') && !block.includes('.catch(')) {
                warnings.push(`⚠️ Baris ${ln}: Fungsi async tanpa try/catch → error tidak tertangkap jika promise reject`);
            }
        }
    });

    return { errors, warnings, totalFuncs: declaredFuncs.size };
}

// ─── HANDLER UTAMA ────────────────────────────────────────
async function handleCekErrorFuncProcess(ctx, state, userState) {
    const code = ctx.message.text?.trim();
    if (!code || code.length < 10) {
        return ctx.reply(
            `<blockquote>❌ Kirimkan kode fungsi JavaScript yang ingin dicek.\n\nContoh: langsung paste kode function kamu di sini.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } }
        );
    }

    delete userState[ctx.from.id];
    const waitMsg = await ctx.reply(`<blockquote>🔍 Menganalisis kode...</blockquote>`, { parse_mode: 'HTML' });

    try {
        const { errors, warnings, totalFuncs } = analyzeFunc(code);
        const { isAi, score, signals } = detectAiGenerated(code);

        let reply = `<blockquote>🛠 <b>HASIL CEK ERROR FUNC</b>\n\n`;

        // Deteksi AI
        if (isAi) {
            reply += `🤖 <b>KODE INI TERDETEKSI BUATAN AI</b>\n`;
            reply += `📊 Skor AI: <b>${score}/10</b>\n`;
            reply += `📌 Indikator:\n`;
            for (const s of signals) reply += `  • ${s}\n`;
            reply += `\n`;
        }

        reply += `📁 Fungsi ditemukan: <b>${totalFuncs}</b>\n`;
        reply += `❌ Error: <b>${errors.length}</b> | ⚠️ Warning: <b>${warnings.length}</b>\n\n`;

        if (errors.length === 0 && warnings.length === 0) {
            reply += `✅ Tidak ada error atau warning ditemukan!`;
        } else {
            if (errors.length > 0) {
                reply += `<b>— ERROR —</b>\n`;
                for (const e of errors.slice(0, 15)) reply += `${e}\n\n`;
                if (errors.length > 15) reply += `<i>...dan ${errors.length - 15} error lainnya (dipotong)</i>\n\n`;
            }
            if (warnings.length > 0) {
                reply += `<b>— WARNING —</b>\n`;
                for (const w of warnings.slice(0, 15)) reply += `${w}\n\n`;
                if (warnings.length > 15) reply += `<i>...dan ${warnings.length - 15} warning lainnya (dipotong)</i>\n\n`;
            }
        }

        reply += `</blockquote>`;

        // Jaga-jaga kalau masih kepanjangan (limit Telegram ~4096 char)
        if (reply.length > 4000) {
            reply = reply.slice(0, 3950) + '\n\n<i>...(dipotong karena terlalu panjang)</i></blockquote>';
        }

        await ctx.telegram.deleteMessage(waitMsg.chat.id, waitMsg.message_id).catch(() => {});
        await ctx.reply(reply, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'main_menu', style: 'primary' }]] }
        });
    } catch (e) {
        await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
            `<blockquote>❌ Gagal analisis: ${e.message}</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } }
        ).catch(() => {});
    }
}

module.exports = { handleCekErrorFuncProcess };
