const AdmZip = require('adm-zip');
const { sendDocumentSmart } = require('../utils/gramjs');

async function handleCompressProcess(ctx, state, userState, downloadTelegramFile) {
    const doc = ctx.message.document;
    if (!doc.file_name?.endsWith('.zip')) {
        return ctx.reply(`<blockquote>❌ File harus berupa <b>.zip</b>!</blockquote>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } });
    }
    delete userState[ctx.from.id];

    const procMsg = await ctx.reply(`<blockquote>⏳ <b>Memproses compress...</b>\n\n🗜 Menghapus file tidak perlu dan mengkompres project...</blockquote>`, { parse_mode: 'HTML' });

    try {
        const buffer = await downloadTelegramFile(ctx, doc.file_id);
        const zip = new AdmZip(buffer);
        const outZip = new AdmZip();

        const SKIP_PATTERNS = [
            /^(.*\/)?build\//,
            /^(.*\/)?\\.dart_tool\//,
            /^(.*\/)?\\.gradle\//,
            /^(.*\/)?\\.idea\//,
            /^(.*\/)?\\.vs\//,
            /^(.*\/)?\\.vscode\//,
            /^(.*\/)?\\.flutter-plugins/,
            /^(.*\/)?\\.flutter-plugins-dependencies/,
            /^(.*\/)?\\.packages/,
            /^(.*\/)?pubspec\.lock/,
            /^(.*\/)?__MACOSX\//,
            /^(.*\/)?\\.DS_Store/,
            /^(.*\/)?Thumbs\.db/,
            /^(.*\/)?node_modules\//,
            /\.class$/,
            /\.dex$/,
            /\.ap_$/,
        ];

        let removed = 0, kept = 0;
        for (const entry of zip.getEntries()) {
            const name = entry.entryName;
            const skip = SKIP_PATTERNS.some(p => p.test(name));
            if (skip) { removed++; continue; }
            if (entry.isDirectory) { outZip.addFile(name, Buffer.alloc(0)); continue; }
            outZip.addFile(name, entry.getData());
            kept++;
        }

        await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});
        const outBuffer = outZip.toBuffer();
        const origSize = (buffer.length / 1024).toFixed(1);
        const newSize = (outBuffer.length / 1024).toFixed(1);
        const saved = ((1 - outBuffer.length / buffer.length) * 100).toFixed(1);

        await sendDocumentSmart(
            ctx, outBuffer, `compressed_${Date.now()}.zip`,
            { caption: `<blockquote>✅ <b>Compress Selesai!</b>\n\n📦 Ukuran asli: <b>${origSize} KB</b>\n📦 Ukuran baru: <b>${newSize} KB</b>\n💾 Hemat: <b>${saved}%</b>\n\n🗑️ File dihapus: <b>${removed}</b>\n✅ File disimpan: <b>${kept}</b></blockquote>`,
              parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'main_menu', style: 'primary' }]] }
            }
        );
    } catch (e) {
        await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});
        await ctx.reply(`<blockquote>❌ <b>Gagal:</b> ${e.message}</blockquote>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } });
    }
}

module.exports = { handleCompressProcess };