const { deployToVercel, deployToNetlify } = require('../utils/deploy');

async function handleDeployProcess(ctx, state, userState, downloadTelegramFile) {
    const target = state.target; // 'vercel' | 'netlify'
    const platformLabel = target === 'vercel' ? 'Vercel' : 'Netlify';

    const doc = ctx.message.document;
    if (!doc.file_name?.endsWith('.zip')) {
        return ctx.reply(
            `<blockquote>❌ File harus berupa <b>.zip</b>!\n\nKirimkan ZIP berisi project static/web kamu (HTML/CSS/JS, atau hasil build seperti folder <code>dist</code>/<code>build</code>).</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_deploy', style: 'danger' }]] } }
        );
    }
    delete userState[ctx.from.id];

    const waitMsg = await ctx.reply(
        `<blockquote>⏳ <b>Memproses deploy ke ${platformLabel}...</b>\n\n⬇️ Mengunduh ZIP dari Telegram, lalu upload ke ${platformLabel}.\nMohon tunggu, proses ini bisa memakan waktu beberapa puluh detik.</blockquote>`,
        { parse_mode: 'HTML' }
    );

    // Fire-and-forget: jangan await supaya tidak kena timeout 90 detik Telegraf
    (async () => {
        try {
            const buffer = await downloadTelegramFile(ctx, doc.file_id);
            const projectName = `tg-${ctx.from.id}-${Date.now().toString(36)}`;

            await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                `<blockquote>⬆️ <b>Mengupload & deploy ke ${platformLabel}...</b>\n\n⏳ Mohon tunggu, jangan kirim file lain dulu.</blockquote>`,
                { parse_mode: 'HTML' }).catch(() => {});

            let result;
            if (target === 'vercel') {
                result = await deployToVercel(buffer, projectName);
            } else {
                result = await deployToNetlify(buffer, projectName);
            }

            const liveUrl = result.url?.startsWith('http') ? result.url : `https://${result.url}`;

            let extra = '';
            if (result.id) extra += `🆔 ID: <code>${result.id}</code>\n`;
            if (result.state) extra += `📊 Status: <b>${result.state}</b>\n`;
            if (result.adminUrl) extra += `⚙️ Admin: ${result.adminUrl}\n`;
            if (result.inspectorUrl) extra += `🔎 Inspector: ${result.inspectorUrl}\n`;

            const buttons = [
                [{ text: '🌐 Buka Situs', url: liveUrl }],
            ];
            if (result.adminUrl) buttons.push([{ text: '⚙️ Buka Admin Panel', url: result.adminUrl }]);
            if (result.inspectorUrl) buttons.push([{ text: '🔎 Buka Inspector', url: result.inspectorUrl }]);
            buttons.push([{ text: '🚀 Deploy Lagi', callback_data: 'menu_deploy', style: 'primary' }, { text: '🏠 Menu Utama', callback_data: 'main_menu', style: 'primary' }]);

            await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                `<blockquote>✅ <b>DEPLOY KE ${platformLabel.toUpperCase()} BERHASIL!</b>\n\n🌐 URL: ${liveUrl}\n${extra}\n⏳ <i>Catatan: deploy mungkin masih proses build di sisi ${platformLabel}, tunggu 1-2 menit kalau situs belum bisa diakses.</i></blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: buttons } }
            ).catch(() => {});
        } catch (e) {
            await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                `<blockquote>❌ <b>Gagal deploy ke ${platformLabel}:</b>\n${e.message}</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🔄 Coba Lagi', callback_data: 'menu_deploy', style: 'primary' }, { text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } }
            ).catch(() => {});
        }
    })();
}

module.exports = { handleDeployProcess };
