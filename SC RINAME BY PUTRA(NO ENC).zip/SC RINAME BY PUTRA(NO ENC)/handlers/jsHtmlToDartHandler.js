const AdmZip = require('adm-zip');
const { sendDocumentSmart } = require('../utils/gramjs');

// Konversi sederhana JS/HTML ke Dart
function convertJsToDart(jsCode) {
    let dart = jsCode;

    // Komentar
    dart = dart.replace(/\/\/ /g, '// ');

    // var/let/const → var (Dart pakai var atau tipe)
    dart = dart.replace(/\bconst\s+(\w+)\s*=/g, 'final $1 =');
    dart = dart.replace(/\blet\s+(\w+)\s*=/g, 'var $1 =');

    // console.log → print
    dart = dart.replace(/console\.log\(/g, 'print(');

    // function declaration
    dart = dart.replace(/function\s+(\w+)\s*\(([^)]*)\)\s*\{/g, 'void $1($2) {');

    // Arrow functions sederhana
    dart = dart.replace(/const\s+(\w+)\s*=\s*\(([^)]*)\)\s*=>\s*\{/g, 'void $1($2) {');
    dart = dart.replace(/const\s+(\w+)\s*=\s*\(([^)]*)\)\s*=>/g, 'var $1 = ($2) =>');

    // === → ==
    dart = dart.replace(/===/g, '==');
    dart = dart.replace(/!==/g, '!=');

    // null → null (sama)
    // undefined → null
    dart = dart.replace(/\bundefined\b/g, 'null');

    // true/false sama

    // String template literals `...${x}...` → '...$x...'
    dart = dart.replace(/`([^`]*)`/g, (match, inner) => {
        const converted = inner.replace(/\$\{([^}]+)\}/g, '\$$1');
        return `'${converted}'`;
    });

    // typeof → (tidak ada di Dart, hapus/ganti komentar)
    dart = dart.replace(/typeof\s+(\w+)\s*===?\s*'(\w+)'/g, '/* typeof $1 == "$2" */');

    // Array methods
    dart = dart.replace(/\.forEach\(/g, '.forEach(');
    dart = dart.replace(/\.map\(/g, '.map(');
    dart = dart.replace(/\.filter\(/g, '.where(');
    dart = dart.replace(/\.length/g, '.length');
    dart = dart.replace(/\.push\(/g, '.add(');

    // import/require → import
    dart = dart.replace(/const\s+\{([^}]+)\}\s*=\s*require\(['"]([^'"]+)['"]\);/g, "import '$2.dart';");
    dart = dart.replace(/const\s+(\w+)\s*=\s*require\(['"]([^'"]+)['"]\);/g, "import '$2.dart';");
    dart = dart.replace(/import\s+\{([^}]+)\}\s+from\s+['"]([^'"]+)['"];/g, "import '$2.dart';");

    // module.exports → (hapus)
    dart = dart.replace(/module\.exports\s*=\s*\{([^}]+)\};?/g, '// Exports: $1');
    dart = dart.replace(/module\.exports\s*=\s*\w+;?/g, '');

    // async/await → async/await (Dart juga punya, tapi return type Future)
    dart = dart.replace(/async\s+function\s+(\w+)\s*\(([^)]*)\)\s*\{/g, 'Future<void> $1($2) async {');

    // parseInt → int.parse
    dart = dart.replace(/parseInt\(([^,)]+)[^)]*\)/g, 'int.parse($1)');
    // parseFloat → double.parse
    dart = dart.replace(/parseFloat\(/g, 'double.parse(');

    // JSON.stringify → jsonEncode (perlu import dart:convert)
    if (dart.includes('JSON.stringify')) {
        dart = "import 'dart:convert';\n" + dart;
        dart = dart.replace(/JSON\.stringify\(/g, 'jsonEncode(');
    }
    if (dart.includes('JSON.parse')) {
        if (!dart.startsWith("import 'dart:convert'")) {
            dart = "import 'dart:convert';\n" + dart;
        }
        dart = dart.replace(/JSON\.parse\(/g, 'jsonDecode(');
    }

    return dart;
}

function convertHtmlToDart(html) {
    let dart = '// Converted from HTML to Dart Flutter Widget\n';
    dart += "import 'package:flutter/material.dart';\n\n";
    dart += 'class ConvertedWidget extends StatelessWidget {\n';
    dart += '  const ConvertedWidget({Key? key}) : super(key: key);\n\n';
    dart += '  @override\n';
    dart += '  Widget build(BuildContext context) {\n';
    dart += '    return Scaffold(\n';

    // Extract title
    const titleMatch = html.match(/<title>([^<]*)<\/title>/i);
    if (titleMatch) {
        dart += `      appBar: AppBar(title: const Text('${titleMatch[1]}')),\n`;
    }

    dart += '      body: SingleChildScrollView(\n';
    dart += '        child: Column(\n';
    dart += '          children: [\n';

    // Extract text dari tag umum
    const hMatches = [...html.matchAll(/<h[1-6][^>]*>([^<]*)<\/h[1-6]>/gi)];
    for (const m of hMatches) {
        dart += `            Text('${m[1].trim()}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 24)),\n`;
        dart += '            const SizedBox(height: 8),\n';
    }

    const pMatches = [...html.matchAll(/<p[^>]*>([^<]*)<\/p>/gi)];
    for (const m of pMatches) {
        if (m[1].trim()) {
            dart += `            Text('${m[1].trim()}'),\n`;
            dart += '            const SizedBox(height: 4),\n';
        }
    }

    // Button
    const btnMatches = [...html.matchAll(/<button[^>]*>([^<]*)<\/button>/gi)];
    for (const m of btnMatches) {
        dart += `            ElevatedButton(\n`;
        dart += `              onPressed: () {},\n`;
        dart += `              child: Text('${m[1].trim()}'),\n`;
        dart += `            ),\n`;
        dart += '            const SizedBox(height: 8),\n';
    }

    // Input
    const inputMatches = [...html.matchAll(/<input[^>]*placeholder="([^"]*)"[^>]*>/gi)];
    for (const m of inputMatches) {
        dart += `            TextField(\n`;
        dart += `              decoration: const InputDecoration(hintText: '${m[1]}'),\n`;
        dart += `            ),\n`;
        dart += '            const SizedBox(height: 8),\n';
    }

    dart += '          ],\n';
    dart += '        ),\n';
    dart += '      ),\n';
    dart += '    );\n';
    dart += '  }\n';
    dart += '}\n';

    // Tambahkan HTML asli sebagai komentar di bawah
    dart += '\n/* === Original HTML ===\n' + html.slice(0, 500) + (html.length > 500 ? '\n...(truncated)' : '') + '\n*/\n';

    return dart;
}

async function handleJsHtmlToDartProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, isFinal = false) {
    if (!isFinal) {
        const doc = ctx.message.document;
        const fname = doc.file_name || '';
        const ext = fname.split('.').pop().toLowerCase();

        if (!['zip', 'js', 'html', 'htm'].includes(ext)) {
            return ctx.reply(
                `<blockquote>❌ File harus berupa <b>.zip</b>, <b>.js</b>, atau <b>.html</b>!</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } }
            );
        }

        const waitMsg = await ctx.reply(`<blockquote>⏳ Mengunduh file...</blockquote>`, { parse_mode: 'HTML' });
        let buffer;
        try {
            buffer = await downloadTelegramFile(ctx, doc.file_id);
        } catch (e) {
            await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                `<blockquote>❌ ${e.message}</blockquote>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } }).catch(() => {});
            return;
        }
        await ctx.telegram.deleteMessage(waitMsg.chat.id, waitMsg.message_id).catch(() => {});

        if (!canUse(ctx.from.id, 'jshtml')) {
            return ctx.reply(`<blockquote>⚠️ <b>Kredit kamu habis!</b>\n\nHubungi owner untuk mendapatkan kredit tambahan.</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } });
        }

        const procMsg = await ctx.reply(`<blockquote>⏳ <b>Mengkonversi ke Dart...</b></blockquote>`, { parse_mode: 'HTML' });

        try {
            const outZip = new AdmZip();
            let count = 0;

            if (ext === 'zip') {
                const zip = new AdmZip(buffer);
                for (const entry of zip.getEntries()) {
                    if (entry.isDirectory) { outZip.addFile(entry.entryName, Buffer.alloc(0)); continue; }
                    const name = entry.entryName.toLowerCase();
                    if (name.endsWith('.js') || name.endsWith('.html') || name.endsWith('.htm')) {
                        const content = entry.getData().toString('utf8');
                        let dartContent;
                        if (name.endsWith('.js')) {
                            dartContent = convertJsToDart(content);
                        } else {
                            dartContent = convertHtmlToDart(content);
                        }
                        const newName = entry.entryName.replace(/\.(js|html|htm)$/i, '.dart');
                        outZip.addFile(newName, Buffer.from(dartContent, 'utf8'));
                        count++;
                    } else {
                        outZip.addFile(entry.entryName, entry.getData());
                    }
                }
            } else if (ext === 'js') {
                const content = buffer.toString('utf8');
                const dartContent = convertJsToDart(content);
                const newName = fname.replace(/\.js$/i, '.dart');
                outZip.addFile(newName, Buffer.from(dartContent, 'utf8'));
                count = 1;
            } else {
                const content = buffer.toString('utf8');
                const dartContent = convertHtmlToDart(content);
                const newName = fname.replace(/\.(html|htm)$/i, '.dart');
                outZip.addFile(newName, Buffer.from(dartContent, 'utf8'));
                count = 1;
            }

            spendCredit(ctx.from.id);
            addLimit(ctx.from.id, 'jshtml');
            delete userState[ctx.from.id];
            await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});
            await sendDocumentSmart(
                ctx, outZip.toBuffer(), `dart_converted_${Date.now()}.zip`,
                {
                    caption: `<blockquote>✅ <b>Konversi Selesai!</b>\n\n🔄 File dikonversi: <b>${count}</b>\n💡 JS/HTML → Dart\n\n💎 Sisa kredit: <b>${getRemaining(ctx.from.id)}</b>\n\n⚠️ Hasil konversi otomatis, periksa kembali kode Dart yang dihasilkan.</blockquote>`,
                    parse_mode: 'HTML',
                    reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'main_menu', style: 'primary' }]] }
                }
            );
        } catch (e) {
            await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});
            await ctx.reply(`<blockquote>❌ <b>Gagal konversi:</b> ${e.message}</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } });
        }
    }
}

module.exports = { handleJsHtmlToDartProcess };
