const { readJson, writeJson, JOBS_FILE } = require('../utils/database');
const { uploadToRelease, deleteRelease, dispatchWorkflow, getLatestRun, getRunById, getArtifacts, downloadArtifactZip, makeProgressBar, randomJobId } = require('../utils/github');
const config = require('../config');

async function startBuildJob(ctx, statusMsg, zipBuffer) {
    const jobId = randomJobId();

    await ctx.telegram.editMessageText(statusMsg.chat.id, statusMsg.message_id, undefined,
        `<blockquote>⬆️ <b>Upload ke GitHub Release...</b>\n\nJob ID: <code>${jobId}</code>\n⏳ Mohon tunggu, file sedang diupload...</blockquote>`,
        { parse_mode: 'HTML' }).catch(() => {});

    // Upload via GitHub Releases (tidak ada batas 1MB seperti Contents API)
    const { releaseId, downloadUrl, tag } = await uploadToRelease(jobId, zipBuffer);

    await ctx.telegram.editMessageText(statusMsg.chat.id, statusMsg.message_id, undefined,
        `<blockquote>🚀 <b>Menjalankan workflow...</b>\n\nJob ID: <code>${jobId}</code></blockquote>`,
        { parse_mode: 'HTML' }).catch(() => {});

    // Kirim input sesuai yang dideklarasikan workflow_dispatch di flutter_build.yml
    // (zip_url, tag, build_type, only_analyze) — JANGAN kirim job_id, GitHub akan
    // menolak dengan 422 "Unexpected inputs provided" kalau ada input yang tidak terdaftar.
    await dispatchWorkflow(config.GITHUB_WORKFLOW, { zip_url: downloadUrl, tag, build_type: 'release' });

    let runId = null;
    for (let i = 0; i < 8; i++) {
        await new Promise(r => setTimeout(r, 3000));
        const run = await getLatestRun(config.GITHUB_WORKFLOW);
        if (run) { runId = run.id; break; }
    }

    const jobs = readJson(JOBS_FILE);
    jobs[jobId] = { job_id: jobId, release_id: releaseId, release_tag: tag, run_id: runId, user_id: ctx.from.id, created_at: new Date().toISOString() };
    writeJson(JOBS_FILE, jobs);

    await ctx.telegram.editMessageText(statusMsg.chat.id, statusMsg.message_id, undefined,
        `<blockquote>✅ <b>Build dimulai!</b>\n\nJob ID: <code>${jobId}</code>\n\n⚠️ Simpan Job ID ini untuk cek status dan ambil APK.</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '📊 Cek Status', callback_data: 'build_status', style: 'primary' }], [{ text: '🏠 Menu Utama', callback_data: 'main_menu', style: 'primary' }]] } }
    ).catch(() => {});

    const progressMsg = await ctx.reply(
        `<blockquote>⏳ <b>Monitoring build...</b>\n\nJob ID: <code>${jobId}</code>\n${makeProgressBar(5)}</blockquote>`,
        { parse_mode: 'HTML' });
    trackBuildProgress(ctx, progressMsg.chat.id, progressMsg.message_id, jobId);
}

async function trackBuildProgress(ctx, chatId, msgId, jobId) {
    const steps = [5, 15, 25, 35, 45, 55, 65, 75, 85, 92, 97];
    let idx = 0;
    const maxWait = 30 * 60 * 1000;
    const start = Date.now();

    while (Date.now() - start < maxWait) {
        const jobs = readJson(JOBS_FILE);
        const job = jobs[jobId];
        if (!job?.run_id) { await new Promise(r => setTimeout(r, 5000)); idx = Math.min(idx + 1, 2); continue; }

        try {
            const run = await getRunById(job.run_id);
            if (run.status === 'completed') {
                const icon = run.conclusion === 'success' ? '✅' : '❌';
                const label = run.conclusion === 'success' ? 'SUCCESS' : `FAILED (${run.conclusion})`;

                // Cleanup: hapus release setelah build selesai
                if (job.release_id && job.release_tag) {
                    deleteRelease(job.release_id, job.release_tag).catch(() => {});
                }

                await ctx.telegram.editMessageText(chatId, msgId, undefined,
                    `<blockquote>🏗 <b>HASIL BUILD</b>\n\nJob ID: <code>${jobId}</code>\nStatus: ${run.status}\n${makeProgressBar(100)}\n\n${icon} <b>${label}</b>${run.conclusion === 'success' ? '\n\n📥 Gunakan "Ambil APK" untuk download hasil.' : ''}</blockquote>`,
                    { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '📥 Ambil APK', callback_data: 'build_get_apk', style: 'success' }, { text: '🏗 Menu Build', callback_data: 'menu_build', style: 'primary' }]] } }
                ).catch(() => {});
                break;
            }
            const pct = steps[Math.min(idx, steps.length - 1)];
            await ctx.telegram.editMessageText(chatId, msgId, undefined,
                `<blockquote>⏳ <b>Monitoring build...</b>\n\nJob ID: <code>${jobId}</code>\nStatus: <b>${run.status}</b>\n${makeProgressBar(pct)}\n\n⏰ Waktu berjalan: ${Math.floor((Date.now() - start) / 60000)}m</blockquote>`,
                { parse_mode: 'HTML' }
            ).catch(() => {});
        } catch {}

        await new Promise(r => setTimeout(r, 10000));
        idx = Math.min(idx + 1, steps.length - 1);
    }
}

async function handleBuildProcess(ctx, state, userState, downloadTelegramFile, startBuildJob, isUrl = false) {
    if (isUrl) {
        const url = ctx.message.text.trim();
        if (!url.startsWith('http')) {
            return ctx.reply(`<blockquote>❌ URL tidak valid!</blockquote>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_build', style: 'danger' }]] } });
        }
        delete userState[ctx.from.id];
        const statusMsg = await ctx.reply(`<blockquote>⬇️ <b>Mengunduh project...</b></blockquote>`, { parse_mode: 'HTML' });
        // Fire-and-forget: jangan await supaya tidak kena timeout 90 detik Telegraf
        (async () => {
            try {
                const res = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0' } });
                if (!res.ok) throw new Error(`Download gagal (${res.status})`);
                const buffer = Buffer.from(await res.arrayBuffer());
                await ctx.telegram.editMessageText(statusMsg.chat.id, statusMsg.message_id, undefined, `<blockquote>⬆️ <b>Upload project ke GitHub Release...</b></blockquote>`, { parse_mode: 'HTML' }).catch(() => {});
                await startBuildJob(ctx, statusMsg, buffer);
            } catch (e) {
                await ctx.telegram.editMessageText(statusMsg.chat.id, statusMsg.message_id, undefined, `<blockquote>❌ <b>Gagal:</b> ${e.message}</blockquote>`, { parse_mode: 'HTML' }).catch(() => {});
            }
        })();
        return;
    }

    const doc = ctx.message.document;
    if (!doc.file_name?.endsWith('.zip')) {
        return ctx.reply(`<blockquote>❌ Harus file <b>.zip</b>!</blockquote>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_build', style: 'danger' }]] } });
    }
    delete userState[ctx.from.id];
    const statusMsg = await ctx.reply(`<blockquote>⬆️ <b>Upload project ke GitHub Release...</b></blockquote>`, { parse_mode: 'HTML' });
    // Fire-and-forget: jangan await supaya tidak kena timeout 90 detik Telegraf
    (async () => {
        try {
            const buffer = await downloadTelegramFile(ctx, doc.file_id);
            await startBuildJob(ctx, statusMsg, buffer);
        } catch (e) {
            await ctx.telegram.editMessageText(statusMsg.chat.id, statusMsg.message_id, undefined, `<blockquote>❌ <b>Gagal:</b> ${e.message}</blockquote>`, { parse_mode: 'HTML' }).catch(() => {});
        }
    })();
}

module.exports = { handleBuildProcess, startBuildJob, trackBuildProgress };
