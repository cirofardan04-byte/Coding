const AdmZip = require('adm-zip');
const path   = require('path');
const { sendDocumentSmart } = require('../utils/gramjs');

// Ukuran icon Android standar
const ANDROID_ICON_SIZES = [
    { dir: 'mipmap-mdpi',    size: 48  },
    { dir: 'mipmap-hdpi',    size: 72  },
    { dir: 'mipmap-xhdpi',   size: 96  },
    { dir: 'mipmap-xxhdpi',  size: 144 },
    { dir: 'mipmap-xxxhdpi', size: 192 },
];

// Ukuran icon iOS
const IOS_ICON_SIZES = [
    { name: 'Icon-App-20x20@1x.png',     size: 20   },
    { name: 'Icon-App-20x20@2x.png',     size: 40   },
    { name: 'Icon-App-20x20@3x.png',     size: 60   },
    { name: 'Icon-App-29x29@1x.png',     size: 29   },
    { name: 'Icon-App-29x29@2x.png',     size: 58   },
    { name: 'Icon-App-29x29@3x.png',     size: 87   },
    { name: 'Icon-App-40x40@1x.png',     size: 40   },
    { name: 'Icon-App-40x40@2x.png',     size: 80   },
    { name: 'Icon-App-40x40@3x.png',     size: 120  },
    { name: 'Icon-App-60x60@2x.png',     size: 120  },
    { name: 'Icon-App-60x60@3x.png',     size: 180  },
    { name: 'Icon-App-76x76@1x.png',     size: 76   },
    { name: 'Icon-App-76x76@2x.png',     size: 152  },
    { name: 'Icon-App-83.5x83.5@2x.png', size: 167  },
    { name: 'ItunesArtwork@2x.png',      size: 1024 },
];

// ── Deteksi format icon launcher yang dipakai di ZIP ──────
function detectIconFormat(zipBuffer) {
    const zip = new AdmZip(zipBuffer);
    const formatCount = {};
    for (const entry of zip.getEntries()) {
        if (entry.isDirectory) continue;
        const name = entry.entryName;
        const base = path.basename(name).toLowerCase();
        if (
            name.includes('mipmap') && (
                base.startsWith('ic_launcher') ||
                base.startsWith('ic_background') ||
                base.startsWith('ic_foreground')
            )
        ) {
            const ext = path.extname(base).replace('.', '').toLowerCase();
            formatCount[ext] = (formatCount[ext] || 0) + 1;
        }
    }
    // Kembalikan format yang paling banyak ditemukan
    const sorted = Object.entries(formatCount).sort((a, b) => b[1] - a[1]);
    return sorted.length > 0 ? sorted[0][0] : 'png'; // default png
}

// ── Cek apakah file yang dikirim sesuai format yang diharapkan ──
function getFileExt(ctx) {
    const doc = ctx.message.document;
    if (doc) {
        const ext = path.extname(doc.file_name || '').replace('.', '').toLowerCase();
        if (ext) return ext;
        if (doc.mime_type) {
            if (doc.mime_type === 'image/png')  return 'png';
            if (doc.mime_type === 'image/jpeg') return 'jpg';
            if (doc.mime_type === 'image/webp') return 'webp';
        }
    }
    if (ctx.message.photo) return 'jpg'; // Telegram compress jadi JPEG
    return null;
}

async function handleGantiIconProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, isFinal = false) {
    if (!isFinal) {
        // Step 1: Terima ZIP project
        const doc = ctx.message.document;
        if (!doc.file_name?.endsWith('.zip')) {
            return ctx.reply(
                `<blockquote>❌ File harus berupa <b>.zip</b> project Flutter!</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } }
            );
        }
        const waitMsg = await ctx.reply(`<blockquote>⏳ Mengunduh & scan project...</blockquote>`, { parse_mode: 'HTML' });
        let buffer;
        try {
            buffer = await downloadTelegramFile(ctx, doc.file_id);
        } catch (e) {
            await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                `<blockquote>❌ ${e.message}</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } }
            ).catch(() => {});
            return;
        }
        await ctx.telegram.deleteMessage(waitMsg.chat.id, waitMsg.message_id).catch(() => {});

        // Deteksi format icon asli di ZIP
        const detectedFormat = detectIconFormat(buffer);
        const formatLabel = detectedFormat === 'jpg' ? 'JPG/JPEG' : detectedFormat.toUpperCase();

        userState[ctx.from.id] = { step: 'WAIT_ICON_IMAGE', zipBuffer: buffer, expectedFormat: detectedFormat };

        return ctx.reply(
            `<blockquote>✅ <b>Project diterima!</b>\n\n🔍 <b>Format icon terdeteksi:</b> <code>${formatLabel}</code>\n\n🖼 Sekarang kirimkan <b>gambar icon baru</b> dalam format <b>${formatLabel}</b>.\n\n📌 Tips:\n• Kirim sebagai <b>File/Dokumen</b> agar tidak dikompres Telegram\n• Format harus <b>${formatLabel}</b> sesuai icon asli\n• Ukuran minimal <b>512x512 px</b>\n• Rasio 1:1 (persegi)\n\nBot akan otomatis mengganti semua icon Android & iOS!</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } }
        );
    }

    // Step 2: Terima gambar icon — validasi format
    const photo    = ctx.message.photo;
    const doc      = ctx.message.document;
    const isImgDoc = doc && (doc.mime_type?.startsWith('image/') || ['.png','.jpg','.jpeg','.webp'].includes(path.extname(doc.file_name || '').toLowerCase()));

    if (!photo && !isImgDoc) {
        const fmt = (state.expectedFormat === 'jpg' ? 'JPG/JPEG' : (state.expectedFormat || 'PNG').toUpperCase());
        return ctx.reply(
            `<blockquote>❌ Kirimkan <b>gambar ${fmt}</b> sebagai Dokumen/File!\n\n⚠️ Jangan kirim sebagai foto biasa agar kualitas tidak turun.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } }
        );
    }

    // Validasi format file sesuai yang dideteksi
    const expectedFmt = state.expectedFormat || 'png';
    const receivedExt = getFileExt(ctx);

    if (receivedExt && expectedFmt !== 'jpg' && receivedExt !== expectedFmt &&
        !(expectedFmt === 'jpg' && (receivedExt === 'jpeg' || receivedExt === 'jpg'))) {
        const fmtLabel = expectedFmt === 'jpg' ? 'JPG/JPEG' : expectedFmt.toUpperCase();
        return ctx.reply(
            `<blockquote>⚠️ <b>Format tidak sesuai!</b>\n\nIcon asli di project kamu berformat <b>${fmtLabel}</b>.\nKamu mengirim: <code>${(receivedExt || '?').toUpperCase()}</code>\n\n📌 Tolong kirim ulang gambar dalam format <b>${fmtLabel}</b> agar icon bisa terganti dengan benar!</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } }
        );
    }

    if (!canUse(ctx.from.id, 'gantiicon')) {
        return ctx.reply(
            `<blockquote>⚠️ <b>Kredit kamu habis!</b>\n\nHubungi owner untuk mendapatkan kredit tambahan.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } }
        );
    }

    const procMsg = await ctx.reply(`<blockquote>⏳ <b>Mengganti icon aplikasi...</b>\n\n🔄 Memproses gambar...</blockquote>`, { parse_mode: 'HTML' });

    try {
        let iconFileId;
        if (Array.isArray(photo)) {
            iconFileId = photo[photo.length - 1].file_id;
        } else if (photo) {
            iconFileId = photo.file_id;
        } else {
            iconFileId = doc.file_id;
        }

        const iconBuffer   = await downloadTelegramFile(ctx, iconFileId);
        const { zipBuffer } = state;
        delete userState[ctx.from.id];

        const zip    = new AdmZip(zipBuffer);
        const outZip = new AdmZip();
        let androidReplaced = 0;
        let iosReplaced     = 0;

        // Copy semua file dari zip
        for (const entry of zip.getEntries()) {
            if (entry.isDirectory) { outZip.addFile(entry.entryName, Buffer.alloc(0)); continue; }
            outZip.addFile(entry.entryName, entry.getData());
        }

        // Ganti icon — pertahankan nama & ekstensi file asli, hanya ganti konten
        for (const entry of outZip.getEntries()) {
            if (entry.isDirectory) continue;
            const name     = entry.entryName;
            const basename = path.basename(name);
            const baseLow  = basename.toLowerCase();

            // Android icons (ic_launcher*, ic_background*, ic_foreground* di mipmap*)
            if (
                name.includes('mipmap') &&
                (baseLow.startsWith('ic_launcher') || baseLow.startsWith('ic_background') || baseLow.startsWith('ic_foreground'))
            ) {
                outZip.updateFile(name, iconBuffer);
                androidReplaced++;
            }

            // iOS icons (AppIcon.appiconset)
            if (name.includes('AppIcon.appiconset') && ['.png','.jpg','.jpeg'].includes(path.extname(basename).toLowerCase())) {
                outZip.updateFile(name, iconBuffer);
                iosReplaced++;
            }

            // Flutter web/assets icons
            if (name.includes('icons/') && ['Icon-192.png','Icon-512.png','Icon-maskable-192.png','Icon-maskable-512.png'].includes(basename)) {
                outZip.updateFile(name, iconBuffer);
            }

            // Favicon
            if (basename === 'favicon.png') {
                outZip.updateFile(name, iconBuffer);
            }
        }

        spendCredit(ctx.from.id);
        addLimit(ctx.from.id, 'gantiicon');
        await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});

        await sendDocumentSmart(
            ctx, outZip.toBuffer(), `new_icon_${Date.now()}.zip`,
            {
                caption: `<blockquote>✅ <b>Ganti Icon Selesai!</b>\n\n🤖 Android icons diganti: <b>${androidReplaced}</b>\n🍎 iOS icons diganti: <b>${iosReplaced}</b>\n🖼 Format icon: <b>${(state.expectedFormat || 'png').toUpperCase()}</b>\n\n⚠️ Untuk resize icon yang presisi, jalankan:\n<code>flutter pub run flutter_launcher_icons</code>\n\n💎 Sisa kredit: <b>${getRemaining(ctx.from.id)}</b></blockquote>`,
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'main_menu', style: 'primary' }]] }
            }
        );
    } catch (e) {
        await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});
        await ctx.reply(
            `<blockquote>❌ <b>Gagal:</b> ${e.message}</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } }
        );
    }
}

module.exports = { handleGantiIconProcess };
