const AdmZip = require('adm-zip');

// Cek syntax JS sederhana tanpa dependency eksternal
function checkJsSyntax(code, filename) {
    const errors = [];
    const warnings = [];
    const lines = code.split('\n');

    let braceCount = 0;
    let parenCount = 0;
    let bracketCount = 0;
    let inString = false;
    let stringChar = '';
    let inMultiComment = false;
    let inSingleComment = false;

    for (let lineNum = 0; lineNum < lines.length; lineNum++) {
        const line = lines[lineNum];
        const trimmed = line.trim();
        inSingleComment = false;

        // Cek console.log yang ketinggalan (warning)
        if (trimmed.includes('console.log(') && !trimmed.startsWith('//')) {
            warnings.push(`Baris ${lineNum + 1}: console.log() ditemukan (debug code?)`);
        }

        // Cek var (warning, gunakan let/const)
        if (/^\s*var\s+/.test(line) && !trimmed.startsWith('//')) {
            warnings.push(`Baris ${lineNum + 1}: Gunakan 'let' atau 'const' daripada 'var'`);
        }

        // Cek == (bukan ===)
        if (/[^=!<>]==[^=]/.test(trimmed) && !trimmed.startsWith('//')) {
            warnings.push(`Baris ${lineNum + 1}: Gunakan '===' daripada '==' untuk perbandingan ketat`);
        }

        // Cek trailing whitespace
        if (line !== line.trimEnd() && trimmed.length > 0) {
            // Hanya info, tidak error
        }

        // Hitung bracket balance (sederhana, tidak memperhitungkan string/comment)
        for (let i = 0; i < line.length; i++) {
            const ch = line[i];
            const prev = i > 0 ? line[i - 1] : '';

            if (inMultiComment) {
                if (ch === '/' && prev === '*') inMultiComment = false;
                continue;
            }
            if (inSingleComment) break;
            if (inString) {
                if (ch === stringChar && prev !== '\\') inString = false;
                continue;
            }

            if (ch === '/' && line[i + 1] === '/') { inSingleComment = true; break; }
            if (ch === '/' && line[i + 1] === '*') { inMultiComment = true; i++; continue; }
            if (ch === '"' || ch === "'" || ch === '`') { inString = true; stringChar = ch; continue; }

            if (ch === '{') braceCount++;
            if (ch === '}') braceCount--;
            if (ch === '(') parenCount++;
            if (ch === ')') parenCount--;
            if (ch === '[') bracketCount++;
            if (ch === ']') bracketCount--;

            if (braceCount < 0) { errors.push(`Baris ${lineNum + 1}: Kurung kurawal '}' tidak memiliki pasangan`); braceCount = 0; }
            if (parenCount < 0) { errors.push(`Baris ${lineNum + 1}: Tanda tutup ')' tidak memiliki pasangan`); parenCount = 0; }
            if (bracketCount < 0) { errors.push(`Baris ${lineNum + 1}: Tanda tutup ']' tidak memiliki pasangan`); bracketCount = 0; }
        }

        // Cek semicolon yang hilang (heuristik sederhana)
        if (trimmed.length > 0 &&
            !trimmed.endsWith('{') && !trimmed.endsWith('}') &&
            !trimmed.endsWith(',') && !trimmed.endsWith(';') &&
            !trimmed.endsWith('(') && !trimmed.endsWith(')') &&
            !trimmed.startsWith('//') && !trimmed.startsWith('*') &&
            !trimmed.startsWith('if') && !trimmed.startsWith('else') &&
            !trimmed.startsWith('for') && !trimmed.startsWith('while') &&
            !trimmed.startsWith('function') && !trimmed.startsWith('class') &&
            !trimmed.startsWith('import') && !trimmed.startsWith('export') &&
            !trimmed.startsWith('return') &&
            /^(const|let|var|[\w$.]+\s*[=(])/.test(trimmed) &&
            lineNum < lines.length - 1) {
            const nextLine = lines[lineNum + 1]?.trim() || '';
            if (nextLine && !nextLine.startsWith('.') && !nextLine.startsWith('?') && !nextLine.startsWith(':') && !nextLine.startsWith('+') && !nextLine.startsWith('-')) {
                // bisa saja ASI, jadi warning saja
                // warnings.push(`Baris ${lineNum + 1}: Mungkin semicolon hilang`);
            }
        }
    }

    if (braceCount > 0) errors.push(`Akhir file: ${braceCount} kurung kurawal '{' tidak ditutup`);
    if (parenCount > 0) errors.push(`Akhir file: ${parenCount} tanda buka '(' tidak ditutup`);
    if (bracketCount > 0) errors.push(`Akhir file: ${bracketCount} tanda buka '[' tidak ditutup`);

    // Cek require/import yang umum salah
    const requireMatches = [...code.matchAll(/require\(['"]([^'"]+)['"]\)/g)];
    // Hanya info

    return { errors, warnings, lines: lines.length };
}

async function handleCekSyntaxProcess(ctx, state, userState, downloadTelegramFile) {
    const doc = ctx.message.document;
    const fname = doc.file_name || '';
    const ext = fname.split('.').pop().toLowerCase();

    if (!['zip', 'js'].includes(ext)) {
        return ctx.reply(
            `<blockquote>❌ File harus berupa <b>.js</b> atau <b>.zip</b> berisi file JS!</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } }
        );
    }

    const waitMsg = await ctx.reply(`<blockquote>⏳ Mengunduh file untuk dicek...</blockquote>`, { parse_mode: 'HTML' });
    let buffer;
    try {
        buffer = await downloadTelegramFile(ctx, doc.file_id);
    } catch (e) {
        await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
            `<blockquote>❌ ${e.message}</blockquote>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } }).catch(() => {});
        return;
    }
    await ctx.telegram.deleteMessage(waitMsg.chat.id, waitMsg.message_id).catch(() => {});

    const procMsg = await ctx.reply(`<blockquote>🔍 <b>Menganalisis syntax JS...</b></blockquote>`, { parse_mode: 'HTML' });

    try {
        let results = [];

        if (ext === 'zip') {
            const zip = new AdmZip(buffer);
            for (const entry of zip.getEntries()) {
                if (entry.isDirectory) continue;
                if (!entry.entryName.toLowerCase().endsWith('.js')) continue;
                const code = entry.getData().toString('utf8');
                const result = checkJsSyntax(code, entry.entryName);
                results.push({ file: entry.entryName, ...result });
            }
        } else {
            const code = buffer.toString('utf8');
            const result = checkJsSyntax(code, fname);
            results.push({ file: fname, ...result });
        }

        delete userState[ctx.from.id];
        await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});

        if (results.length === 0) {
            return ctx.reply(`<blockquote>⚠️ Tidak ada file .js ditemukan dalam zip.</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } });
        }

        let report = `<blockquote>🔍 <b>HASIL CEK SYNTAX JS</b>\n\n`;
        let totalErrors = 0;
        let totalWarnings = 0;

        for (const r of results.slice(0, 5)) { // max 5 file
            const errCount = r.errors.length;
            const warnCount = r.warnings.length;
            totalErrors += errCount;
            totalWarnings += warnCount;

            const icon = errCount > 0 ? '❌' : (warnCount > 0 ? '⚠️' : '✅');
            report += `${icon} <b>${r.file}</b> (${r.lines} baris)\n`;
            if (errCount > 0) {
                report += `   🔴 Error (${errCount}):\n`;
                for (const e of r.errors.slice(0, 3)) {
                    report += `   • ${e}\n`;
                }
                if (r.errors.length > 3) report += `   • ...dan ${r.errors.length - 3} error lagi\n`;
            }
            if (warnCount > 0) {
                report += `   🟡 Warning (${warnCount}):\n`;
                for (const w of r.warnings.slice(0, 2)) {
                    report += `   • ${w}\n`;
                }
                if (r.warnings.length > 2) report += `   • ...dan ${r.warnings.length - 2} warning lagi\n`;
            }
            if (errCount === 0 && warnCount === 0) {
                report += `   ✅ Syntax OK\n`;
            }
            report += '\n';
        }

        if (results.length > 5) {
            report += `📁 ...dan ${results.length - 5} file JS lainnya\n\n`;
        }

        report += `📊 <b>Ringkasan:</b>\n`;
        report += `📁 File diperiksa: <b>${results.length}</b>\n`;
        report += `🔴 Total Error: <b>${totalErrors}</b>\n`;
        report += `🟡 Total Warning: <b>${totalWarnings}</b>\n`;
        report += totalErrors === 0 ? `\n✅ <b>Tidak ada error syntax kritis!</b>` : `\n❌ <b>Ditemukan ${totalErrors} error, segera perbaiki!</b>`;
        report += `</blockquote>`;
        if (report.length > 4000) {
            report = report.slice(0, 3950) + '\n\n<i>...(dipotong karena terlalu panjang)</i></blockquote>';
        }

        await ctx.reply(report, {
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'main_menu', style: 'primary' }]] }
        });

    } catch (e) {
        await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});
        await ctx.reply(`<blockquote>❌ <b>Gagal cek syntax:</b> ${e.message}</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } });
    }
}

module.exports = { handleCekSyntaxProcess };
