const config = require('../config');

async function handleOwnerAddUser(ctx, state, db, saveDB, initCredits, getCredits) {
    const uid = parseInt(ctx.message.text.trim());
    if (isNaN(uid)) return ctx.reply(`<blockquote>⚠️ ID tidak valid.</blockquote>`, { parse_mode: 'HTML' });
    if (!db.whitelist.includes(uid)) { db.whitelist.push(uid); saveDB(db); }
    initCredits(uid);
    const userCredits = getCredits(uid);
    return ctx.reply(`<blockquote>✅ <b>User <code>${uid}</code> berhasil ditambahkan!</b>\n💎 Kredit: <b>${userCredits}</b></blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '⚙️ Panel Owner', callback_data: 'panel_owner', style: 'primary' }]] } });
}

async function handleOwnerRemoveUser(ctx, state, db, saveDB) {
    const uid = parseInt(ctx.message.text.trim());
    if (isNaN(uid)) return ctx.reply(`<blockquote>⚠️ ID tidak valid.</blockquote>`, { parse_mode: 'HTML' });
    if (uid === config.OWNER_ID) return ctx.reply(`<blockquote>⚠️ Tidak bisa menghapus Owner!</blockquote>`, { parse_mode: 'HTML' });
    db.whitelist = db.whitelist.filter(id => id !== uid);
    saveDB(db);
    return ctx.reply(`<blockquote>✅ <b>User <code>${uid}</code> berhasil dihapus.</b></blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '⚙️ Panel Owner', callback_data: 'panel_owner', style: 'primary' }]] } });
}

async function handleOwnerSetMedia(ctx, state, mediaType, updateConfig) {
    let mediaId;
    if (mediaType === 'photo') {
        mediaId = ctx.message.photo[ctx.message.photo.length - 1].file_id;
    } else if (mediaType === 'video') {
        mediaId = ctx.message.video.file_id;
    } else {
        mediaId = ctx.message.audio?.file_id || ctx.message.document?.file_id;
    }
    config.WELCOME_MEDIA = mediaId;
    config.WELCOME_MEDIA_TYPE = mediaType;
    updateConfig({ WELCOME_MEDIA: mediaId, WELCOME_MEDIA_TYPE: mediaType });
    return ctx.reply(`<blockquote>✅ <b>${mediaType === 'photo' ? 'Foto' : mediaType === 'video' ? 'Video' : 'Audio'} sambutan berhasil disimpan!</b>\n\nKetik /start untuk melihat hasilnya.</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '⚙️ Panel Owner', callback_data: 'panel_owner', style: 'primary' }]] } });
}

module.exports = { handleOwnerAddUser, handleOwnerRemoveUser, handleOwnerSetMedia };