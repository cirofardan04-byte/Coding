const AdmZip = require('adm-zip');
const path = require('path');
const { sendDocumentSmart } = require('../utils/gramjs');

async function handleRecolourProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, _AdmZip, isFinal = false) {
    if (!isFinal) return;

    const oldHex = ctx.message.text.trim().replace('#', '').toUpperCase();
    if (!/^[0-9A-F]{6,8}$/.test(oldHex)) {
        return ctx.reply(`<blockquote>❌ Format HEX tidak valid!\n\nContoh: <code>FF0000</code></blockquote>`, { parse_mode: 'HTML' });
    }

    const { targetHex, zipBuffer } = state;
    delete userState[ctx.from.id];

    if (!canUse(ctx.from.id, 'recolour')) {
        return ctx.reply(`<blockquote>⚠️ <b>Kredit kamu habis!</b>\n\nHubungi owner untuk mendapatkan kredit tambahan.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } });
    }

    const procMsg = await ctx.reply(
        `<blockquote>⏳ <b>Memproses recolour...</b>\n\n🎨 Lama: <code>#${oldHex}</code> → Baru: <code>#${targetHex}</code></blockquote>`,
        { parse_mode: 'HTML' }
    );

    try {
        const zip = new AdmZip(zipBuffer);
        const entries = zip.getEntries();
        const totalEntries = entries.length;

        // Kumpulkan semua file .dart yang mengandung warna lama
        const modifiedDarts = [];
        let processed = 0;
        let lastUpdate = Date.now();

        // Pattern penggantian warna (support format Dart 0xFFXXXXXX dan #XXXXXX)
        const oldHexLower = oldHex.toLowerCase();
        const targetHexLower = targetHex.toLowerCase();

        const patterns = [
            { regex: new RegExp(`0xFF${oldHex}`, 'gi'), replace: `0xFF${targetHex}` },
            { regex: new RegExp(`0xff${oldHex}`, 'gi'), replace: `0xff${targetHex}` },
            { regex: new RegExp(`0xFF${oldHexLower}`, 'gi'), replace: `0xFF${targetHex}` },
            { regex: new RegExp(`0xff${oldHexLower}`, 'gi'), replace: `0xff${targetHex}` },
            { regex: new RegExp(`#${oldHex}`, 'gi'), replace: `#${targetHex}` },
            { regex: new RegExp(`#${oldHexLower}`, 'gi'), replace: `#${targetHex}` },
        ];

        for (const entry of entries) {
            processed++;

            if (Date.now() - lastUpdate > 2000 || processed % 20 === 0) {
                const percent = Math.floor((processed / totalEntries) * 100);
                await ctx.telegram.editMessageText(procMsg.chat.id, procMsg.message_id, undefined,
                    `<blockquote>⏳ <b>Memproses recolour...</b>\n\n🎨 Lama: <code>#${oldHex}</code> → Baru: <code>#${targetHex}</code>\n\n📂 Scan: ${processed}/${totalEntries} (${percent}%)\n🔍 File .dart diubah: ${modifiedDarts.length}</blockquote>`,
                    { parse_mode: 'HTML' }
                ).catch(() => {});
                lastUpdate = Date.now();
            }

            if (entry.isDirectory) continue;

            const entryName = entry.entryName;
            const ext = path.extname(entryName).toLowerCase();

            // Hanya proses file .dart
            if (ext !== '.dart') continue;

            let text = entry.getData().toString('utf8');
            let modified = false;

            for (const pattern of patterns) {
                if (pattern.regex.test(text)) {
                    text = text.replace(pattern.regex, pattern.replace);
                    modified = true;
                }
            }

            if (modified) {
                modifiedDarts.push({
                    name: path.basename(entryName), // nama file saja (tanpa path)
                    buffer: Buffer.from(text, 'utf8'),
                });
            }
        }

        spendCredit(ctx.from.id);
        addLimit(ctx.from.id, 'recolour');

        if (modifiedDarts.length === 0) {
            await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});
            return ctx.reply(
                `<blockquote>ℹ️ <b>Recolour Selesai</b>\n\n🎨 <code>#${oldHex}</code> → <code>#${targetHex}</code>\n\n📭 Tidak ada file .dart yang mengandung warna tersebut.</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'main_menu', style: 'primary' }]] } }
            );
        }

        await ctx.telegram.editMessageText(procMsg.chat.id, procMsg.message_id, undefined,
            `<blockquote>⏳ <b>Mengirim ${modifiedDarts.length} file .dart...</b>\n\n🎨 <code>#${oldHex}</code> → <code>#${targetHex}</code></blockquote>`,
            { parse_mode: 'HTML' }
        ).catch(() => {});

        // Kirim file .dart satu per satu
        for (let i = 0; i < modifiedDarts.length; i++) {
            const dart = modifiedDarts[i];
            const isLast = i === modifiedDarts.length - 1;
            const caption = isLast
                ? `<blockquote>✅ <b>Recolour Selesai!</b>\n\n🎨 Dari: <code>#${oldHex}</code>\n🎨 Ke: <code>#${targetHex}</code>\n📁 Total file diubah: <b>${modifiedDarts.length}</b>\n\n💎 Sisa kredit: <b>${getRemaining(ctx.from.id)}</b></blockquote>`
                : `<blockquote>📄 <b>${dart.name}</b> (${i + 1}/${modifiedDarts.length})</blockquote>`;

            await sendDocumentSmart(
                ctx, dart.buffer, dart.name,
                {
                    caption,
                    parse_mode: 'HTML',
                    ...(isLast ? { reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'main_menu', style: 'primary' }]] } } : {}),
                }
            );

            // Delay kecil antar file agar tidak flood
            if (!isLast) await new Promise(r => setTimeout(r, 300));
        }

        await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});

    } catch (e) {
        await ctx.telegram.editMessageText(procMsg.chat.id, procMsg.message_id, undefined,
            `<blockquote>❌ <b>Gagal:</b> ${e.message}\n\nPastikan file zip valid dan tidak corrupt.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } }
        ).catch(() => {
            ctx.reply(`<blockquote>❌ Gagal: ${e.message}</blockquote>`, { parse_mode: 'HTML' });
        });
    }
}

module.exports = { handleRecolourProcess };
