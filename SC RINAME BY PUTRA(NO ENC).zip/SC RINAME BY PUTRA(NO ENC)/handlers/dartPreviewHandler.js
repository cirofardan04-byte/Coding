const fetch = (...args) => import('node-fetch').then(({ default: f }) => f(...args)).catch(() => require('node-fetch')(...args));

// ────────────────────────────────────────────────────────────────────────────
// DART PREVIEW HANDLER
// Render widget .dart pakai DartPad API → balik hasilnya sebagai gambar
// ────────────────────────────────────────────────────────────────────────────

/**
 * Ambil source dari file .dart, wrap kalau perlu, lalu render lewat API.
 */
async function handleDartPreviewProcess(ctx, dartBuffer, filename) {
    let dartCode = dartBuffer.toString('utf-8');

    // Auto-wrap kalau tidak ada main() — user kirim widget doang
    const hasMain = /void\s+main\s*\(/.test(dartCode);
    const hasImportMaterial = dartCode.includes("import 'package:flutter/material.dart'");
    const hasImportWidgets = dartCode.includes("import 'package:flutter/widgets.dart'");

    if (!hasMain) {
        // Cari nama class pertama yang extends StatelessWidget / StatefulWidget
        const classMatch = dartCode.match(/class\s+(\w+)\s+extends\s+(?:Stateless|Stateful)Widget/);
        const widgetName = classMatch ? classMatch[1] : 'MyWidget';

        const imports = (!hasImportMaterial && !hasImportWidgets)
            ? "import 'package:flutter/material.dart';\n\n"
            : '';

        dartCode = `${imports}${dartCode}

void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: Center(child: ${widgetName}()),
      ),
    ),
  );
}
`;
    } else if (!hasImportMaterial && !hasImportWidgets) {
        dartCode = "import 'package:flutter/material.dart';\n\n" + dartCode;
    }

    // ─── Coba DartPad compile + screenshot via screenshot API ───────────────
    // Step 1: compile dulu lewat DartPad
    let compileResult;
    try {
        const compRes = await fetch('https://dartpad.dev/api/dartservices/v2/compile', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ source: dartCode }),
            signal: AbortSignal.timeout(30000),
        });
        compileResult = await compRes.json();
    } catch (e) {
        throw new Error(`Koneksi ke DartPad gagal: ${e.message}`);
    }

    if (compileResult.error) {
        const errMsg = compileResult.error || 'Compile error';
        throw new Error(`❌ Kode Dart gagal compile:\n\n${errMsg}`);
    }

    // Step 2: Screenshot via DartPad embed URL
    // Kita kirim kode ke DartPad share, lalu screenshot URL embed-nya
    const shareId = await uploadToDartPad(dartCode);
    if (!shareId) throw new Error('Gagal upload ke DartPad. Coba lagi nanti.');

    const embedUrl = `https://dartpad.dev/embed-flutter.html?id=${shareId}&theme=dark&run=true`;
    const screenshotUrl = await screenshotViaApi(embedUrl);

    return {
        imageBuffer: screenshotUrl,
        shareId,
        embedUrl: `https://dartpad.dev/?id=${shareId}`,
    };
}

/**
 * Upload kode dart ke DartPad gist-like API, return ID
 */
async function uploadToDartPad(dartCode) {
    try {
        const res = await fetch('https://dartpad.dev/api/dartservices/v2/shareDart', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ dart: dartCode }),
            signal: AbortSignal.timeout(20000),
        });
        if (!res.ok) return null;
        const data = await res.json();
        return data.uuid || null;
    } catch {
        return null;
    }
}

/**
 * Screenshot URL lewat beberapa API screenshot gratis
 */
async function screenshotViaApi(url) {
    const apis = [
        `https://image.thum.io/get/width/390/crop/844/allowJPG/wait/5/noanimate/${encodeURIComponent(url)}`,
        `https://mini.s-shot.ru/390x844/PNG/390/Z1/?${encodeURIComponent(url)}`,
        `https://api.screenshotone.com/take?url=${encodeURIComponent(url)}&viewport_width=390&viewport_height=844&format=png&timeout=25`,
    ];

    for (const apiUrl of apis) {
        try {
            const res = await fetch(apiUrl, {
                headers: { 'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15' },
                signal: AbortSignal.timeout(30000),
            });
            if (!res.ok) continue;
            const ct = res.headers.get('content-type') || '';
            if (ct.includes('image') || ct.includes('png') || ct.includes('jpeg')) {
                const buf = Buffer.from(await res.arrayBuffer());
                if (buf.length > 5000) return buf;
            }
        } catch {}
    }

    throw new Error('Semua API screenshot gagal. Coba lagi beberapa saat.');
}

module.exports = { handleDartPreviewProcess };
