const AdmZip = require('adm-zip');
const { sendDocumentSmart } = require('../utils/gramjs');

async function handleRenameProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, isFinal = false) {
    if (!isFinal) {
        // Step 1: Terima ZIP
        const doc = ctx.message.document;
        if (!doc.file_name?.endsWith('.zip')) {
            return ctx.reply(`<blockquote>❌ File harus berupa <b>.zip</b>!</blockquote>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } });
        }
        const waitMsg = await ctx.reply(`<blockquote>⏳ Mengunduh file...</blockquote>`, { parse_mode: 'HTML' });
        let buffer;
        try {
            buffer = await downloadTelegramFile(ctx, doc.file_id);
        } catch (e) {
            await ctx.telegram.editMessageText(waitMsg.chat.id, waitMsg.message_id, undefined,
                `<blockquote>❌ ${e.message}</blockquote>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } }).catch(() => {});
            return;
        }
        await ctx.telegram.deleteMessage(waitMsg.chat.id, waitMsg.message_id).catch(() => {});
        userState[ctx.from.id] = { step: 'WAIT_RENAME_DOMAIN', zipBuffer: buffer };
        return ctx.reply(
            `<blockquote>✅ <b>File diterima!</b>\n\nSekarang kirimkan <b>domain baru</b> beserta port (jika ada).\n\nContoh:\n• <code>api.example.com</code>\n• <code>api.example.com:8080</code></blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]] } }
        );
    }
    
    // Step 2: Proses rename
    const oldDomain = ctx.message.text.trim();
    const { newDomain, zipBuffer } = state;
    delete userState[ctx.from.id];

    if (!canUse(ctx.from.id, 'rename')) {
        return ctx.reply(`<blockquote>⚠️ <b>Kredit kamu habis!</b>\n\nHubungi owner untuk mendapatkan kredit tambahan.</blockquote>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } });
    }

    const procMsg = await ctx.reply(`<blockquote>⏳ <b>Memproses rename domain...</b>\n\n🔄 Lama: <code>${oldDomain}</code>\n✅ Baru: <code>${newDomain}</code></blockquote>`, { parse_mode: 'HTML' });

    try {
        const zip = new AdmZip(zipBuffer);
        const outZip = new AdmZip();
        let count = 0;

        for (const entry of zip.getEntries()) {
            if (entry.isDirectory) { outZip.addFile(entry.entryName, Buffer.alloc(0)); continue; }
            let content = entry.getData();
            const name = entry.entryName.toLowerCase();
            if (name.endsWith('.dart') || name.endsWith('.js') || name.endsWith('.json') || name.endsWith('.yaml') || name.endsWith('.yml') || name.endsWith('.xml') || name.endsWith('.gradle') || name.endsWith('.properties') || name.endsWith('.txt')) {
                const text = content.toString('utf8');
                if (text.includes(oldDomain)) {
                    content = Buffer.from(text.replaceAll(oldDomain, newDomain), 'utf8');
                    count++;
                }
            }
            outZip.addFile(entry.entryName, content);
        }

        spendCredit(ctx.from.id);
        addLimit(ctx.from.id, 'rename');
        await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});
        const outBuffer = outZip.toBuffer();
        await sendDocumentSmart(
            ctx, outBuffer, `renamed_domain_${Date.now()}.zip`,
            { caption: `<blockquote>✅ <b>Rename Domain Selesai!</b>\n\n🔄 Lama: <code>${oldDomain}</code>\n✅ Baru: <code>${newDomain}</code>\n📁 File diubah: <b>${count}</b>\n\n💎 Sisa kredit: <b>${getRemaining(ctx.from.id)}</b></blockquote>`,
              parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'main_menu', style: 'primary' }]] }
            }
        );
    } catch (e) {
        await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});
        await ctx.reply(`<blockquote>❌ <b>Gagal:</b> ${e.message}</blockquote>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } });
    }
}

module.exports = { handleRenameProcess };