const path = require('path');
const { sendDocumentSmart } = require('./gramjs');

// ── Recolour: terima file .dart tunggal, kembalikan file .dart ──
async function handleRecolourProcess(ctx, state, userState, downloadTelegramFile, canUse, spendCredit, addLimit, getRemaining, _AdmZip, isProcessing = false) {
    const oldHex = ctx.message.text.trim().replace('#', '').toUpperCase();
    if (!/^[0-9A-F]{6,8}$/.test(oldHex)) {
        return ctx.reply(
            `<blockquote>❌ Format HEX tidak valid!\n\nContoh: <code>FF0000</code></blockquote>`,
            { parse_mode: 'HTML' }
        );
    }

    const { targetHex, dartFiles } = state; // dartFiles: [{ name, buffer }]
    delete userState[ctx.from.id];

    if (!canUse(ctx.from.id, 'recolour')) {
        return ctx.reply(
            `<blockquote>⚠️ <b>Kredit kamu habis!</b>\n\nHubungi owner untuk mendapatkan kredit tambahan.</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } }
        );
    }

    const procMsg = await ctx.reply(
        `<blockquote>⏳ <b>Memproses recolour...</b>\n\n🎨 Lama: <code>#${oldHex}</code> → Baru: <code>#${targetHex}</code>\n\n📄 Memproses ${dartFiles.length} file dart...</blockquote>`,
        { parse_mode: 'HTML' }
    );

    try {
        const patterns = [
            { regex: new RegExp(`0xFF${oldHex}`, 'gi'), replace: `0xFF${targetHex}` },
            { regex: new RegExp(`0xff${oldHex}`, 'gi'), replace: `0xff${targetHex}` },
            { regex: new RegExp(`#${oldHex}`, 'gi'), replace: `#${targetHex}` },
            { regex: new RegExp(`#${oldHex.toLowerCase()}`, 'gi'), replace: `#${targetHex.toLowerCase()}` },
        ];

        const results = []; // { name, buffer, changed }
        for (const file of dartFiles) {
            let text = file.buffer.toString('utf8');
            let changed = false;
            for (const p of patterns) {
                const newText = text.replace(p.regex, p.replace);
                if (newText !== text) { text = newText; changed = true; }
            }
            results.push({ name: file.name, buffer: Buffer.from(text, 'utf8'), changed });
        }

        const changedFiles = results.filter(r => r.changed);
        const unchangedFiles = results.filter(r => !r.changed);

        spendCredit(ctx.from.id);
        addLimit(ctx.from.id, 'recolour');

        await ctx.telegram.editMessageText(
            procMsg.chat.id, procMsg.message_id, undefined,
            `<blockquote>✅ <b>Recolour Selesai!</b>\n\n🎨 Dari: <code>#${oldHex}</code>\n🎨 Ke: <code>#${targetHex}</code>\n📁 File diubah: <b>${changedFiles.length}</b> dari ${dartFiles.length}\n📤 Mengirim file dart...</blockquote>`,
            { parse_mode: 'HTML' }
        ).catch(() => {});

        if (changedFiles.length === 0) {
            await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});
            return ctx.reply(
                `<blockquote>⚠️ <b>Tidak ada warna yang ditemukan!</b>\n\nWarna <code>#${oldHex}</code> tidak ditemukan di file dart yang dikirim.\n\n💎 Kredit tidak terpakai karena tidak ada perubahan.\n\nCoba cek HEX yang benar di project kamu.</blockquote>`,
                { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } }
            );
        }

        // Kirim satu per satu file dart yang berubah
        for (let i = 0; i < changedFiles.length; i++) {
            const f = changedFiles[i];
            await sendDocumentSmart(
                ctx, f.buffer, f.name,
                {
                    caption: i === changedFiles.length - 1
                        ? `<blockquote>✅ <b>Recolour Selesai!</b>\n\n🎨 Dari: <code>#${oldHex}</code>\n🎨 Ke: <code>#${targetHex}</code>\n📁 File diubah: <b>${changedFiles.length}</b> dari ${dartFiles.length}\n\n💎 Sisa kredit: <b>${getRemaining(ctx.from.id)}</b></blockquote>`
                        : `<blockquote>📄 File ${i + 1}/${changedFiles.length}: <code>${f.name}</code></blockquote>`,
                    parse_mode: 'HTML',
                    reply_markup: i === changedFiles.length - 1
                        ? { inline_keyboard: [[{ text: '🏠 Menu Utama', callback_data: 'main_menu', style: 'primary' }]] }
                        : undefined
                }
            );
            // Kecil delay antar file agar tidak flood
            if (i < changedFiles.length - 1) await new Promise(r => setTimeout(r, 300));
        }

        await ctx.telegram.deleteMessage(procMsg.chat.id, procMsg.message_id).catch(() => {});

    } catch (e) {
        await ctx.telegram.editMessageText(
            procMsg.chat.id, procMsg.message_id, undefined,
            `<blockquote>❌ <b>Gagal:</b> ${e.message}</blockquote>`,
            { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '🏠 Menu', callback_data: 'main_menu', style: 'primary' }]] } }
        ).catch(() => {});
    }
}

module.exports = { handleRecolourProcess };
