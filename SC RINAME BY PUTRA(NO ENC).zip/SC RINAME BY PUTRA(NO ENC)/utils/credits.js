const { readJson, writeJson, CREDITS_FILE, LIMITS_FILE } = require('./database');
const config = require('../config');

const INITIAL_CREDITS = 5;

function getCredits(userId) {
    if (userId === config.OWNER_ID) return Infinity;
    const credits = readJson(CREDITS_FILE);
    return credits[userId] ?? null;
}

function initCredits(userId) {
    const credits = readJson(CREDITS_FILE);
    if (credits[userId] === undefined) {
        credits[userId] = INITIAL_CREDITS;
        writeJson(CREDITS_FILE, credits);
        return true;
    }
    return false;
}

function spendCredit(userId) {
    if (userId === config.OWNER_ID) return true;
    const credits = readJson(CREDITS_FILE);
    if ((credits[userId] ?? 0) <= 0) return false;
    credits[userId] = (credits[userId] ?? 0) - 1;
    writeJson(CREDITS_FILE, credits);
    return true;
}

function addCredits(userId, amount) {
    const credits = readJson(CREDITS_FILE);
    if (credits[userId] === undefined) credits[userId] = 0;
    credits[userId] += amount;
    writeJson(CREDITS_FILE, credits);
}

function creditDisplay(userId) {
    if (userId === config.OWNER_ID) return '∞';
    return getCredits(userId) ?? 0;
}

function getTodayKey() { 
    return new Date().toISOString().split('T')[0]; 
}

function getLimitCount(userId, feature) {
    const limits = readJson(LIMITS_FILE);
    const today = getTodayKey();
    return (limits[today]?.[userId]?.[feature]) || 0;
}

function addLimit(userId, feature) {
    const limits = readJson(LIMITS_FILE);
    const today = getTodayKey();
    if (!limits[today]) limits[today] = {};
    if (!limits[today][userId]) limits[today][userId] = {};
    limits[today][userId][feature] = (limits[today][userId][feature] || 0) + 1;
    writeJson(LIMITS_FILE, limits);
}

function canUse(userId, feature) {
    if (userId === config.OWNER_ID) return true;
    const credits = getCredits(userId);
    return credits !== null && credits > 0;
}

function getRemaining(userId) {
    return creditDisplay(userId);
}

module.exports = {
    INITIAL_CREDITS,
    getCredits,
    initCredits,
    spendCredit,
    addCredits,
    creditDisplay,
    getTodayKey,
    getLimitCount,
    addLimit,
    canUse,
    getRemaining
};