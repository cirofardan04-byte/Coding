const fs = require('fs');

function updateConfig(updates) {
    try {
        let content = fs.readFileSync('./config.js', 'utf8');
        for (const [key, val] of Object.entries(updates)) {
            const valStr = typeof val === 'string' ? `'${val}'` : JSON.stringify(val);
            content = content.replace(new RegExp(`(${key}:\\s*)[^,\n]+`), `$1${valStr}`);
        }
        fs.writeFileSync('./config.js', content, 'utf8');
    } catch (e) { console.error('Gagal update config:', e); }
}

module.exports = { updateConfig };