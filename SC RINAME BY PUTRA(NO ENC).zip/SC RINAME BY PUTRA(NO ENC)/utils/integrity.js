const fs = require('fs');
const path = require('path');

// ============================================================
// DAFTAR SEMUA FILE YANG TERHUBUNG DENGAN index.js
// Kalau salah satu file ini DIHAPUS atau HILANG,
// seluruh sistem (semua fitur) akan dianggap ERROR TOTAL
// dan bot otomatis dihentikan dari index.js.
// ============================================================
const REQUIRED_FILES = [
    'config.js',
    'package.json',

    // utils
    'utils/database.js',
    'utils/credits.js',
    'utils/github.js',
    'utils/helpers.js',
    'utils/integrity.js',
    'utils/gramjs.js',
    'utils/renameHandler.js',
    'utils/recolourHandler.js',
    'utils/deploy.js',

    // handlers
    'handlers/renameHandler.js',
    'handlers/renameAllHandler.js',
    'handlers/recolourHandler.js',
    'handlers/functionsHandler.js',
    'handlers/compressHandler.js',
    'handlers/buildHandler.js',
    'handlers/ownerHandler.js',
    'handlers/deployHandler.js',
    'handlers/jsHtmlToDartHandler.js',
    'handlers/cekSyntaxHandler.js',
    'handlers/renameAppHandler.js',
    'handlers/gantiIconHandler.js',
    'handlers/cekErrorFuncHandler.js',

    // menus
    'menus/mainMenu.js',
    'menus/renameMenu.js',
    'menus/recolourMenu.js',
    'menus/buildMenu.js',
    'menus/ownerMenu.js',
    'menus/deployMenu.js',
];

const ROOT_DIR = path.join(__dirname, '..');

/**
 * Mengecek apakah semua file pada REQUIRED_FILES masih ada.
 * @returns {{ ok: boolean, missing: string[] }}
 */
function checkIntegrity() {
    const missing = [];
    for (const rel of REQUIRED_FILES) {
        const full = path.join(ROOT_DIR, rel);
        if (!fs.existsSync(full)) missing.push(rel);
    }
    return { ok: missing.length === 0, missing };
}

/**
 * Dipanggil di paling atas index.js (SEBELUM require lain dijalankan).
 * Kalau ada file yang hilang, bot langsung dimatikan total (process.exit).
 * Ini membuat index.js menjadi "pusat" dari semua file —
 * jika satu saja hilang, seluruh sistem error.
 */
function enforceIntegrity() {
    const { ok, missing } = checkIntegrity();
    if (!ok) {
        console.error('==================================================');
        console.error('🚫 SYSTEM INTEGRITY CHECK FAILED');
        console.error('🚫 File berikut TIDAK DITEMUKAN / TELAH DIHAPUS:');
        missing.forEach(f => console.error('   ❌ ' + f));
        console.error('🚫 index.js menghentikan SELURUH BOT (error total).');
        console.error('==================================================');
        process.exit(1);
    }
    return true;
}

/**
 * Memantau integritas file secara berkala selama bot berjalan.
 * Kalau ada file yang dihapus SAAT RUNTIME, bot otomatis mati total.
 * @param {number} intervalMs - interval pengecekan (default 30 detik)
 */
function startIntegrityWatcher(intervalMs = 30000) {
    setInterval(() => {
        const { ok, missing } = checkIntegrity();
        if (!ok) {
            console.error('==================================================');
            console.error('🚫 INTEGRITY WATCHER: File hilang saat runtime!');
            missing.forEach(f => console.error('   ❌ ' + f));
            console.error('🚫 index.js menghentikan SELURUH BOT (error total).');
            console.error('==================================================');
            process.exit(1);
        }
    }, intervalMs);
}

module.exports = {
    REQUIRED_FILES,
    checkIntegrity,
    enforceIntegrity,
    startIntegrityWatcher,
};
