const config = require('../config');

// Limit Bot API resmi
const BOT_API_LIMIT = 2 * 1024 * 1024 * 1024; // 2GB

// Limit upload/download GramJS (akun/bot biasa Telegram: ~2GB)
const GRAMJS_LIMIT = 2 * 1024 * 1024 * 1024; // 2GB

let client = null;
let initPromise = null;

/**
 * Inisialisasi client GramJS memakai BOT_TOKEN saja.
 * - TIDAK butuh session file (StringSession kosong, tidak pernah disimpan ke disk).
 * - TIDAK butuh login interaktif (login otomatis via botAuthToken).
 * - Tetap butuh API_ID/API_HASH (didapat dari my.telegram.org) karena ini
 *   adalah syarat wajib protokol MTProto, namun proses login berjalan
 *   otomatis menggunakan BOT_TOKEN — tanpa OTP/kode/login manual.
 *
 * Dipanggil sekali saat startup. Kalau API_ID/API_HASH belum diisi,
 * fitur upload/download >2GB tidak aktif,
 * tapi bot tetap berjalan normal untuk file kecil via Bot API.
 */
async function initMtproto() {
    if (!config.API_ID || !config.API_HASH) {
        console.log('ℹ️ GRAMJS: API_ID/API_HASH belum diisi di config.js — upload/download file >2GB tidak akan tersedia.');
        return null;
    }
    if (initPromise) return initPromise;

    initPromise = (async () => {
        try {
            const { TelegramClient } = require('telegram');
            const { StringSession } = require('telegram/sessions');

            // Session selalu kosong & tidak disimpan ke disk — tanpa session, tanpa login manual.
            const c = new TelegramClient(new StringSession(''), Number(config.API_ID), config.API_HASH, {
                connectionRetries: 5,
            });
            await c.start({
                botAuthToken: config.BOT_TOKEN,
                onError: (err) => console.error('GRAMJS client error:', err),
            });
            client = c;
            console.log('✅ GRAMJS: client siap (upload/download file s/d 2GB aktif via Bot Token)');
            return c;
        } catch (e) {
            console.error('⚠️ GRAMJS: gagal init client, fallback file besar tidak aktif:', e.message);
            return null;
        }
    })();

    return initPromise;
}

function getMtprotoClient() {
    return client;
}

/**
 * Download dokumen dari sebuah pesan Telegram via GramJS (tanpa limit 2GB Bot API).
 * @param {number|string} chatId - ctx.chat.id
 * @param {number} messageId - ctx.message.message_id
 * @returns {Promise<Buffer>}
 */
async function downloadViaMtproto(chatId, messageId) {
    if (!client) throw new Error('GramJS client belum siap (cek API_ID/API_HASH di config.js)');
    const msgs = await client.getMessages(chatId, { ids: [messageId] });
    const msg = msgs && msgs[0];
    if (!msg || !msg.media) throw new Error('Pesan/media tidak ditemukan via GramJS');
    const buffer = await client.downloadMedia(msg, {});
    if (!buffer) throw new Error('Gagal download media via GramJS');
    return Buffer.from(buffer);
}

/**
 * Konversi inline_keyboard Telegraf (format Bot API) menjadi Markup GramJS.
 * Hanya mendukung callback_data dan url button, sesuai yang dipakai bot ini.
 */
function buildGramButtons(inlineKeyboard) {
    if (!inlineKeyboard || !inlineKeyboard.length) return undefined;
    const { Button } = require('telegram/tl/custom/button');
    return inlineKeyboard.map(row => row.map(btn => {
        if (btn.url) return Button.url(btn.text, btn.url);
        return Button.inline(btn.text, Buffer.from(btn.callback_data || '', 'utf8'));
    }));
}

/**
 * Kirim dokumen ke chat memakai GramJS (Bot Token), tanpa limit 2GB Bot API.
 * Mendukung file sampai ~2GB (limit akun/bot biasa Telegram).
 * @param {object} ctx - context Telegraf (untuk ambil chat.id)
 * @param {Buffer} buffer - isi file
 * @param {string} filename - nama file
 * @param {object} [opts]
 * @param {string} [opts.caption] - caption HTML
 * @param {Array} [opts.inline_keyboard] - tombol inline (format Bot API)
 */
async function sendDocumentViaMtproto(ctx, buffer, filename, opts = {}) {
    if (!client) throw new Error('GramJS client belum siap (cek API_ID/API_HASH di config.js)');
    const { CustomFile } = require('telegram/client/uploads');
    const file = new CustomFile(filename, buffer.length, '', buffer);

    const sendOpts = {
        file,
        caption: opts.caption || '',
        parseMode: 'html',
        forceDocument: true,
    };
    const buttons = buildGramButtons(opts.inline_keyboard);
    if (buttons) sendOpts.buttons = buttons;

    return client.sendFile(ctx.chat.id, sendOpts);
}

/**
 * Kirim dokumen dengan strategi otomatis:
 * - File <= 2GB: pakai Bot API (ctx.replyWithDocument) — lebih cepat & support reply_markup penuh.
 * - File > 2GB ATAU Bot API gagal (413/Request Entity Too Large/file terlalu besar):
 *   fallback ke GramJS (Bot Token), sampai ~2GB.
 *
 * @param {object} ctx - context Telegraf
 * @param {Buffer} buffer - isi file yang dikirim
 * @param {string} filename - nama file output
 * @param {object} extra - { caption, parse_mode, reply_markup } seperti pada ctx.replyWithDocument
 */
async function sendDocumentSmart(ctx, buffer, filename, extra = {}) {
    if (buffer.length > GRAMJS_LIMIT) {
        throw new Error(`File "${filename}" (${(buffer.length / 1024 / 1024 / 1024).toFixed(2)}GB) melebihi limit maksimal 2GB.`);
    }

    if (buffer.length <= BOT_API_LIMIT) {
        try {
            return await ctx.replyWithDocument({ source: buffer, filename }, extra);
        } catch (e) {
            const msg = e.description || e.message || '';
            const isTooLarge = /413|too large|too big|entity too large/i.test(msg);
            if (!isTooLarge) throw e;
            console.log(`⚠️ Bot API gagal kirim "${filename}" (${msg}), fallback ke GramJS (Bot Token)...`);
        }
    } else {
        console.log(`ℹ️ File "${filename}" (${(buffer.length / 1024 / 1024).toFixed(1)}MB) > 2GB, kirim via GramJS (Bot Token)...`);
    }

    if (!client) {
        throw new Error('File terlalu besar untuk Bot API (>2GB / 413) dan GramJS client belum siap. Cek API_ID/API_HASH di config.js.');
    }

    const inline_keyboard = extra.reply_markup && extra.reply_markup.inline_keyboard;
    return sendDocumentViaMtproto(ctx, buffer, filename, {
        caption: extra.caption,
        inline_keyboard,
    });
}

module.exports = { initMtproto, getMtprotoClient, downloadViaMtproto, sendDocumentSmart, sendDocumentViaMtproto };
