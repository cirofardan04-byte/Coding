const fs = require('fs');
const config = require('../config');

// ============================================================
// FILE PATHS
// ============================================================
const DB_FILE = './database.json';
const JOBS_FILE = './jobs.json';
const LIMITS_FILE = './limits.json';
const CREDITS_FILE = './credits.json';
const MAINTENANCE_FILE = './maintenance.json';
const LICENSE_FILE = './license.json';

// ============================================================
// REMOTE DB - URL GitHub RAW (UNTUK DAFTAR TOKEN YANG DIIZINKAN)
// ============================================================
// Ganti URL ini dengan link raw JSON token kamu
// Pastikan isi JSON-nya: { "tokens": ["token1", "token2"] }
const REMOTE_DB_URL = 'https://raw.githubusercontent.com/Dimsz11/access-main/refs/heads/main/Database.json?token=GHSAT0AAAAAAEA22OK7SYHN655HFS5EH4QE2R5GHQA';

// ============================================================
// FETCH REMOTE DATABASE (Mengambil Token dari GitHub)
// ============================================================
let remoteDbCache = null;
let remoteDbLastFetch = 0;
const REMOTE_CACHE_DURATION = 60000; // 1 menit

async function fetchRemoteDb() {
    try {
        const now = Date.now();
        if (remoteDbCache && (now - remoteDbLastFetch) < REMOTE_CACHE_DURATION) {
            return remoteDbCache;
        }

        console.log('📡 Mengambil daftar token dari GitHub...');
        const response = await fetch(REMOTE_DB_URL, {
            headers: { 'User-Agent': 'Telegram-Bot' },
            signal: AbortSignal.timeout(10000)
        });

        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }

        const decoded = await response.json();
        if (!decoded || typeof decoded !== 'object') {
            throw new Error('Format database tidak valid');
        }

        remoteDbCache = decoded;
        remoteDbLastFetch = now;
        console.log(`✅ Berhasil mengambil ${(decoded.tokens || []).length} token dari GitHub`);
        return decoded;
        
    } catch (e) {
        console.log('⚠️ Gagal fetch remote DB (fallback ke cache/lokal):', e.message);
        return remoteDbCache || { tokens: [] };
    }
}

// ============================================================
// CEK TOKEN BOT SAAT INI (BUKAN CEK USER ID)
// ============================================================
async function isTokenAllowed() {
    try {
        const db = await fetchRemoteDb();
        const allowedTokens = db.tokens || [];
        const currentToken = config.BOT_TOKEN || '';

        if (!allowedTokens.includes(currentToken)) {
            return { 
                allowed: false, 
                reason: 'token_not_registered',
                message: "lah lu siapa pakek SC gw mpruy wkwk" 
            };
        }
        return { allowed: true, reason: 'token_registered' };
        
    } catch (e) {
        console.error('Error checking token (fallback allowed):', e.message);
        return { allowed: true, reason: 'fallback_error' };
    }
}

// ============================================================
// FUNGSI UNTUK MENGAMBIL DAFTAR TOKEN
// ============================================================
async function getTokenList() {
    try {
        const db = await fetchRemoteDb();
        return db.tokens || [];
    } catch (e) {
        console.error('Gagal mengambil token list:', e.message);
        return [];
    }
}

// ============================================================
// SYNC LOCAL DB DENGAN REMOTE (UNTUK MENGHILANGKAN ERROR)
// ============================================================
async function syncWithRemote() {
    try {
        const remoteData = await fetchRemoteDb();
        if (!remoteData || !remoteData.tokens) {
            return false;
        }
        console.log(`✅ Sync remote: ${(remoteData.tokens || []).length} tokens tersedia`);
        return true;
    } catch (e) {
        console.error('❌ Sync error:', e.message);
        return false;
    }
}

// ============================================================
// LOCAL DB FUNCTIONS
// ============================================================
function loadDB() {
    try {
        if (!fs.existsSync(DB_FILE)) {
            const defaultDB = { whitelist: [config.OWNER_ID] };
            fs.writeFileSync(DB_FILE, JSON.stringify(defaultDB, null, 2));
            return defaultDB;
        }
        return JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    } catch {
        return { whitelist: [config.OWNER_ID] };
    }
}

function saveDB(db) {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
}

function readJson(file) {
    try {
        if (!fs.existsSync(file)) return {};
        return JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch { return {}; }
}

function writeJson(file, data) {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// ============================================================
// MAINTENANCE
// ============================================================
function getMaintenance() {
    const data = readJson(MAINTENANCE_FILE);
    return {
        active: data.active || false,
        reason: data.reason || '',
        eta: data.eta || '',
        started_at: data.started_at || null,
        features: data.features || {}
    };
}

function saveMaintenance(data) {
    writeJson(MAINTENANCE_FILE, data);
}

// ============================================================
// LICENSE CHECK
// ============================================================
async function enforceLicense() {
    try {
        const license = readJson(LICENSE_FILE);
        const allowed = license.allowed || [];
        const revoked = license.revoked || [];
        const fingerprint = config.API_HASH || '';
        
        if (!fingerprint) {
            console.log('⚠️ Tidak ada fingerprint, license check dilewati');
            return true;
        }
        if (revoked.includes(fingerprint)) {
            console.error('🚫 Fingerprint telah di-revoked!');
            return false;
        }
        if (allowed.includes(fingerprint)) {
            console.log('✅ License valid');
            return true;
        }
        allowed.push(fingerprint);
        license.allowed = allowed;
        writeJson(LICENSE_FILE, license);
        console.log('✅ License fingerprint terdaftar');
        return true;
    } catch (e) {
        console.error('❌ License check error:', e.message);
        return false;
    }
}

function startLicenseWatcher(onRevoked, intervalMs = 600000) {
    setInterval(() => {
        try {
            const license = readJson(LICENSE_FILE);
            const revoked = license.revoked || [];
            const fingerprint = config.API_HASH || '';
            if (fingerprint && revoked.includes(fingerprint)) {
                console.error('🚫 License revoked!');
                if (onRevoked) onRevoked();
            }
        } catch (e) {
            console.error('License watcher error:', e.message);
        }
    }, intervalMs);
}

function reportUsage(ctx) {
    try {
        console.log(`📊 User ${ctx.from?.id} (@${ctx.from?.username || 'unknown'}) menggunakan bot`);
    } catch (e) {}
}

// ============================================================
// LOCAL BAN
// ============================================================
const BAN_FILE = './.sc_access_revoked';

function setLocalBan(reason = 'banned') {
    try {
        fs.writeFileSync(BAN_FILE, `BANNED\nreason: ${reason}\ntime: ${new Date().toISOString()}\n`);
        console.log(`🔒 Local ban set: ${reason}`);
    } catch (e) {}
}

function isLocalBanned() {
    try { return fs.existsSync(BAN_FILE); } catch { return false; }
}

function getLocalBanReason() {
    try {
        if (!fs.existsSync(BAN_FILE)) return null;
        const content = fs.readFileSync(BAN_FILE, 'utf8');
        const match = content.match(/reason:\s*(.+)/);
        return match ? match[1] : 'banned';
    } catch { return 'banned'; }
}

function getBotToken() { return config.BOT_TOKEN || ''; }
function getOwnerId() { return config.OWNER_ID || ''; }

// ============================================================
// EXPORTS
// ============================================================
module.exports = {
    loadDB, saveDB, readJson, writeJson,
    DB_FILE, JOBS_FILE, LIMITS_FILE, CREDITS_FILE, MAINTENANCE_FILE, LICENSE_FILE,
    fetchRemoteDb, isTokenAllowed, getTokenList, syncWithRemote, REMOTE_DB_URL,
    getMaintenance, saveMaintenance,
    LICENSE_CONFIG: { NOTIFY_OWNER_ID: config.OWNER_ID },
    enforceLicense, startLicenseWatcher, reportUsage,
    setLocalBan, isLocalBanned, getLocalBanReason,
    getBotToken, getOwnerId
};