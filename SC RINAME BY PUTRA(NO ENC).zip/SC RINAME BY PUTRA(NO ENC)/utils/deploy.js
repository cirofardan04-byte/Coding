const AdmZip = require('adm-zip');
const config = require('../config');

const MAX_DEPLOY_SIZE = 2 * 1024 * 1024 * 1024; // 2GB — batas aman untuk deploy langsung via API
const MAX_DEPLOY_FILES = 1500;

// ============================================================
// Helper: buka ZIP, deteksi & strip 1 folder root umum
// (Telegram biasa kirim ZIP dengan 1 folder pembungkus di root,
// padahal Vercel/Netlify butuh index.html dkk di ROOT deployment)
// ============================================================
function readZipEntries(zipBuffer) {
    const zip = new AdmZip(zipBuffer);
    const all = zip.getEntries().filter(e => !e.isDirectory);
    if (all.length === 0) throw new Error('File ZIP kosong / tidak berisi file apapun.');

    let prefix = '';
    const first = all[0].entryName;
    const slashIdx = first.indexOf('/');
    if (slashIdx !== -1) {
        const candidate = first.substring(0, slashIdx + 1);
        if (all.every(e => e.entryName.startsWith(candidate))) prefix = candidate;
    }

    const SKIP_PATTERNS = [
        /^(.*\/)?node_modules\//,
        /^(.*\/)?\.git\//,
        /^(.*\/)?__MACOSX\//,
        /^(.*\/)?\.DS_Store$/,
        /^(.*\/)?Thumbs\.db$/,
    ];

    const files = [];
    let totalSize = 0;
    for (const e of all) {
        let rel = prefix ? e.entryName.substring(prefix.length) : e.entryName;
        if (!rel) continue;
        if (SKIP_PATTERNS.some(p => p.test(rel)) || SKIP_PATTERNS.some(p => p.test(e.entryName))) continue;
        const data = e.getData();
        totalSize += data.length;
        files.push({ path: rel, data });
    }

    if (files.length === 0) throw new Error('Tidak ada file valid di dalam ZIP setelah filtering.');
    if (files.length > MAX_DEPLOY_FILES) throw new Error(`Project terlalu banyak file (${files.length}). Maksimal ${MAX_DEPLOY_FILES} file untuk deploy langsung lewat bot.`);
    if (totalSize > MAX_DEPLOY_SIZE) throw new Error(`Ukuran project terlalu besar (${(totalSize / 1024 / 1024).toFixed(1)}MB). Maksimal ${(MAX_DEPLOY_SIZE / 1024 / 1024 / 1024).toFixed(0)}GB untuk deploy langsung lewat bot.`);

    return files;
}

function slugifyName(name) {
    return (name || '')
        .toLowerCase()
        .replace(/[^a-z0-9-]/g, '-')
        .replace(/-+/g, '-')
        .replace(/^-|-$/g, '')
        .slice(0, 52);
}

// ============================================================
// DEPLOY KE VERCEL
// Pakai REST API v13 deployments dengan inline file content
// (base64). Cocok untuk static site / hasil build kecil-menengah.
// Docs: https://vercel.com/docs/rest-api/endpoints/deployments
// ============================================================
async function deployToVercel(zipBuffer, projectName) {
    if (!config.VERCEL_TOKEN) throw new Error('VERCEL_TOKEN belum diisi di config.js. Minta Owner isi dulu di https://vercel.com/account/tokens');

    const files = readZipEntries(zipBuffer);
    const name = slugifyName(projectName) || `tg-deploy-${Date.now()}`;

    const body = {
        name,
        target: 'production',
        projectSettings: { framework: null },
        files: files.map(f => ({
            file: f.path,
            data: f.data.toString('base64'),
            encoding: 'base64',
        })),
    };

    let url = 'https://api.vercel.com/v13/deployments';
    if (config.VERCEL_TEAM_ID) url += `?teamId=${encodeURIComponent(config.VERCEL_TEAM_ID)}`;

    const res = await fetch(url, {
        method: 'POST',
        headers: {
            Authorization: `Bearer ${config.VERCEL_TOKEN}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(body),
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
        const msg = data?.error?.message || data?.message || JSON.stringify(data) || `HTTP ${res.status}`;
        throw new Error(msg);
    }

    return {
        platform: 'Vercel',
        url: `https://${data.url}`,
        inspectorUrl: data.inspectorUrl || null,
        id: data.id,
        state: data.readyState || 'QUEUED',
    };
}

// ============================================================
// DEPLOY KE NETLIFY
// Pakai REST API "Deploy via ZIP" — kirim ZIP langsung sebagai
// body request dengan Content-Type: application/zip.
// Docs: https://docs.netlify.com/api/get-started/#deploy-with-zip
// ============================================================
async function deployToNetlify(zipBuffer, siteName) {
    if (!config.NETLIFY_TOKEN) throw new Error('NETLIFY_TOKEN belum diisi di config.js. Minta Owner isi dulu di https://app.netlify.com/user/applications');

    // Strip folder pembungkus root supaya index.html ada di root ZIP
    const files = readZipEntries(zipBuffer);
    const out = new AdmZip();
    for (const f of files) out.addFile(f.path, f.data);
    const normalizedZip = out.toBuffer();

    const name = slugifyName(siteName);
    let url = 'https://api.netlify.com/api/v1/sites';
    if (name) url += `?name=${encodeURIComponent(name)}`;

    const res = await fetch(url, {
        method: 'POST',
        headers: {
            Authorization: `Bearer ${config.NETLIFY_TOKEN}`,
            'Content-Type': 'application/zip',
        },
        body: normalizedZip,
    });

    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
        const msg = data?.message || JSON.stringify(data) || `HTTP ${res.status}`;
        throw new Error(msg);
    }

    return {
        platform: 'Netlify',
        url: data.ssl_url || data.url,
        adminUrl: data.admin_url || null,
        id: data.site_id || data.id,
        state: data.state || 'processing',
    };
}

module.exports = { deployToVercel, deployToNetlify, slugifyName, readZipEntries };
