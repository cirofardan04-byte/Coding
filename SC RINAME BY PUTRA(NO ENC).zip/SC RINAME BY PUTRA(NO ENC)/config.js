module.exports = {
    // ===== BOT CONFIG =====
    BOT_TOKEN: '8888325606:AAE5CNoiJ4KaLVakT_yuq1oKtqUkuFuAIk4',
    OWNER_ID: 8511513555,
    OWNER_USERNAME: 'FarzzOffcial',

    // ===== MTPROTO (GramJS) — untuk download file >2GB =====
    API_ID: 36586412,
    API_HASH: '0ac6df74fb4e1fcbe4453b20c8d69983',

    
    WELCOME_MEDIA: 'https://files.catbox.moe/5syvre.mp4',
    WELCOME_MEDIA_TYPE: 'video',

    // ===== LIMIT PENGGUNAAN HARIAN =====
    DAILY_LIMIT: 3,
     
    FORCE_JOIN_CHANNEL: 'AllInformationFarzz',          
    FORCE_JOIN_CHANNEL_LINK: 'https://t.me/AllInformationFarzz', 

    // ===== GITHUB (untuk Build Flutter) =====
    GITHUB_TOKEN: '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',
    GITHUB_OWNER: 'cirofardan04-byte',
    GITHUB_REPO: 'Farzz-Sky',
    GITHUB_BRANCH: 'main',
    GITHUB_WORKFLOW: 'flutter_build.yml',

    // ===== DEPLOY (VERCEL & NETLIFY) =====
    VERCEL_TOKEN: 'vcp_0q4NX5xle7LL3n4pxgPW9eu0zaVqgrgoORdi8rnkxtwNRWVkSP4VeLME',
    VERCEL_TEAM_ID: 'usMUO8qS5P4zsw5yKvYVip6w',
    NETLIFY_TOKEN: 'nfp_H81MCubS3SRng4dFAWE7kBFLWVag8YwKbb47',
};
