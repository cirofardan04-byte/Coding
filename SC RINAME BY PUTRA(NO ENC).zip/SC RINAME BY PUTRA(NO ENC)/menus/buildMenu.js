const { getMaintenance } = require('../utils/database');

async function showBuildMenu(ctx) {
    try { await ctx.answerCbQuery(); } catch {}

    const maint = getMaintenance();
    const buildMaint = maint.active || maint.features?.build;

    if (buildMaint) {
        const maintMsg = maint.features?.build_msg || maint.global_msg ||
            `🔧 Fitur Sedang Maintenance\n\nFitur 🏗️ Build Flutter sedang tidak tersedia sementara.\n\n📝 Alasan :\n${maint.reason || 'Sedang dalam perbaikan'}\n\n⏱ Estimasi :\n${maint.eta || '1-2 jam'}\n\nMohon bersabar dan coba lagi nanti 🙏`;

        const msgText = `<blockquote>${maintMsg}</blockquote>`;
        try {
            await ctx.editMessageText(msgText, {
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: [[{ text: '🔙 Kembali', callback_data: 'main_menu', style: 'primary' }]] }
            });
        } catch {
            await ctx.reply(msgText, {
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: [[{ text: '🔙 Kembali', callback_data: 'main_menu', style: 'primary' }]] }
            });
        }
        return;
    }

    const keyboard = [
        [{ text: '📁 Build via ZIP (2GB)', callback_data: 'build_zip', style: 'primary' }],
        [{ text: '🔗 Build via URL (2GB)', callback_data: 'build_url', style: 'primary' }],
        [{ text: '📊 Cek Status Build', callback_data: 'build_status', style: 'primary' }],
        [{ text: '📥 Ambil APK', callback_data: 'build_get_apk', style: 'success' }],
        [{ text: '🔙 Kembali', callback_data: 'main_menu', style: 'primary' }],
    ];
    const msgText = `<blockquote>🏗 <b>BUILD FLUTTER</b>\n\nBuild project Flutter kamu menjadi APK/AAB menggunakan GitHub Actions.\n\n📌 <b>Pilih metode build:</b></blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
    }
}

async function showBuildZipPrompt(ctx) {
    const msgText = `<blockquote>📁 <b>BUILD VIA ZIP</b>\n\nKirimkan file <b>.zip</b> project Flutter kamu (maks 2GB).\n\n⏳ Bot akan mengupload ke GitHub dan mulai proses build otomatis.</blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_build', style: 'danger' }]] } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_build', style: 'danger' }]] } });
    }
}

async function showBuildUrlPrompt(ctx) {
    const msgText = `<blockquote>🔗 <b>BUILD VIA URL</b>\n\nKirimkan <b>URL</b> repository GitHub atau link zip project Flutter kamu.\n\nContoh: <code>https://github.com/user/repo/archive/main.zip</code></blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_build', style: 'danger' }]] } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_build', style: 'danger' }]] } });
    }
}

async function showBuildStatusPrompt(ctx) {
    const msgText = `<blockquote>📊 <b>CEK STATUS BUILD</b>\n\nKirimkan <b>Job ID</b> build kamu.\n\nJob ID dikirimkan saat kamu memulai build.</blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_build', style: 'danger' }]] } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_build', style: 'danger' }]] } });
    }
}

async function showGetApkPrompt(ctx) {
    const msgText = `<blockquote>📥 <b>AMBIL APK</b>\n\nKirimkan <b>Job ID</b> build kamu untuk mengunduh hasil APK/AAB.\n\nJob ID dikirimkan saat kamu memulai build.</blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_build', style: 'danger' }]] } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_build', style: 'danger' }]] } });
    }
}

module.exports = { showBuildMenu, showBuildZipPrompt, showBuildUrlPrompt, showBuildStatusPrompt, showGetApkPrompt };
