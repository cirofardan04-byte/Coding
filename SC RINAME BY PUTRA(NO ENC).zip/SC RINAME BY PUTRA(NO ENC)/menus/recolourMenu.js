const COLOUR_LIST = [
    { name: '🔴 Merah', hex: 'FF0000' },
    { name: '🟠 Oranye', hex: 'FF6600' },
    { name: '🟡 Kuning', hex: 'FFCC00' },
    { name: '🟢 Hijau', hex: '00CC44' },
    { name: '🔵 Biru', hex: '0066FF' },
    { name: '🟣 Ungu', hex: '9933FF' },
    { name: '🩷 Pink', hex: 'FF3399' },
    { name: '🤍 Putih', hex: 'FFFFFF' },
    { name: '🖤 Hitam', hex: '000000' },
    { name: '🩶 Abu-abu', hex: '888888' },
    { name: '🟤 Cokelat', hex: '8B4513' },
    { name: '🎨 Custom Hex', hex: 'CUSTOM' },
];

async function showRecolourMenu(ctx) {
    await ctx.answerCbQuery();
    const rem = require('../utils/credits').getRemaining(ctx.from.id);
    const cancelButton = { text: '❌ Batalkan', callback_data: 'main_menu', style: 'danger' };
    const msgText = `<blockquote>🎨 <b>RECOLOUR</b>\n\nFitur ini mengganti warna HEX di file <b>.dart</b> project Flutter kamu.\n\n💎 Kredit tersisa: <b>${rem}</b>\n\n<b>Langkah 1:</b> Kirimkan <b>file .dart</b> yang ingin diubah warnanya.\n\n📌 Kamu bisa kirim <b>1 atau lebih file .dart</b> sekaligus (kirim satu per satu, lalu ketik <b>selesai</b>).\n\n⚠️ Kirim sebagai <b>File/Dokumen</b>, bukan foto.\n\n📄 Hasil: file .dart yang sudah diubah dikirim balik satu per satu.</blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[cancelButton]] } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[cancelButton]] } });
    }
}

async function showColourPicker(ctx, dartFiles) {
    const colourKeyboard = [];
    for (let i = 0; i < COLOUR_LIST.length; i += 2) {
        const row = COLOUR_LIST.slice(i, i + 2).map(c => ({
            text: c.name,
            callback_data: `colour_pick_${c.hex}`,
            style: 'primary'
        }));
        colourKeyboard.push(row);
    }
    colourKeyboard.push([{ text: '❌ Batal', callback_data: 'main_menu', style: 'danger' }]);

    await ctx.reply(
        `<blockquote>✅ <b>${dartFiles.length} file .dart diterima!</b>\n\n🎨 Pilih <b>warna baru</b> yang ingin kamu gunakan:</blockquote>`,
        { parse_mode: 'HTML', reply_markup: { inline_keyboard: colourKeyboard } }
    );
}

module.exports = { showRecolourMenu, showColourPicker, COLOUR_LIST };
