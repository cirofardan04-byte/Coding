const { creditDisplay } = require('../utils/credits');
const { getMaintenance } = require('../utils/database');
const config = require('../config');

async function showMainMenu(ctx, ownerId) {
    const isOwner = ctx.from.id === (ownerId ?? config.OWNER_ID);
    const credits = creditDisplay(ctx.from.id);
    const maint = getMaintenance();

    if (maint.active && !isOwner) {
        const maintText = `<blockquote>🔧 <b>Bot Sedang Maintenance</b>\n\n📝 <b>Alasan:</b>\n${maint.reason || 'Sedang dalam perbaikan'}\n\n⏱ <b>Estimasi:</b>\n${maint.eta || '1-2 jam'}\n\nMohon bersabar dan coba lagi nanti 🙏</blockquote>`;
        try {
            if (ctx.updateType === 'callback_query') { try { await ctx.deleteMessage(); } catch {} }
            await ctx.reply(maintText, { parse_mode: 'HTML' });
        } catch {}
        return;
    }

    let maintBanner = '';
    if (maint.active && isOwner) {
        maintBanner = `\n\n⚠️ <b>[MAINTENANCE AKTIF]</b> — user lain tidak bisa akses`;
    }

    const text = `<blockquote>⭐ <b>ASISTEN PADUKA YUZI</b>\n\nSelamat datang! Bot ini membantu kamu mengelola project Flutter dengan mudah dan cepat.\n\n📌 <b>Fitur tersedia:</b>\n🔥 <b>Rename All</b> — rename domain+port, logo &amp; nama app sekaligus\n⚡️ <b>Rename Domain</b> — ganti domain/port di seluruh file\n🎨 <b>Recolour</b> — ganti warna hex di file .dart\n🔧 <b>Manage Functions</b> — ganti Func di file .js\n🗜 <b>Compress Base</b> — hapus file tidak perlu &amp; kompres\n🏗 <b>Build Flutter</b> — build APK/AAB via GitHub Actions\n🔄 <b>Js &amp; Html To Dart</b> — konversi file JS/HTML ke Dart\n🔍 <b>Cek Syntax JS</b> — analisis &amp; cek error syntax JS\n🖼 <b>Ganti Icon App</b> — ganti icon aplikasi Flutter\n✏️ <b>Rename Nama App</b> — ganti nama aplikasi Flutter\n🛠 <b>Cek Error Func</b> — analisis error di fungsi JS\n📸 <b>Screenshot Web</b> — screenshot tampilan website\n🚀 <b>Deploy</b> — deploy project ke Vercel / Netlify\n🤖 <b>Jadibot</b> — clone bot dengan token baru\n🧪 <b>Preview Dart</b> — render widget .dart jadi gambar langsung\n\n💎 <b>Kredit kamu: ${credits}</b>\n🚀 Proses otomatis, cepat, dan akurat!${maintBanner}</blockquote>`;

    const keyboard = [
        [{ text: '🔥 Rename All (Domain+Logo+Nama)', callback_data: 'menu_renameall', style: 'primary' }],
        [
            { text: '⚡ Rename Domain', callback_data: 'menu_rename', style: 'primary' },
            { text: '🎨 Recolour', callback_data: 'menu_recolour', style: 'primary' }
        ],
        [{ text: '🔧 Manage Functions', callback_data: 'menu_functions', style: 'primary' }],
        [
            { text: '🗜 Compress Base', callback_data: 'menu_compress', style: 'primary' },
            { text: '🏗 Build Flutter', callback_data: 'menu_build', style: 'primary' }
        ],
        [{ text: '🔄 Js and Html To Dart', callback_data: 'menu_jshtml', style: 'primary' }],
        [{ text: '🔍 Cek Syntax JS', callback_data: 'menu_ceksyntax', style: 'primary' }],
        [
            { text: '🖼 Ganti Icon App', callback_data: 'menu_gantiicon', style: 'primary' },
            { text: '✏️ Rename Nama App', callback_data: 'menu_renameapp', style: 'primary' }
        ],
        [{ text: '🛠 Cek Error Func', callback_data: 'menu_cekerrorfunc', style: 'primary' }],
        [
            { text: '📸 Screenshot Web', callback_data: 'menu_ssweb', style: 'primary' },
            { text: '🤖 Jadibot', callback_data: 'menu_jadibot', style: 'primary' }
        ],
        [{ text: '🚀 Deploy (Vercel/Netlify)', callback_data: 'menu_deploy', style: 'primary' }],
        [{ text: '🧪 Preview Dart Widget', callback_data: 'menu_dartpreview', style: 'primary' }],
        [{ text: '👤 Contact Developer', callback_data: 'contact_dev', style: 'primary' }],
    ];
    if (isOwner) keyboard.push([{ text: '⚙️ Panel Owner', callback_data: 'panel_owner', style: 'primary' }]);

    try {
        if (config.WELCOME_MEDIA && config.WELCOME_MEDIA_TYPE) {
            if (ctx.updateType === 'callback_query') { try { await ctx.deleteMessage(); } catch {} }
            if (config.WELCOME_MEDIA_TYPE === 'photo') {
                await ctx.replyWithPhoto(config.WELCOME_MEDIA, { caption: text, parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
            } else if (config.WELCOME_MEDIA_TYPE === 'video') {
                await ctx.replyWithVideo(config.WELCOME_MEDIA, { caption: text, parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
            } else if (config.WELCOME_MEDIA_TYPE === 'audio') {
                await ctx.replyWithAudio(config.WELCOME_MEDIA, { caption: text, parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
            } else {
                await ctx.replyWithDocument(config.WELCOME_MEDIA, { caption: text, parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
            }
        } else {
            if (ctx.updateType === 'callback_query') { try { await ctx.deleteMessage(); } catch {} }
            await ctx.reply(text, { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
        }
    } catch (e) {
        try { await ctx.reply(text, { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } }); } catch {}
    }
}

module.exports = { showMainMenu };
