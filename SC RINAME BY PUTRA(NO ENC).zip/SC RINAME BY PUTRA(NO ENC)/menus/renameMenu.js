async function showRenameMenu(ctx) {
    await ctx.answerCbQuery();
    const rem = require('../utils/credits').getRemaining(ctx.from.id);
    const cancelButton = { text: '❌ Batalkan', callback_data: 'main_menu', style: 'danger' };
    const msgText = `<blockquote>⚡ <b>RENAME DOMAIN</b>\n\nFitur ini mengganti domain/URL di seluruh file project Flutter kamu.\n\n💎 Kredit tersisa: <b>${rem}</b>\n\n<b>Langkah 1:</b> Kirimkan file .zip project Flutter kamu.\n\n⚠️ Pastikan file zip berisi semua file yang perlu diubah.</blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[cancelButton]] } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[cancelButton]] } });
    }
}

module.exports = { showRenameMenu };
