const { getMaintenance } = require('../utils/database');

async function showDeployMenu(ctx) {
    try { await ctx.answerCbQuery(); } catch {}

    const maint = getMaintenance();
    const deployMaint = maint.active || maint.features?.deploy;

    if (deployMaint) {
        const maintMsg = maint.features?.deploy_msg || maint.global_msg ||
            `🔧 Fitur Sedang Maintenance\n\nFitur 🚀 Deploy sedang tidak tersedia sementara.\n\n📝 Alasan :\n${maint.reason || 'Sedang dalam perbaikan'}\n\n⏱ Estimasi :\n${maint.eta || '1-2 jam'}\n\nMohon bersabar dan coba lagi nanti 🙏`;

        const msgText = `<blockquote>${maintMsg}</blockquote>`;
        try {
            await ctx.editMessageText(msgText, {
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: [[{ text: '🔙 Kembali', callback_data: 'main_menu', style: 'primary' }]] }
            });
        } catch {
            await ctx.reply(msgText, {
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: [[{ text: '🔙 Kembali', callback_data: 'main_menu', style: 'primary' }]] }
            });
        }
        return;
    }

    const msgText = `<blockquote>🚀 <b>DEPLOY WEBSITE</b>\n\nDeploy project static/web (hasil build, HTML/CSS/JS, dll) langsung ke hosting gratis.\n\n📌 <b>Pilih platform tujuan deploy:</b></blockquote>`;
    const keyboard = [
        [{ text: '▲ Deploy ke Vercel', callback_data: 'deploy_vercel', style: 'primary' }],
        [{ text: '◆ Deploy ke Netlify', callback_data: 'deploy_netlify', style: 'primary' }],
        [{ text: '🔙 Kembali', callback_data: 'main_menu', style: 'primary' }],
    ];
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
    }
}

async function showDeployZipPrompt(ctx, platform) {
    const label = platform === 'vercel' ? 'Vercel' : 'Netlify';
    const msgText = `<blockquote>🚀 <b>DEPLOY KE ${label.toUpperCase()}</b>\n\nKirimkan file <b>.zip</b> berisi project static/web kamu.\n\n📌 <b>Struktur yang didukung:</b>\n• File <code>index.html</code> + aset (CSS/JS/gambar) langsung di root ZIP\n• Atau hasil build (folder <code>dist</code>/<code>build</code>/<code>public</code>) — pastikan <code>index.html</code> ada di dalamnya\n\n⚠️ Maks ukuran ZIP ~2GB.\n\n⏳ Setelah dikirim, bot otomatis deploy ke ${label} memakai token yang sudah dikonfigurasi Owner.</blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_deploy', style: 'danger' }]] } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '❌ Batal', callback_data: 'menu_deploy', style: 'danger' }]] } });
    }
}

module.exports = { showDeployMenu, showDeployZipPrompt };
