async function showOwnerPanel(ctx) {
    try { await ctx.answerCbQuery(); } catch {}
    const keyboard = [
        [
            { text: '➕ Whitelist User', callback_data: 'owner_whitelist', style: 'success' },
            { text: '➖ Remove User', callback_data: 'owner_remove', style: 'danger' }
        ],
        [{ text: '📋 Lihat Whitelist', callback_data: 'owner_list', style: 'primary' }],
        [{ text: '💎 Tambah Kredit User', callback_data: 'owner_add_credits', style: 'success' }],
        [{ text: '👁️ Lihat Kredit User', callback_data: 'owner_view_credits', style: 'primary' }],
        [{ text: '🖼️ Set Foto Sambutan', callback_data: 'owner_set_photo', style: 'primary' }],
        [{ text: '🎬 Set Video Sambutan', callback_data: 'owner_set_video', style: 'primary' }],
        [{ text: '🎵 Set Audio Sambutan', callback_data: 'owner_set_audio', style: 'primary' }],
        [{ text: '🗑️ Hapus Media Sambutan', callback_data: 'owner_clear_media', style: 'danger' }],
        [
            { text: '🔧 Toggle Maintenance', callback_data: 'owner_toggle_maintenance', style: 'danger' },
            { text: '📢 Broadcast', callback_data: 'owner_broadcast', style: 'success' }
        ],
        [{ text: '🔙 Kembali', callback_data: 'main_menu', style: 'primary' }],
    ];
    const msgText = `<blockquote>⚙️ <b>PANEL OWNER</b>\n\nSelamat datang di panel owner. Kamu bisa mengelola whitelist user, kredit, media sambutan, maintenance, dan broadcast.</blockquote>`;
    try {
        await ctx.editMessageText(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
    } catch {
        await ctx.reply(msgText, { parse_mode: 'HTML', reply_markup: { inline_keyboard: keyboard } });
    }
}

module.exports = { showOwnerPanel };
